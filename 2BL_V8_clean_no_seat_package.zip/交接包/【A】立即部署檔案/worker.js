// ================================================================
// 2BL V8 Cloudflare Worker
// 正式主線檔案：worker.js
// worker.txt 僅為由本檔同步產出的純文字備用版。
// 禁止使用舊 worker.txt 覆蓋本檔；若 worker.js 有修改，必須同步更新 worker.txt。
// 更新日期：2026-06-28（版本殘留清理版）
// ================================================================
// 環境變數 (Cloudflare Workers 設定)：
//   SUPABASE_URL  — 2BL Supabase Project URL
//   SUPABASE_SERVICE_ROLE_KEY — Supabase service_role key（SUPABASE_KEY 相容備援）
//   RESEND_KEY    — Resend API key
//   AUTH_SECRET   — token 鹽值（自訂字串，改後管理員需重新登入）
// wrangler.toml cron：
//   [[triggers.crons]]
//   crons = ["0 1 * * *", "0 2 * * *"]
// ================================================================

// ── SECTION 1: 常數設定 ─────────────────────────────────────────
// DEFAULT_TENANT 已移除（M-02）：缺少 tenant 一律回傳 400，不允許 fallback
const PAY_DEADLINE_HOURS = 48;
const REMINDER_HOURS    = 36;
const STALL_HOLD_DAYS   = 3;
const FORCE_CHOICE_HOURS = 48; // 不可抗力選擇期限固定 48 小時

// 不可抗力原因代碼（後台單選清單）
const FORCE_REASON_CODES = {
  typhoon:                    '颱風警報',
  heavy_rain:                 '豪雨／大雨特報',
  earthquake_or_disaster:     '地震或災害安全疑慮',
  gov_work_school_suspension: '政府公告停班停課',
  gov_order_cancel:           '政府／主管機關要求停辦',
  venue_safety_request:       '場地方公共安全要求',
  venue_unavailable:          '場地突發不可使用',
  traffic_disruption:         '交通中斷或重大管制',
  other_force_majeure:        '其他不可抗力因素',
};

// fallback 常數（當 tenants 資料庫欄位為空時使用）
const FALLBACK_SITE_URL   = 'https://2b-love.com/';
// FALLBACK_LINE_URL 已移除：LINE 連結僅由 tenant_settings/tenants.line_url 提供，缺設定不 fallback
// FALLBACK_BANK_INFO 已移除：付款資訊僅由 tenant 設定提供，缺設定不 fallback
const FALLBACK_EMAIL_FROM = '2BL V8 <no-reply@2b-love.com>'; // fallback only；正式寄件資料以 tenants 設定為準
const FALLBACK_EMAIL_REPLY= 'service@2b-love.com'; // fallback only；正式回覆信箱以 tenants 設定為準
const FALLBACK_TENANT_NAME= '2BL V8';
const DEFAULT_REFUND_RULES = {
  transferFeeDefault: 0,
  rules: [
    { key:'before_7', label:'活動前 7 日以上：扣行政費 NT$500', minDays:7, adminFeeType:'fixed', adminFee:500 },
    { key:'before_3_6', label:'活動前 3～6 日：退 50%', minDays:3, maxDays:6, adminFeeType:'percent', adminFeePercent:50 },
    { key:'within_3', label:'活動前 3 日內或當日：不退費', minDays:-9999, maxDays:2, adminFeeType:'percent', adminFeePercent:100 }
  ]
};

// ── 付款 API 設定（功能保留、尚未啟用，key 請設定於 Cloudflare Workers 環境變數）──
const ECPAY_MERCHANT_ID = 'YOUR_ECPAY_MERCHANT_ID';
const ECPAY_HASH_KEY    = 'YOUR_ECPAY_HASH_KEY';
const ECPAY_HASH_IV     = 'YOUR_ECPAY_HASH_IV';
const ECPAY_API_URL     = 'https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5';

const LINEPAY_CHANNEL_ID = 'YOUR_LINEPAY_CHANNEL_ID';
const LINEPAY_SECRET     = 'YOUR_LINEPAY_SECRET';
const LINEPAY_API_URL    = 'https://api-pay.line.me';
const WORKER_PUBLIC_URL  = 'https://2bl-v7.ndiangrace.workers.dev';

// ── SECTION 2: 工具函式 ──────────────────────────────────────────

// ── 租戶解析：從 GET params 或 POST body 取得 tenantId ──────────
function getTenantId(p) {
  // p 可能是 URL searchParams 或 POST body
  // M-02：缺少 tenant 回傳 null，不允許 fallback 至任何預設值
  const t = p && (p.tenant || p.tenantId || p.tenant_id);
  if (!t) return null;
  const clean = String(t).trim().toLowerCase().replace(/[^a-z0-9_-]/g, '');
  return clean || null;
}

// ── JWT / Token 安全層（Google OAuth 升級）──────────────────────
// JWT_SECRET 必須來自環境變數，不得有任何預設值
function jwtSecret(env) {
  if (!env.JWT_SECRET) throw new Error('JWT_SECRET 環境變數未設定，請於 Cloudflare Workers Secrets 設定');
  return env.JWT_SECRET;
}

// 相容舊 token 格式（過渡期，90 天後可移除）
function authSecret(env) {
  if (!env.AUTH_SECRET) throw new Error('AUTH_SECRET 環境變數未設定');
  return env.AUTH_SECRET;
}
// makeToken 保留供舊路徑相容，新路徑全用 signAdminJwt
function makeToken(email, tenantId, env) {
  return md5(email + tenantId + authSecret(env));
}

// ── HS256 JWT 實作（Web Crypto API）──
async function signAdminJwt(payload, env) {
  const secret = jwtSecret(env);
  const encoder = new TextEncoder();
  const keyData = encoder.encode(secret);
  const key = await crypto.subtle.importKey('raw', keyData, { name:'HMAC', hash:'SHA-256' }, false, ['sign']);
  const header = btoa(JSON.stringify({ alg:'HS256', typ:'JWT' })).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
  const body = btoa(unescape(encodeURIComponent(JSON.stringify(payload)))).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
  const sig = await crypto.subtle.sign('HMAC', key, encoder.encode(`${header}.${body}`));
  const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sig))).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
  return `${header}.${body}.${sigB64}`;
}

async function verifyAdminJwt(token, env) {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const secret = jwtSecret(env);
    const encoder = new TextEncoder();
    const keyData = encoder.encode(secret);
    const key = await crypto.subtle.importKey('raw', keyData, { name:'HMAC', hash:'SHA-256' }, false, ['verify']);
    const sigBytes = Uint8Array.from(atob(parts[2].replace(/-/g,'+').replace(/_/g,'/')), c=>c.charCodeAt(0));
    const valid = await crypto.subtle.verify('HMAC', key, sigBytes, encoder.encode(`${parts[0]}.${parts[1]}`));
    if (!valid) return null;
    let _raw = atob(parts[1].replace(/-/g,'+').replace(/_/g,'/'));
    let _str; try { _str = decodeURIComponent(escape(_raw)); } catch(e) { _str = _raw; }
    const payload = JSON.parse(_str);
    if (payload.expires_at && Date.now() > payload.expires_at) return null; // 已過期
    return payload;
  } catch(e) { return null; }
}

// 簽發後台 admin JWT（30 天有效）
async function issueAdminToken(staffRow, tenantId, env) {
  const now = Date.now();
  const payload = {
    iss: '2BL-V8',
    sub: staffRow.id || staffRow.email,
    email: staffRow.email,
    tenant_id: tenantId,
    staff_id: staffRow.id || '',
    role: staffRow.role || 'organizer_admin',
    normalized_role: staffRow.normalized_role || staffRow.role || '',
    limit_sessions: staffRow.limit_sessions || '',
    display_name: (staffRow.name || staffRow.display_name || '').replace(/[^\x00-\x7F]/g, ''),
    issued_at: now,
    expires_at: now + 30 * 24 * 60 * 60 * 1000,  // 30 天
  };
  return signAdminJwt(payload, env);
}

// 簽發前台會員 JWT（30 天有效）
async function issueMemberToken(memberInfo, env) {
  const now = Date.now();
  const payload = {
    iss: '2BL-V8',
    type: 'member',
    sub: memberInfo.google_sub || memberInfo.email,
    email: memberInfo.email,
    google_sub: memberInfo.google_sub || '',
    display_name: (memberInfo.display_name || '').replace(/[^\x00-\x7F]/g, ''),
    avatar_url: memberInfo.avatar_url || '',
    issued_at: now,
    expires_at: now + 30 * 24 * 60 * 60 * 1000,  // 30 天
  };
  return signAdminJwt(payload, env);
}

// 檢查 tenant 是否被鎖定
async function checkTenantLocked(env, tenantId) {
  try {
    const rows = await dbGet(env, 'tenants', `id=eq.${tenantId}&select=is_locked,locked_reason,plan_type,trial_end_at`);
    const t = rows[0];
    if (!t) return { locked: false };
    if (t.is_locked) return { locked: true, reason: t.locked_reason || '帳號已鎖定' };
    // 檢查試用是否到期
    if (t.plan_type === 'trial' && t.trial_end_at) {
      if (new Date(t.trial_end_at) < new Date()) {
        return { locked: true, reason: '試用期已結束，請續費以繼續使用' };
      }
    }
    return { locked: false };
  } catch(e) { return { locked: false }; }
}

// 驗證 admin token（優先 JWT，回退舊 makeToken 格式相容）
async function verifyAdminToken(token, email, tenantId, env) {
  if (!token || !email) return null;
  // 新格式：JWT
  if (token.includes('.')) {
    const payload = await verifyAdminJwt(token, env);
    if (!payload) return null;
    if (payload.email !== email) return null;
    // platform_super_admin 不受 tenant 限制
    if (payload.normalized_role === 'platform_super_admin' || payload.role === 'platform_super_admin') return payload;
    if (payload.tenant_id !== tenantId) return null;
    return payload;
  }
  // 舊格式相容（過渡期）：重新查 DB 驗證
  const expected = makeToken(email, tenantId, env);
  const expectedPlatform = makeToken(email, 'platform', env);
  if (token !== expected && token !== expectedPlatform) return null;
  return { email, tenant_id: tenantId, role: '', legacy: true };
}

function genId(prefix) {
  // H-04：改用 crypto.randomUUID，移除 4 碼尾碼碰撞風險
  return `${prefix}_${crypto.randomUUID().replace(/-/g, '').slice(0, 20)}`;
}
function isPaidStatus(v) {
  return String(v || '').indexOf('已繳費') >= 0;
}
function safeNum(v) {
  const n = Number(v);
  return isNaN(n) || n < 0 ? 0 : n;
}
function isCapacityInactiveTransferStatus(v) {
  return ['退費中','已退費','refund_pending','refunded','申請退費'].includes(String(v || ''));
}
function isCapacityInactiveRegistrationStatus(v) {
  return ['cancelled','refunded'].includes(String(v || ''));
}
function isCapacityInactiveReviewStatus(v) {
  return ['已取消','不錄取','未錄取'].includes(String(v || ''));
}
function isActiveForCapacity(reg) {
  if (!reg) return false;
  if (isCapacityInactiveRegistrationStatus(reg.registration_status)) return false;
  if (isCapacityInactiveReviewStatus(reg.review_status)) return false;
  if (isCapacityInactiveTransferStatus(reg.transfer_status)) return false;
  return true;
}
// M-01：adjustSessionCurrentCount 改用原子 RPC（防並發）
// delta > 0 = claim（報名），delta < 0 = release（取消/退費）
async function adjustSessionCurrentCount(env, tenantId, sessionId, delta) {
  if (!sessionId || !delta) return;
  if (delta > 0) {
    await dbRpc(env, 'claim_session_slot', { p_tenant_id: tenantId, p_session_id: sessionId, p_stall_count: delta });
  } else {
    await dbRpc(env, 'release_session_slot', { p_tenant_id: tenantId, p_session_id: sessionId, p_stall_count: Math.abs(delta) });
  }
}
async function writeAuditLog(env, tenantId, actorEmail, actorRole, action, targetTable, targetId, beforeJson, afterJson, metaJson) {
  try {
    await dbInsert(env, 'audit_logs', {
      id: genId('AUD'),
      tenant_id: tenantId,
      actor_email: actorEmail || '',
      actor_role: actorRole || '',
      action,
      target_table: targetTable || '',
      target_id: targetId || '',
      before_json: beforeJson || {},
      after_json: afterJson || {},
      meta_json: metaJson || {},
      created_at: nowIso(),
    });
  } catch(e) {
    console.error('audit log skipped', e && e.message ? e.message : e);
  }
}
function safeJson(str, fallback) {
  if (str === null || str === undefined) return fallback;
  if (typeof str !== 'string') return str;  // 已是 object/array，直接回傳
  if (!str.trim()) return fallback;
  try { return JSON.parse(str); } catch { return fallback; }
}
function getDisplayName(name, brand, sessionType) {
  const useBrand = ['市集場次', '通路寄賣'].includes(sessionType || '');
  return (useBrand && brand) ? brand : (name || brand || '您');
}
function nowIso() { return new Date().toISOString(); }
function nowTaipeiText() { return new Date().toLocaleString('zh-TW', {timeZone:'Asia/Taipei', hour12:false}); }

// 不可抗力三層對象分類（由後端 DB 狀態決定，前台不自行判斷）
// 第一層：已錄取＋已付款 or 已錄取＋付款待確認 → 可選延期或退費
// 第二層：已錄取未付款 or 待審核 → 只通知，不給選擇
// 第三層：已取消 / 不錄取 / 已退費 / 無有效報名 → 不進入流程
function classifyForceLayer(reg) {
  const rs = String(reg.review_status || '');
  const ps = String(reg.payment_status || '');
  const regSt = String(reg.registration_status || '');
  const ts = String(reg.transfer_status || '');
  // 第三層
  if (['已取消'].includes(rs)) return 3;
  if (['不錄取', '未錄取'].includes(rs)) return 3;
  if (['cancelled', 'refunded'].includes(regSt)) return 3;
  if (['已退費', 'refunded'].includes(ts)) return 3;
  // 第一層
  if (rs === '已錄取' && (isPaidStatus(ps) || ps === '待確認')) return 1;
  // 第二層
  if (rs === '已錄取' || rs === '待審核') return 2;
  return 3;
}
function cleanEventId(v) {
  const s = String(v ?? '').trim();
  if (!s || s === '0' || s.toLowerCase() === 'null' || s.toLowerCase() === 'undefined') return null;
  return s;
}

// ── SECTION 3: MD5（Token 驗證）────────────────────────────────
function md5(inputStr) {
  function safeAdd(x, y) {
    const lsw = (x & 0xFFFF) + (y & 0xFFFF);
    return (((x >> 16) + (y >> 16) + (lsw >> 16)) << 16) | (lsw & 0xFFFF);
  }
  const rol = (n, c) => (n << c) | (n >>> (32 - c));
  const F = (a,b,c,d,x,s,t) => safeAdd(rol(safeAdd(safeAdd(a,(b&c)|(~b&d)),safeAdd(x,t)),s),b);
  const G = (a,b,c,d,x,s,t) => safeAdd(rol(safeAdd(safeAdd(a,(b&d)|(c&~d)),safeAdd(x,t)),s),b);
  const H = (a,b,c,d,x,s,t) => safeAdd(rol(safeAdd(safeAdd(a,b^c^d),safeAdd(x,t)),s),b);
  const I = (a,b,c,d,x,s,t) => safeAdd(rol(safeAdd(safeAdd(a,c^(b|~d)),safeAdd(x,t)),s),b);
  const bytes = new TextEncoder().encode(inputStr);
  const len = bytes.length;
  const nWords = ((len + 72) >> 6) << 4;
  const w = new Int32Array(nWords);
  for (let j = 0; j < len; j++) w[j >> 2] |= bytes[j] << ((j & 3) << 3);
  w[len >> 2] |= 0x80 << ((len & 3) << 3);
  w[nWords - 2] = len * 8;
  let a = 0x67452301, b = 0xEFCDAB89, c = 0x98BADCFE, d = 0x10325476;
  for (let j = 0; j < nWords; j += 16) {
    const [A,B,C,D] = [a,b,c,d];
    a=F(a,b,c,d,w[j+0],7,-680876936);   d=F(d,a,b,c,w[j+1],12,-389564586);
    c=F(c,d,a,b,w[j+2],17,606105819);   b=F(b,c,d,a,w[j+3],22,-1044525330);
    a=F(a,b,c,d,w[j+4],7,-176418897);   d=F(d,a,b,c,w[j+5],12,1200080426);
    c=F(c,d,a,b,w[j+6],17,-1473231341); b=F(b,c,d,a,w[j+7],22,-45705983);
    a=F(a,b,c,d,w[j+8],7,1770035416);   d=F(d,a,b,c,w[j+9],12,-1958414417);
    c=F(c,d,a,b,w[j+10],17,-42063);     b=F(b,c,d,a,w[j+11],22,-1990404162);
    a=F(a,b,c,d,w[j+12],7,1804603682);  d=F(d,a,b,c,w[j+13],12,-40341101);
    c=F(c,d,a,b,w[j+14],17,-1502002290);b=F(b,c,d,a,w[j+15],22,1236535329);
    a=G(a,b,c,d,w[j+1],5,-165796510);   d=G(d,a,b,c,w[j+6],9,-1069501632);
    c=G(c,d,a,b,w[j+11],14,643717713);  b=G(b,c,d,a,w[j+0],20,-373897302);
    a=G(a,b,c,d,w[j+5],5,-701558691);   d=G(d,a,b,c,w[j+10],9,38016083);
    c=G(c,d,a,b,w[j+15],14,-660478335); b=G(b,c,d,a,w[j+4],20,-405537848);
    a=G(a,b,c,d,w[j+9],5,568446438);    d=G(d,a,b,c,w[j+14],9,-1019803690);
    c=G(c,d,a,b,w[j+3],14,-187363961);  b=G(b,c,d,a,w[j+8],20,1163531501);
    a=G(a,b,c,d,w[j+13],5,-1444681467); d=G(d,a,b,c,w[j+2],9,-51403784);
    c=G(c,d,a,b,w[j+7],14,1735328473);  b=G(b,c,d,a,w[j+12],20,-1926607734);
    a=H(a,b,c,d,w[j+5],4,-378558);      d=H(d,a,b,c,w[j+8],11,-2022574463);
    c=H(c,d,a,b,w[j+11],16,1839030562); b=H(b,c,d,a,w[j+14],23,-35309556);
    a=H(a,b,c,d,w[j+1],4,-1530992060);  d=H(d,a,b,c,w[j+4],11,1272893353);
    c=H(c,d,a,b,w[j+7],16,-155497632);  b=H(b,c,d,a,w[j+10],23,-1094730640);
    a=H(a,b,c,d,w[j+13],4,681279174);   d=H(d,a,b,c,w[j+0],11,-358537222);
    c=H(c,d,a,b,w[j+3],16,-722521979);  b=H(b,c,d,a,w[j+6],23,76029189);
    a=H(a,b,c,d,w[j+9],4,-640364487);   d=H(d,a,b,c,w[j+12],11,-421815835);
    c=H(c,d,a,b,w[j+15],16,530742520);  b=H(b,c,d,a,w[j+2],23,-995338651);
    a=I(a,b,c,d,w[j+0],6,-198630844);   d=I(d,a,b,c,w[j+7],10,1126891415);
    c=I(c,d,a,b,w[j+14],15,-1416354905);b=I(b,c,d,a,w[j+5],21,-57434055);
    a=I(a,b,c,d,w[j+12],6,1700485571);  d=I(d,a,b,c,w[j+3],10,-1894986606);
    c=I(c,d,a,b,w[j+10],15,-1051523);   b=I(b,c,d,a,w[j+1],21,-2054922799);
    a=I(a,b,c,d,w[j+8],6,1873313359);   d=I(d,a,b,c,w[j+15],10,-30611744);
    c=I(c,d,a,b,w[j+6],15,-1560198380); b=I(b,c,d,a,w[j+13],21,1309151649);
    a=I(a,b,c,d,w[j+4],6,-145523070);   d=I(d,a,b,c,w[j+11],10,-1120210379);
    c=I(c,d,a,b,w[j+2],15,718787259);   b=I(b,c,d,a,w[j+9],21,-343485551);
    a=safeAdd(a,A); b=safeAdd(b,B); c=safeAdd(c,C); d=safeAdd(d,D);
  }
  const w2h = n => [(n)&0xFF,(n>>8)&0xFF,(n>>16)&0xFF,(n>>24)&0xFF]
    .map(x => ('0'+x.toString(16)).slice(-2)).join('');
  return w2h(a)+w2h(b)+w2h(c)+w2h(d);
}

// ── SECTION 4: 加密工具（ECPay / LINE Pay）──────────────────────
async function sha256Hex(str) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('').toUpperCase();
}
async function hmacSha256Base64(secret, message) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), {name:'HMAC',hash:'SHA-256'}, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(message));
  return btoa(String.fromCharCode(...new Uint8Array(sig)));
}

// ── SECTION 5: CORS / Response ──────────────────────────────────
function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Cache-Control',
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
    'Pragma': 'no-cache',
    'Expires': '0',
  };
}
const jsonOk  = data => new Response(JSON.stringify(data), {status:200, headers:corsHeaders()});
const jsonErr = msg  => new Response(JSON.stringify({error:msg}), {status:200, headers:corsHeaders()});

// ── SECTION 6: Supabase 查詢工具 ────────────────────────────────
function supabaseServiceRoleKey(env) {
  return env.SUPABASE_SERVICE_ROLE_KEY || env.SUPABASE_KEY;
}
function sbHdr(env) {
  const key = supabaseServiceRoleKey(env);
  return {
    'apikey': key,
    'Authorization': `Bearer ${key}`,
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };
}
async function dbGet(env, table, qs) {
  const res = await fetch(`${env.SUPABASE_URL}/rest/v1/${table}${qs?'?'+qs:''}`, {headers:sbHdr(env), cache:'no-store'});
  if (!res.ok) throw new Error(`DB GET ${table}: ${await res.text()}`);
  return res.json();
}
async function dbInsert(env, table, data) {
  const res = await fetch(`${env.SUPABASE_URL}/rest/v1/${table}`, {
    method:'POST', body:JSON.stringify(data),
    headers:{...sbHdr(env),'Prefer':'return=representation'}, cache:'no-store',
  });
  if (!res.ok) throw new Error(`DB INSERT ${table}: ${await res.text()}`);
  const r = await res.json();
  return Array.isArray(r) ? r[0] : r;
}
async function dbUpdate(env, table, qs, data) {
  const res = await fetch(`${env.SUPABASE_URL}/rest/v1/${table}?${qs}`, {
    method:'PATCH', body:JSON.stringify(data), headers:sbHdr(env), cache:'no-store',
  });
  if (!res.ok) throw new Error(`DB UPDATE ${table}: ${await res.text()}`);
  return true;
}
async function dbDelete(env, table, qs) {
  const res = await fetch(`${env.SUPABASE_URL}/rest/v1/${table}?${qs}`, {
    method:'DELETE', headers:sbHdr(env), cache:'no-store',
  });
  if (!res.ok) throw new Error(`DB DELETE ${table}: ${await res.text()}`);
  return true;
}

// M-01：RPC 呼叫（用於原子名額操作）
async function dbRpc(env, fnName, params) {
  const res = await fetch(`${env.SUPABASE_URL}/rest/v1/rpc/${fnName}`, {
    method:'POST',
    body: JSON.stringify(params),
    headers: {...sbHdr(env), 'Content-Type':'application/json'},
    cache: 'no-store',
  });
  if (!res.ok) {
    const errText = await res.text().catch(()=>'');
    throw new Error(`DB RPC ${fnName}: ${errText}`);
  }
  return res.json();
}

// ── SECTION 7: 管理員驗證 ───────────────────────────────────────
async function verifyStaff(env, email, token, tenantId, requiredRole='', sessionId='') {
  if (!email || !token) return false;
  const tid = (typeof tenantId === 'string' && tenantId) ? tenantId : null;
  if (!tid) return false;

  // 驗證 token（JWT 或舊格式）
  const jwtPayload = await verifyAdminToken(token, email, tid, env);
  if (!jwtPayload) return false;

  const role = jwtPayload.normalized_role || jwtPayload.role || '';
  const limitSessions = jwtPayload.limit_sessions || '';

  // platform_super_admin 直通（跨 tenant）
  if (role === 'platform_super_admin') return true;

  // tenant 隔離：token 內的 tenant_id 才是準的，前端傳來的不可信
  if (jwtPayload.tenant_id !== tid && !jwtPayload.legacy) return false;

  // 舊格式回退：查 DB 確認
  if (jwtPayload.legacy) {
    const platformRows = await dbGet(env, 'platform_staff', `email=eq.${encodeURIComponent(email)}&is_active=eq.true&select=*`).catch(()=>[]);
    if (platformRows[0]?.role === 'platform_super_admin') return true;
    const rows = await dbGet(env, 'staff', `tenant_id=eq.${tid}&email=eq.${encodeURIComponent(email)}&select=*`);
    const staff = rows[0];
    if (!staff) return false;
    const staffRole = staff.role || '';
    if (staffRole === 'organizer_owner' || staffRole === 'platform_super_admin') return true;
    if (requiredRole === 'superadmin') return false;
    if (requiredRole) {
      const perms = safeJson(staff.perms_json, {});
      if (!perms[requiredRole]) return false;
    }
    const ls = staff.limit_sessions || '';
    if (sessionId && ls) {
      const allowed = String(ls).split(',').map(s=>s.trim()).filter(Boolean);
      if (allowed.length && !allowed.includes(sessionId)) return false;
    }
    return true;
  }

  // JWT 格式：從 payload 取角色
  const normalizedRole = role;
  const ownerRoles = ['organizer_owner', 'platform_super_admin', 'organizer_admin'];

  if (requiredRole === 'superadmin') {
    return normalizedRole === 'organizer_owner' || normalizedRole === 'platform_super_admin';
  }

  if (requiredRole === 'finance') {
    const allowed = ['organizer_owner','platform_super_admin','organizer_admin','finance_admin'];
    return allowed.includes(normalizedRole);
  }

  if (requiredRole === 'checkin') {
    const allowed = ['organizer_owner','platform_super_admin','organizer_admin','session_admin','onsite_staff'];
    return allowed.includes(normalizedRole);
  }

  if (requiredRole === 'review' || requiredRole === 'sessions' || requiredRole === 'events') {
    const allowed = ['organizer_owner','platform_super_admin','organizer_admin','session_admin','finance_admin'];
    return allowed.includes(normalizedRole);
  }

  if (requiredRole === 'announce') {
    const allowed = ['organizer_owner','platform_super_admin','organizer_admin'];
    return allowed.includes(normalizedRole);
  }

  // 有 sessionId 限制：session_admin / onsite_staff 只能看授權場次
  if (sessionId && limitSessions) {
    if (['session_admin','onsite_staff'].includes(normalizedRole)) {
      const allowed = String(limitSessions).split(',').map(s=>s.trim()).filter(Boolean);
      if (allowed.length && !allowed.includes(sessionId)) return false;
    }
  }

  return true; // 通過基本驗證，無特殊 requiredRole
}

// ── SECTION 8: Session 格式化 / 費用計算 ────────────────────────
function calcLimit(s) {
  const dates = safeJson(s.dates_json, []);
  if (!dates.length) return safeNum(s.limit_count);
  const hasLimit = dates.some(d => Number(d.limit) > 0);
  if (!hasLimit) return 0;
  return dates.reduce((sum, d) => sum + (Number(d.limit) || 0), 0);
}
function formatSession(s) {
  return {
    id: s.id, eventId: s.event_id,
    name: s.name, type: s.type, region: s.region || '',
    dates: safeJson(s.dates_json, []),
    venue: s.venue, fee: safeNum(s.fee), deposit: safeNum(s.deposit),
    limit: calcLimit(s), maxStalls: safeNum(s.max_stalls),
    count: safeNum(s.current_count), status: s.status,
    needReview: s.need_review === true || s.need_review === 'true',
    modules: safeJson(s.modules_json, {}),
    equip: safeJson(s.equip_json, {}),
    customFields: safeJson(s.custom_fields_json, []),
    addons: safeJson(s.addons_json, []),
    invoiceTax: safeJson(s.invoice_tax_json, {stall:true,equip:false,extra:false}),
    refundRules: safeJson(s.refund_rules_json, null),
    basicEquip: s.basic_equip || '',
    theme: s.theme || '', organizer: s.organizer || '', coorg: s.co_organizer || '',
    portals: s.portals ? String(s.portals).split(',').map(x=>x.trim()).filter(Boolean) : [],
    cover: s.cover_url || '', desc: s.description || '',
    stallList: safeJson(s.stall_list_json, []),
    assignedStaff: s.assigned_staff ? String(s.assigned_staff).split(',').filter(Boolean) : [],
    forceCancel: s.force_cancel || false,
    forceCancelTargetId: s.force_cancel_target_id || '',
    forceCancelDeadline: s.force_cancel_deadline || '',
    // 不可抗力模組欄位
    forceCancelled: s.force_cancelled || false,
    forceCancelReasonCode: s.force_cancel_reason_code || '',
    forceCancelReasonLabel: s.force_cancel_reason_label || '',
    forceCancelNote: s.force_cancel_note || '',
    forceCancelledAt: s.force_cancelled_at || '',
    forceMode: s.force_mode || '',
    forceTransferTargetSessionId: s.force_transfer_target_session_id || '',
    forceChoiceDeadline: s.force_choice_deadline || '',
    forceNoticeSentAt: s.force_notice_sent_at || '',
    createdAt: s.created_at,
    // ── 合約同意設定 ──────────────────────────────────
    agreementRequired:  s.agreement_required !== false,
    agreementTitle:     s.agreement_title   || '',
    agreementContent:   s.agreement_content || '',
    agreementVersion:   s.agreement_version || '',
    agreementUpdatedAt: s.agreement_updated_at || '',
  };
}
function calcFee(ses, selectedDates, stallCount) {
  const dates = safeJson(ses.dates_json, []);
  const baseFee = safeNum(ses.fee);
  const stalls = Math.max(parseInt(stallCount)||1, 1); // 無上限，由後台 maxStalls 控制
  if (dates.length > 1 && selectedDates && selectedDates.length > 0) {
    const allSelected = dates.every(d => selectedDates.includes(d.date));
    if (allSelected && baseFee > 0) return baseFee * stalls;
    return selectedDates.reduce((sum, sd) => {
      const def = dates.find(d => d.date === sd);
      return sum + (def ? (Number(def.fee) || 0) : 0);
    }, 0) * stalls;
  }
  if (dates.length === 1) return (Number(dates[0].fee) || baseFee || 0) * stalls;
  return baseFee * stalls;
}
function effectiveEquipIncl(key, def, basicEquip) {
  const raw = Number(def?.incl)||0;
  if (raw <= 0) return 0;
  const name = String(key||'');
  const basic = String(basicEquip||'').trim();
  const isTableOrChair = name.includes('桌') || name.includes('椅');
  if (!isTableOrChair) return raw;
  if (!basic) return 0;
  if (/不含|無附|無提供|沒有|不提供|未提供/.test(basic)) return 0;
  const mentionsThis = name.includes('桌') ? basic.includes('桌') : (basic.includes('椅') || basic.includes('椅子'));
  return mentionsThis ? raw : 0;
}
function calcEquipTotal(equip, equipJsonStr, stallCount, basicEquip='') {
  let total = 0;
  const stalls = Number(stallCount) || 1;
  try {
    const def = typeof equipJsonStr === 'string' ? JSON.parse(equipJsonStr||'{}') : (equipJsonStr||{});
    Object.entries(equip||{}).forEach(([k,qty]) => {
      if (def[k]?.open) {
        const incl = effectiveEquipIncl(k, def[k], basicEquip) * stalls;
        const extra = Math.max(0, (Number(qty)||0) - incl);
        total += (Number(def[k].price)||0) * extra;
      }
    });
  } catch {}
  return total;
}

// ── SECTION 9: Email 工具（Resend API）─────────────────────────
async function sendEmail(env, to, subject, htmlBody, tenantCtx) {
  if (!to) return {ok:false, error:'missing recipient'};
  if (!env.RESEND_KEY) {
    console.error('Email skipped: RESEND_KEY missing');
    return {ok:false, error:'RESEND_KEY missing'};
  }
  const emailFrom    = (tenantCtx && tenantCtx.emailFrom)    || FALLBACK_EMAIL_FROM;
  const emailReplyTo = (tenantCtx && tenantCtx.emailReplyTo) || FALLBACK_EMAIL_REPLY;
  const ctrl = new AbortController();
  const timer = setTimeout(()=>ctrl.abort(), 8000);
  try {
    const res = await fetch('https://api.resend.com/emails', {
      method:'POST',
      headers:{'Authorization':`Bearer ${env.RESEND_KEY}`,'Content-Type':'application/json'},
      body:JSON.stringify({from:emailFrom, to:[to], subject, html:htmlBody, reply_to:emailReplyTo}),
      signal:ctrl.signal,
    });
    const txt = await res.text().catch(()=>'');
    if (!res.ok) {
      console.error('Email failed:', res.status, txt);
      return {ok:false, error:txt || ('HTTP '+res.status)};
    }
    return {ok:true};
  } catch(e) {
    console.error('Email failed:', e && e.message ? e.message : String(e));
    return {ok:false, error:e && e.name==='AbortError' ? 'timeout' : (e.message||String(e))};
  } finally {
    clearTimeout(timer);
  }
}
// emailWrap：依租戶動態顯示品牌名稱與頁尾
function emailWrap(content, tenantCtx) {
  const name    = (tenantCtx && tenantCtx.name)    || FALLBACK_TENANT_NAME;
  const footer  = (tenantCtx && tenantCtx.footer)  || (name + '　All rights reserved.');
  const color   = (tenantCtx && tenantCtx.color)   || '#2d6a4f';
  return `<div style="font-family:'Noto Sans TC',sans-serif;max-width:600px;margin:0 auto;padding:32px;background:#fafaf8;border-radius:12px">
<div style="text-align:center;margin-bottom:24px"><h2 style="color:${color};font-size:20px;margin:0">${name}</h2></div>
${content}
<hr style="border:none;border-top:1px solid #e0e0e0;margin:24px 0">
<p style="font-size:12px;color:#aaa;text-align:center">${footer}</p>
</div>`;
}
function memberUrl(regId, tenantCtx) {
  const base = (tenantCtx && tenantCtx.siteUrl) || FALLBACK_SITE_URL;
  const tid = (tenantCtx && tenantCtx.id) || '';  // M-02：id 缺漏時不輸出 'undefined' 字串
  const sep = base.includes('?') ? '&' : '?';
  return base + sep + 'member=1&tenant=' + encodeURIComponent(tid) + (regId ? '&pay='+encodeURIComponent(regId) : '');
}
function emailBtn(label, href, bg, color, extraStyle='') {
  return `<a href="${href}" style="display:block;background:${bg};color:${color};border-radius:10px;text-decoration:none;font-weight:700;font-size:13px;line-height:1.35;text-align:center;padding:11px 10px;white-space:nowrap;${extraStyle}">${label}</a>`;
}
function emailButtonRow(leftHtml, rightHtml) {
  return `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:14px 0;border-collapse:collapse"><tr><td width="50%" style="padding:0 5px 0 0">${leftHtml}</td><td width="50%" style="padding:0 0 0 5px">${rightHtml}</td></tr></table>`;
}
function lineBtn(tenantCtx) {
  const url = (tenantCtx && tenantCtx.lineUrl) || '';
  if (!url) return '';   // tenant 未設定 LINE 時不顯示按鈕，不 fallback
  return `<p style="text-align:center;margin:12px 0"><a href="${url}" style="background:#06C755;color:#fff;padding:10px 20px;border-radius:10px;text-decoration:none;font-weight:700;font-size:13px">加入官方 LINE</a></p>`;
}

function normalizeEquipName(k) {
  const name = String(k || '').trim();
  if (name === '椅子') return '椅';
  return name;
}
function equipSummaryFromJson(equip) {
  const eq = safeJson(equip, {});
  return Object.entries(eq)
    .filter(([k,v]) => Number(v) > 0)
    .map(([k,v]) => `${normalizeEquipName(k)} ×${Number(v)}`)
    .join('、');
}
function buildPaymentLineCardText(reg, sesName, method, amount) {
  const brand = String(reg.brand_name || reg.brand || '').trim();
  const name = String(reg.name || reg.contact_name || reg.display_name || '').trim();
  const who = brand && name ? `${brand}／${name}` : (brand || name || '未填名稱');
  const stallCount = Math.max(Number(reg.stall_count || 1), 1);
  const equipText = equipSummaryFromJson(reg.equipment_json);
  const stallEquipLine = `攤位 ${stallCount} 攤${equipText ? '、' + equipText : ''}`;
  const deposit = Number(reg.deposit || 0);
  const lines = [
    sesName || reg.session_name || '場次',
    who,
    stallEquipLine,
  ];
  if (deposit > 0) lines.push(`保證金 NT$${deposit.toLocaleString()}`);
  lines.push('');
  lines.push(`付款金額：NT$${Number(amount || reg.amount || 0).toLocaleString()}（${method || reg.payment_method || '付款'}）`);
  return lines.join('\n');
}


// ① 報名確認（AA8 正式版）
async function mailRegConfirm(env, email, displayName, sesName, regId, total, stallCount, selectedDates, equip, tenantCtx=null) {
  const datesText = selectedDates?.length ? selectedDates.join('、') : '';
  const equipText = equipSummaryFromJson(equip);
  await sendEmail(env, email, `【${sesName}】報名確認`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<p>我們已收到您的申請，請耐心等候審核通知。</p>
<p style="font-weight:700;color:#2d6a4f;margin:16px 0 8px">━━━ 📋 報名資料 ━━━</p>
<p>場次：<strong>${sesName}</strong></p>
${datesText?`<p>報名日期：${datesText}</p>`:''}
<p>攤位數：${stallCount||1} 攤</p>
${equipText?`<p>設備：${equipText}</p>`:''}
${total>0?`<p>錄取後預計繳費金額：<strong style="color:#2d6a4f">NT$ ${Number(total).toLocaleString()}</strong></p>`:''}
<p>━━━━━━━━━━━━━━</p>
<p>目前狀態：等待主辦單位審核。</p>
<p>審核完成後，系統將以 Email 通知結果。</p>
<p>請先加入官方 LINE，告知品牌名稱，方便核對報名資料。</p>
${emailButtonRow(
  ((tenantCtx&&tenantCtx.lineUrl)?emailBtn('加入官方 LINE', tenantCtx.lineUrl, '#06C755', '#fff'):''),
  emailBtn('查看報名紀錄', memberUrl(regId, tenantCtx), '#e8f7ee', '#2d6a4f', 'border:1.5px solid #2d6a4f;')
)}
`, tenantCtx), tenantCtx);
}

// ② 錄取通知（AA8 正式版：只保留一顆按鈕）
async function mailApproval(env, email, displayName, sesName, regId, fee, stallCount, selectedDates, equip, sesEquipJson, tenantCtx=null) {
  const datesHtml = selectedDates?.length ? `<div style="font-size:13px;color:#555;margin:4px 0">報名日期：${selectedDates.join('、')}</div>` : '';
  const equipHtml = equipSummaryFromJson(equip) ? `<div style="font-size:13px;color:#555;margin:4px 0">設備：${equipSummaryFromJson(equip)}</div>` : '';
  const dl = new Date(); dl.setHours(dl.getHours()+48);
  const dlStr = `${dl.getMonth()+1}/${dl.getDate()} ${dl.getHours()}:00`;
  await sendEmail(env, email, `【${sesName}】恭喜您通過審核！`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，恭喜！您已成功錄取 <strong>${sesName}</strong>。</p>
<div style="background:#f8f8f8;border-radius:10px;padding:14px;margin:14px 0;font-size:13px">
  <div style="font-weight:700;color:#2d6a4f;margin-bottom:8px">📋 報名資料</div>
  <div style="color:#555">場次：<strong>${sesName}</strong></div>
  ${datesHtml}
  <hr style="border:none;border-top:1px solid #e0e0e0;margin:8px 0">
  <div style="color:#555">攤位數：${stallCount||1} 攤</div>
  ${equipHtml}
  ${fee>0?`<div style="color:#2d6a4f;font-weight:700;margin-top:4px;font-size:14px">應繳金額：NT$ ${Number(fee).toLocaleString()}</div>`:`<div style="color:#2d6a4f;font-weight:700">本場次免費，名額已保留！</div>`}
</div>
${fee>0?`
<div style="background:#fff3f3;border-radius:10px;padding:12px 14px;margin:14px 0;font-size:13px;color:#c0392b">
  ⚠️ 請於 <strong>${dlStr}</strong> 前完成繳費，逾期將自動釋出位置。
</div>
${emailBtn('前往我的紀錄繳費', memberUrl(regId, tenantCtx), '#2d6a4f', '#fff')}
`:lineBtn(tenantCtx)}
`, tenantCtx), tenantCtx);
}

// ③ 繳費回報已收到（AA8 正式版）
async function mailPaymentReceived(env, email, displayName, sesName, method, amount, last5, regId, tenantCtx=null) {
  await sendEmail(env, email, `【${sesName}】繳費回報已收到，等待確認中`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<div style="background:#fffbea;border-radius:10px;padding:16px;margin:16px 0;border-left:4px solid #f5a623">
  <p style="font-size:15px;font-weight:700;color:#b7660a;margin-bottom:8px">📬 我們已收到您的繳費回報。</p>
  <div style="font-size:13px;color:#555">場次：<strong>${sesName}</strong></div>
  <div style="font-size:13px;color:#555;margin-top:4px">付款方式：${method||'付款'}</div>
  <div style="font-size:13px;color:#555;margin-top:4px">金額：NT$ ${Number(amount||0).toLocaleString()}</div>
  ${last5?`<div style="font-size:13px;color:#555;margin-top:4px">末五碼：${last5}</div>`:''}
</div>
<p style="font-size:13px;color:#777">這代表付款狀態為「待確認」，不等於已繳費。主辦確認入帳後，將寄送正式繳費確認信。</p>
${emailButtonRow(
  emailBtn('查看報名紀錄', memberUrl(regId, tenantCtx), '#2d6a4f', '#fff'),
  ((tenantCtx&&tenantCtx.lineUrl)?emailBtn('加入官方 LINE', tenantCtx.lineUrl, '#06C755', '#fff'):'')
)}
`, tenantCtx), tenantCtx);
}

// ④ 繳費確認信（AA8 正式版）
async function mailPaymentConfirm(env, email, displayName, sesName, amount, equipStr, stallNo, tenantCtx=null) {
  await sendEmail(env, email, `【${sesName}】繳費確認`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<div style="background:#f0fdf4;border-radius:10px;padding:16px;margin:16px 0">
  <p style="font-size:16px;font-weight:700;color:#2d6a4f;margin-bottom:8px">✅ 付款確認成功！</p>
  <div style="font-size:13px;color:#555">場次：<strong>${sesName}</strong></div>
  <div style="font-size:13px;color:#555;margin-top:4px">繳費金額：<strong>NT$ ${Number(amount||0).toLocaleString()}</strong></div>
  ${equipStr?`<div style="font-size:13px;color:#555;margin-top:4px">設備：${equipStr}</div>`:''}
  ${stallNo?`<div style="font-size:14px;font-weight:700;color:#2d6a4f;margin-top:8px">攤位號碼：${stallNo}</div>`:''}
</div>
${lineBtn(tenantCtx)}
<div style="margin-top:20px;border-top:1px solid #e0e0e0;padding-top:16px">
  <div style="font-weight:700;color:#2d6a4f;margin-bottom:12px;font-size:14px">📌 行前注意事項</div>
  <img src="https://placehold.co/1200x628?text=2BL+V8+Notice" alt="進撤場登記" style="width:100%;border-radius:10px;display:block;margin-bottom:10px">
  <img src="https://placehold.co/1200x628?text=2BL+V8+Rules" alt="市集規範" style="width:100%;border-radius:10px;display:block;margin-bottom:10px">
  <img src="https://placehold.co/1200x628?text=2BL+V8+Refund" alt="退款機制" style="width:100%;border-radius:10px;display:block;margin-bottom:10px">
</div>
`, tenantCtx), tenantCtx);
}

// ⑤ 未錄取通知信（AA8 正式版）
async function mailRejection(env, email, displayName, sesName, tenantCtx=null) {
  await sendEmail(env, email, `【${sesName}】關於您的報名結果`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<p>感謝您報名 <strong>${sesName}</strong>。</p>
<p>很抱歉，本場次未錄取。歡迎報名其他場次，我們期待下次與您相遇。</p>
<p style="text-align:center;margin:20px 0"><a href="${(tenantCtx&&tenantCtx.siteUrl)||FALLBACK_SITE_URL}" style="background:#2d6a4f;color:#fff;padding:14px 28px;border-radius:12px;text-decoration:none;font-weight:700;font-size:15px">報名其他場次</a></p>
${lineBtn(tenantCtx)}
`, tenantCtx), tenantCtx);
}

// ⑥ 未繳費取消通知信（AA8 正式版）
async function mailCancelReg(env, email, displayName, sesName, tenantCtx=null) {
  await sendEmail(env, email, `您報名的【${sesName}】已取消`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<p>您已取消本場報名。</p>
<p>本次尚未完成付款，因此不涉及退費流程。</p>
<p>報名紀錄會保留，日後仍可重新報名。</p>
${emailButtonRow(
  ((tenantCtx&&tenantCtx.lineUrl)?emailBtn('加入官方 LINE', tenantCtx.lineUrl, '#06C755', '#fff'):''),
  emailBtn('查看報名紀錄', memberUrl(null, tenantCtx), '#e8f7ee', '#2d6a4f', 'border:1.5px solid #2d6a4f;')
)}
`, tenantCtx), tenantCtx);
}

// ⑦ 退款申請已收到（AA8 正式版）
async function mailRefundRequestReceived(env, email, displayName, sesName, tenantCtx=null) {
  await sendEmail(env, email, `【${sesName}】退款申請已收到`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<p>我們已收到您的退款申請。</p>
<p>主辦確認後，將依退款規則處理。</p>
${lineBtn(tenantCtx)}
`, tenantCtx), tenantCtx);
}

// ⑧ 退款完成通知信（AA8 正式版）
async function mailRefundConfirm(env, email, displayName, sesName, tenantCtx=null) {
  await sendEmail(env, email, `【${sesName}】退費已完成`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<p>我們已完成您的退費處理。</p>
<p>款項將依實際金流或帳務處理時間退回。</p>
<p>感謝您的支持，期待下次再與您相遇。</p>
${lineBtn(tenantCtx)}
`, tenantCtx), tenantCtx);
}

// ⑨ 逾期未繳費自動取消（AA8 延伸：沿用取消規則）
async function mailAutoCancel(env, email, displayName, sesName, tenantCtx=null) {
  await sendEmail(env, email, `【${sesName}】您的報名已因逾期未繳費自動取消`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<p>您的報名因逾期未繳費自動取消。</p>
<p>本次尚未完成付款，因此不涉及退費流程。若仍想參加，歡迎重新報名。</p>
<p style="text-align:center;margin:20px 0"><a href="${(tenantCtx&&tenantCtx.siteUrl)||FALLBACK_SITE_URL}" style="background:#2d6a4f;color:#fff;padding:14px 28px;border-radius:12px;text-decoration:none;font-weight:700;font-size:15px">重新報名</a></p>
${lineBtn(tenantCtx)}
`, tenantCtx), tenantCtx);
}

// 系統必要保留：繳費期限提醒
async function mailDeadlineReminder(env, email, displayName, sesName, regId, fee, selectedDates, equip, sesEquipJson, tenantCtx=null) {
  await sendEmail(env, email, `【${sesName}】您的報名繳費期限剩12H`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<div style="background:#fff3f3;border-radius:10px;padding:14px;margin:14px 0;font-size:13px;color:#c0392b;font-weight:700">⚠️ 您的報名繳費期限剩12H，未繳費將自動取消，釋出位置。</div>
<p>場次：<strong>${sesName}</strong></p>
<p>應繳金額：<strong>NT$ ${Number(fee||0).toLocaleString()}</strong></p>
${emailBtn('前往我的紀錄繳費', memberUrl(regId, tenantCtx), '#c0392b', '#fff')}
`, tenantCtx), tenantCtx);
}

// 系統必要保留：行前提醒
async function mailPreEventReminder(env, email, displayName, sesName, date, venue, tenantCtx=null) {
  await sendEmail(env, email, `[${(tenantCtx&&tenantCtx.name)||FALLBACK_TENANT_NAME}] 活動提醒  ${sesName} 還有3天！`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<p><strong>${sesName}</strong> 還有 <strong>3天</strong> 就要開始了！</p>
<div style="background:#f0fdf4;border-radius:10px;padding:14px;margin:14px 0;font-size:13px"><div>📅 活動日期：<strong>${date}</strong></div><div>📍 活動地點：<strong>${venue}</strong></div></div>
${lineBtn(tenantCtx)}
`, tenantCtx), tenantCtx);
}

// 系統必要保留：不可抗力取消／延期
async function mailForceCancelChoice(env, email, displayName, sesName, targetSesName, deadline, tenantCtx=null) {
  await sendEmail(env, email, `【${sesName}】因不可抗力取消，請選擇處理方式`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<p>您報名的 <strong>${sesName}</strong> 因不可抗力因素取消，造成不便深感抱歉。</p>
${targetSesName?`<p>我們已安排延期至 <strong>${targetSesName}</strong>，歡迎選擇延期參加。</p>`:''}
<p>請於 <strong>${deadline}</strong> 前至會員中心選擇處理方式。</p>
${emailBtn('前往會員中心選擇', memberUrl(null, tenantCtx), '#2d6a4f', '#fff')}
${lineBtn(tenantCtx)}
`, tenantCtx), tenantCtx);
}
async function mailTransferDiffFee(env, email, displayName, newSesName, newFee, oldFee, tenantCtx=null) {
  await sendEmail(env, email, `【${newSesName}】您的報名已完成延期`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p><p>您的報名已成功延期至 <strong>${newSesName}</strong>。</p>
<p>原場次費用：NT$ ${Number(oldFee||0).toLocaleString()}<br>新場次費用：NT$ ${Number(newFee||0).toLocaleString()}</p>
${emailBtn('查看我的報名紀錄', memberUrl(null, tenantCtx), '#2d6a4f', '#fff')}
`, tenantCtx), tenantCtx);
}
async function mailTransferSameFee(env, email, displayName, newSesName, tenantCtx=null) {
  await sendEmail(env, email, `【${newSesName}】您的報名已完成延期`, emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p><p>您的報名已成功延期至 <strong>${newSesName}</strong>，費用維持不變。</p>
${emailBtn('查看我的報名紀錄', memberUrl(null, tenantCtx), '#2d6a4f', '#fff')}
`, tenantCtx), tenantCtx);
}
async function mailAutoRefund(env, email, displayName, sesName, tenantCtx=null) {
  await mailRefundRequestReceived(env, email, displayName, sesName, tenantCtx);
}

// ───── 不可抗力取消通知信 ─────────────────────────────────────────
async function mailForceCancelNotice(env, email, displayName, sesName, tenantCtx=null) {
  await sendEmail(env, email,
    `【${sesName}】因不可抗力因素取消，請查看處理方式`,
    emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<p>您報名的 <strong>【${sesName}】</strong> 因不可抗力因素取消。</p>
<div style="background:#fff8ed;border-radius:10px;padding:14px;margin:14px 0;border-left:4px solid #f5a623">
  <p style="font-weight:700;color:#92400e;margin:0 0 8px">請至「我的紀錄」查看您的處理方式</p>
  <p style="font-size:13px;color:#555;margin:0">若您的報名已進入付款或付款確認流程，系統將依您的報名狀態提供延期或退費處理選項。</p>
</div>
${emailBtn('前往我的紀錄', memberUrl(null, tenantCtx), '#2d6a4f', '#fff')}
${lineBtn(tenantCtx)}
`, tenantCtx), tenantCtx);
}

// ───── 延期完成信 ─────────────────────────────────────────────────
async function mailForceTransferDone(env, email, displayName, oldSesName, newSesName, paidAmount, tenantCtx=null) {
  await sendEmail(env, email,
    `【${newSesName}】您的報名已完成延期`,
    emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<div style="background:#f0fdf4;border-radius:10px;padding:14px;margin:14px 0">
  <p style="font-size:16px;font-weight:700;color:#2d6a4f;margin:0 0 8px">✅ 已成功延期至 ${newSesName}</p>
  <div style="font-size:13px;color:#555;line-height:1.8">
    <div>原場次：<strong>${oldSesName}</strong>（已因不可抗力取消）</div>
    <div>延期至：<strong>${newSesName}</strong></div>
    ${paidAmount > 0 ? `<div style="margin-top:6px;color:#2d6a4f;font-weight:700">原付款金額 NT$ ${Number(paidAmount).toLocaleString()} 沿用，無需重新付款</div>` : ''}
  </div>
</div>
<p style="font-size:13px;color:#777">無需重新填寫報名資料，攤位數、設備加購等資訊均已保留。</p>
${emailBtn('查看我的報名紀錄', memberUrl(null, tenantCtx), '#2d6a4f', '#fff')}
${lineBtn(tenantCtx)}
`, tenantCtx), tenantCtx);
}

// ───── 退費完成信（不可抗力）───────────────────────────────────────
async function mailForceRefundDone(env, email, displayName, sesName, refundAmount, tenantCtx=null) {
  await sendEmail(env, email,
    `【${sesName}】退費已完成`,
    emailWrap(`
<p>親愛的 <strong>${displayName}</strong>，</p>
<div style="background:#f0fdf4;border-radius:10px;padding:14px;margin:14px 0">
  <p style="font-size:16px;font-weight:700;color:#2d6a4f;margin:0 0 8px">✅ 退費處理完成</p>
  <div style="font-size:13px;color:#555;line-height:1.8">
    <div>場次：<strong>${sesName}</strong></div>
    ${refundAmount > 0 ? `<div>退費金額：<strong>NT$ ${Number(refundAmount).toLocaleString()}</strong></div>` : ''}
    <div>退費依不可抗力退款規則辦理。</div>
  </div>
</div>
<p style="font-size:13px;color:#777">款項將依實際金流或帳務處理時間退回。歡迎報名其他場次，期待下次再與您相遇。</p>
${emailBtn('報名其他場次', (tenantCtx && tenantCtx.siteUrl) || FALLBACK_SITE_URL, '#2d6a4f', '#fff')}
${lineBtn(tenantCtx)}
`, tenantCtx), tenantCtx);
}

// 管理員邀請
async function mailStaffInvite(env, email, name, role, perms, limitSessions, tenantCtx=null) {
  const labels = {review:'審核報名',checkin:'現場報到',sessions:'管理場次',events:'管理活動',finance:'財務管理',announce:'公告管理'};
  const permText = (role==='superadmin'||role==='超級管理員')
    ? '所有功能（超級管理員）'
    : Object.keys(perms||{}).filter(k=>perms[k]).map(k=>labels[k]||k).join('、') || '（請確認權限）';
  const sesText = limitSessions?.length ? '僅限指定場次' : '所有場次';
  const tenantName = (tenantCtx&&tenantCtx.name)||FALLBACK_TENANT_NAME;
  await sendEmail(env, email, `【${tenantName}】您已被授權為活動管理員`, emailWrap(`
<p>親愛的 <strong>${name||email}</strong>，</p>
<p>${tenantName} 已開通您的後台管理權限，歡迎加入！</p>
<div style="background:#f0fdf4;border-radius:10px;padding:16px;margin:16px 0">
  <p style="margin:0 0 8px"><strong>您的權限：</strong>${permText}</p>
  <p style="margin:0"><strong>可管理場次：</strong>${sesText}</p>
</div>
<p style="font-weight:700;margin-bottom:6px">後台登入方式：</p>
<ol style="margin:0 0 12px;padding-left:20px;line-height:2">
  <li>開啟前台網址：<a href="${(tenantCtx&&tenantCtx.siteUrl)||FALLBACK_SITE_URL}">${(tenantCtx&&tenantCtx.siteUrl)||FALLBACK_SITE_URL}</a></li>
  <li>在首頁封面區域（Logo 位置）<strong>長按 3 秒</strong>，進入後台</li>
  <li>輸入您的 Email（${email}）登入</li>
</ol>
<p style="background:#fff8ed;border-radius:8px;padding:12px 14px;font-size:13px;color:#7c2d12">
  ⚠️ 登入方式為「長按首頁封面區域 3 秒」，任何封面圖片下都有效。
</p>
<p style="text-align:center;margin:20px 0"><a href="${(tenantCtx&&tenantCtx.siteUrl)||FALLBACK_SITE_URL}" style="background:#2d6a4f;color:#fff;padding:14px 28px;border-radius:12px;text-decoration:none;font-weight:700;font-size:15px">前往前台登入後台</a></p>
`, tenantCtx), tenantCtx);
}

// ── SECTION 10: DB 查詢輔助 ─────────────────────────────────────
async function getSessionRow(env, sessionId, tenantId) {
  const tid = tenantId ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const rows = await dbGet(env, 'sessions', `tenant_id=eq.${tid}&id=eq.${encodeURIComponent(sessionId)}&select=*`);
  return rows[0] || null;
}
async function getSessionName(env, sessionId, tenantId) {
  const tid = tenantId ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const rows = await dbGet(env, 'sessions', `tenant_id=eq.${tid}&id=eq.${encodeURIComponent(sessionId)}&select=name,type`);
  return rows.length ? rows[0].name : sessionId;
}
async function getSessionType(env, sessionId, tenantId) {
  const tid = tenantId ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const rows = await dbGet(env, 'sessions', `tenant_id=eq.${tid}&id=eq.${encodeURIComponent(sessionId)}&select=type`);
  return rows.length ? rows[0].type : '';
}
// 取得租戶 context（品牌資料、信件設定）
async function getTenantCtx(env, tenantId) {
  const tid = tenantId ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const rows = await dbGet(env, 'tenants', `id=eq.${tid}&select=id,name,slug,config_json,line_url,bank_info,email_from,email_reply_to,footer_text,site_url,default_refund_rules_json,payment_config_json`);
  const t = rows[0] || {};
  const cfg = safeJson(t.config_json, {});
  return {
    id:         tid,
    name:       t.name       || FALLBACK_TENANT_NAME,
    slug:       t.slug       || tid,
    siteUrl:    t.site_url   || cfg.siteUrl   || FALLBACK_SITE_URL,
    lineUrl:    t.line_url   || '',   // 付款/LINE 設定缺漏不 fallback（前台顯示未設定）
    bankInfo:   t.bank_info  || '',   // 付款設定缺漏不 fallback（前台顯示未設定）
    emailFrom:  t.email_from || FALLBACK_EMAIL_FROM,
    emailReplyTo: t.email_reply_to || FALLBACK_EMAIL_REPLY,
    footer:     t.footer_text || (t.name || FALLBACK_TENANT_NAME) + '　All rights reserved.',
    color:      cfg.brandColor || '#2d6a4f',
    heroImg:    cfg.heroImg  || '',
    infoText:   cfg.infoText || '',
    portals:    cfg.portals  || ['市集報名','體驗活動','通路寄賣','合作洽詢'],
    defaultRefundRules: safeJson(t.default_refund_rules_json, DEFAULT_REFUND_RULES),
    paymentConfig: safeJson(t.payment_config_json, {}),
  };
}

// ── SECTION 11: GET Handlers ─────────────────────────────────────

// frontBootstrap：前台資料庫主導總入口
async function hFrontBootstrap(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const [tc, eventRows, sessionRows, annRows] = await Promise.all([
    getTenantCtx(env, TENANT),
    dbGet(env, 'events', `tenant_id=eq.${TENANT}&status=neq.停用&select=*`),
    dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&status=in.(報名中,開放中)&select=*`),
    dbGet(env, 'announcements', `tenant_id=eq.${TENANT}&select=*&order=created_at.desc`),
  ]);
  return jsonOk({
    tenant: {
      id:       tc.id,
      name:     tc.name,
      slug:     tc.slug,
      heroImg:  tc.heroImg,
      infoText: tc.infoText,
      lineUrl:  tc.lineUrl,
      bankInfo: tc.bankInfo,
      color:    tc.color,
      portals:  tc.portals,
      paymentConfig: tc.paymentConfig,
    },
    events:        eventRows.map(r=>({id:r.id,title:r.title,desc:r.description,location:r.location,cover:r.cover_url,status:r.status})),
    sessions:      sessionRows.map(formatSession),
    announcements: annRows.map(r=>({id:r.id,title:r.title,content:r.content,url:r.url,urlText:r.url_text,createdAt:r.created_at})),
  });
}

// getEvents
async function hGetEvents(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const rows = await dbGet(env, 'events', `tenant_id=eq.${TENANT}&status=neq.停用&select=*`);
  return jsonOk(rows.map(r=>({id:r.id,title:r.title,desc:r.description,location:r.location,cover:r.cover_url,status:r.status})));
}

// getSessions
async function hGetSessions(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  let qs = `tenant_id=eq.${TENANT}&status=in.(報名中,開放中)&select=*`;
  if (p.eventId) qs += `&event_id=eq.${encodeURIComponent(p.eventId)}`;
  let rows = await dbGet(env, 'sessions', qs);
  if (p.portal) rows = rows.filter(r=>{
    const ps = r.portals ? String(r.portals).split(',').map(x=>x.trim()) : [];
    return ps.includes(p.portal);
  });
  return jsonOk(rows.map(formatSession));
}

// getSession
async function hGetSession(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const id = p.id || p.sessionId;
  if (!id) return jsonErr('請提供 id');
  const rows = await dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(id)}&select=*`);
  if (!rows.length) return jsonErr('找不到場次');
  return jsonOk(formatSession(rows[0]));
}

// getSessionAgreement（回傳場次合約設定，供前台 Modal 顯示）
async function hGetSessionAgreement(env, p) {
  const TENANT = (p && p._tenantId);
  const id = p.id || p.sessionId;
  if (!id) return jsonErr('請提供 id');
  const rows = await dbGet(env, 'sessions',
    `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(id)}&select=id,name,agreement_required,agreement_title,agreement_content,agreement_version,agreement_updated_at`);
  if (!rows.length) return jsonErr('找不到場次');
  const s = rows[0];
  return jsonOk({
    sessionId: s.id,
    sessionName: s.name || '',
    agreementRequired: s.agreement_required !== false,
    title: s.agreement_title || '報名合約／活動細則與攤商規範',
    content: s.agreement_content || '',
    version: s.agreement_version || '',
    updatedAt: s.agreement_updated_at || null,
  });
}

// getMember
async function hGetMember(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!p.email) return jsonErr('請提供 email');
  const rows = await dbGet(env, 'members', `tenant_id=eq.${TENANT}&email=ilike.${encodeURIComponent(p.email)}&select=*`);
  if (!rows.length) return jsonOk(null);
  const m = rows[0];
  const brandName = m.brand_name || m.brand || '';
  return jsonOk({
    email:m.email, name:m.name||'', phone:String(m.phone||''),
    brand:brandName, brand_name:brandName,
    brandIntro:m.brand_intro||'', brand_intro:m.brand_intro||'',
    sellCat:m.sell_category||'', sell_category:m.sell_category||'',
    photo:m.photo_url||'', photo_url:m.photo_url||'',
    fb:m.fb_url||'', fb_url:m.fb_url||'', ig:m.ig_url||'', ig_url:m.ig_url||'',
    collabUrl:m.collab_url||'', collabDesc:m.collab_desc||'', collabItems:m.collab_items||'',
    company:m.company||m.invoice_title||'', taxId:m.tax_id||'', tax_id:m.tax_id||'',
    invoiceType:m.invoice_type||'', invoiceTitle:m.invoice_title||m.company||'', invoice_title:m.invoice_title||m.company||'',
    invoiceEmail:m.invoice_email||'', invoice_email:m.invoice_email||'',
    invoiceCarrier:m.invoice_carrier||'', invoice_carrier:m.invoice_carrier||'',
    city:m.city||'', lineId:m.line_id||'', line_id:m.line_id||'',
    fastPass:m.fast_pass===true||m.fast_pass==='true', joinedAt:m.joined_at,
  });
}

// getMyRegs
async function hGetMyRegs(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!p.email) return jsonErr('請提供 email');
  const [regs, sessions] = await Promise.all([
    dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&email=ilike.${encodeURIComponent(p.email)}&select=*&order=created_at.desc`),
    dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&select=id,name,event_id,force_cancelled,force_mode,force_cancel_reason_label,force_cancelled_at,force_transfer_target_session_id,force_choice_deadline`),
  ]);
  const sMap = {}; sessions.forEach(s=>sMap[s.id]=s);
  return jsonOk(regs.map(r=>{
    const s = sMap[r.session_id]||{};
    return {
      id:r.id, sessionId:r.session_id, sessionName:s.name||r.session_id,
      eventId:r.event_id||s.event_id||'',
      status:r.review_status, payStatus:r.payment_status,
      amount:Number(r.amount||0), total:Number(r.total_amount||r.amount||0),
      deposit:Number(r.deposit||0),
      stallCount:Number(r.stall_count||1),
      selectedDates:safeJson(r.selected_dates_json,[]),
      equip:safeJson(r.equipment_json,{}),
      addonQty:safeJson(r.addon_qty_json,{}),
      participants:safeJson(r.participants_json,{}),
      stallNumber:r.stall_number||'',
      payMethod:r.payment_method||'',
      payLast5:r.payment_last5||'',
      checkin:r.checkin_status, createdAt:r.created_at,
      transferStatus:r.transfer_status||'',
      transferChosenAt:r.transfer_chosen_at||'',
      refundAmount:safeNum(r.refund_amount),
      refundAdminFee:safeNum(r.refund_admin_fee),
      refundTransferFee:safeNum(r.refund_transfer_fee),
      refundRuleLabel:r.refund_rule_label||'',
      refundedAt:r.refunded_at||'',
      refundNote:r.refund_note||'',
      // ── 不可抗力欄位 ──
      forceStatus:r.force_status||null,
      forceChoiceDeadline:s.force_choice_deadline||'',
      forceCancelled:s.force_cancelled||false,
      forceMode:s.force_mode||'',
      forceCancelReasonLabel:s.force_cancel_reason_label||'',
      forceTransferTargetSessionId:r.transferred_to_session_id||s.force_transfer_target_session_id||'',
      forceRefundRequestedAt:r.force_refund_requested_at||'',
      forceRefundedAt:r.force_refunded_at||'',
      // ── 合約同意紀錄 ──
      agreementAccepted:   r.agreement_accepted || false,
      agreementVersion:    r.agreement_version  || '',
    };
  }));
}

// getRegLookup（信件深連結用：依 regId 反查 email，不依賴瀏覽器暫存）
async function hGetRegLookup(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const regId = p.regId || p.reg || p.pay || p.registrationId || '';
  if (!regId) return jsonErr('請提供 regId');
  const rows = await dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(regId)}&select=id,email,review_status,payment_status,session_id`);
  if (!rows.length) return jsonErr('找不到報名紀錄');
  const r = rows[0];
  return jsonOk({id:r.id,email:r.email,status:r.review_status||'',payStatus:r.payment_status||'',sessionId:r.session_id||''});
}

// getAnnouncements
async function hGetAnnouncements(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const rows = await dbGet(env, 'announcements', `tenant_id=eq.${TENANT}&select=*&order=created_at.desc`);
  return jsonOk(rows.map(r=>({id:r.id,title:r.title,content:r.content,url:r.url,urlText:r.url_text,createdAt:r.created_at})));
}

// getStalls
async function hGetStalls(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  let qs = `tenant_id=eq.${TENANT}&select=*`;
  if (p.sessionId) qs += `&session_id=eq.${encodeURIComponent(p.sessionId)}`;
  const rows = await dbGet(env, 'stalls', qs);
  return jsonOk(rows.map(r=>({id:r.id,sessionId:r.session_id,number:r.stall_no||r.number||'',stallNo:r.stall_no||r.number||'',status:(r.status==='空閒'?'開放':(r.status||'開放')),regId:r.reg_id||'',holdTime:r.hold_time||'',email:r.email||''})));
}

// getMyStall
async function hGetMyStall(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!p.regId) return jsonOk(null);
  const rows = await dbGet(env, 'stalls', `tenant_id=eq.${TENANT}&reg_id=eq.${encodeURIComponent(p.regId)}&select=*`);
  if (!rows.length) return jsonOk(null);
  return jsonOk({number:rows[0].stall_no||rows[0].number||'', status:rows[0].status});
}

// getStallStatus
async function hGetStallStatus(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const sId = p.sessionId || p.session_id;
  if (!sId) return jsonErr('請提供 sessionId');
  const rows = await dbGet(env, 'stalls', `tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(sId)}&select=*`);
  const stallList = rows.map(r=>r.stall_no||r.number||'').filter(Boolean);
  const taken = {};
  rows.forEach(r=>{
    if (r.status==='鎖定'||r.status==='預留')
      taken[r.stall_no||r.number] = {status:r.status==='鎖定'?'paid':'reserved', regId:r.reg_id||''};
  });
  return jsonOk({stallList, taken});
}

// ── 統一 Google 登入入口（前台 + 後台共用）────────────────────────

// GET /auth/google/unified/start — 統一登入起點
async function hGoogleUnifiedStart(env, url) {
  const GOOGLE_CLIENT_ID = env.GOOGLE_CLIENT_ID;
  const GOOGLE_REDIRECT_URI = env.GOOGLE_UNIFIED_REDIRECT_URI || env.GOOGLE_REDIRECT_URI;
  if (!GOOGLE_CLIENT_ID || !GOOGLE_REDIRECT_URI) {
    return new Response('Google OAuth 未設定', { status: 500 });
  }
  const tenant = url.searchParams.get('tenant') || 'tuibile';
  const next = url.searchParams.get('next') || 'auto'; // auto/admin/member
  const rawState = `${tenant}:${next}:${Date.now()}:${Math.random().toString(36).slice(2)}`;
  const state = btoa(rawState);
  const params = new URLSearchParams({
    client_id: GOOGLE_CLIENT_ID,
    redirect_uri: GOOGLE_REDIRECT_URI,
    response_type: 'code',
    scope: 'openid email profile',
    state,
    access_type: 'online',
    prompt: 'select_account',
  });
  return Response.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`, 302);
}

// GET /auth/google/unified/callback — 統一登入回調
async function hGoogleUnifiedCallback(env, url) {
  const GOOGLE_CLIENT_ID = env.GOOGLE_CLIENT_ID;
  const GOOGLE_CLIENT_SECRET = env.GOOGLE_CLIENT_SECRET;
  const GOOGLE_REDIRECT_URI = env.GOOGLE_UNIFIED_REDIRECT_URI || env.GOOGLE_REDIRECT_URI;
  const FRONTEND_SITE_URL = env.FRONTEND_SITE_URL || env.ADMIN_SITE_URL || '';
  const ADMIN_SITE_URL = env.ADMIN_SITE_URL || '';

  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const errorParam = url.searchParams.get('error');

  const failRedirect = (reason, base) => {
    const u = new URL(base || FRONTEND_SITE_URL);
    u.searchParams.set('login_error', reason);
    return Response.redirect(u.toString(), 302);
  };

  if (errorParam) return failRedirect('google_cancelled', FRONTEND_SITE_URL);
  if (!code || !state) return failRedirect('missing_params', FRONTEND_SITE_URL);

  let tenant = 'tuibile', next = 'auto';
  try {
    const raw = atob(state);
    const parts = raw.split(':');
    tenant = parts[0] || 'tuibile';
    next = parts[1] || 'auto';
  } catch(e) { return failRedirect('invalid_state', FRONTEND_SITE_URL); }

  // 換 token
  let tokenRes;
  try {
    tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code, client_id: GOOGLE_CLIENT_ID,
        client_secret: GOOGLE_CLIENT_SECRET,
        redirect_uri: GOOGLE_REDIRECT_URI,
        grant_type: 'authorization_code',
      }),
    }).then(r => r.json());
  } catch(e) { return failRedirect('token_exchange_failed', FRONTEND_SITE_URL); }

  if (!tokenRes.id_token) return failRedirect('no_id_token', FRONTEND_SITE_URL);

  // 驗證 id_token
  let userInfo;
  try {
    const infoRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${tokenRes.id_token}`);
    userInfo = await infoRes.json();
    if (userInfo.error || userInfo.aud !== GOOGLE_CLIENT_ID) throw new Error('invalid');
  } catch(e) { return failRedirect('id_token_verify_failed', FRONTEND_SITE_URL); }

  const googleEmail = (userInfo.email || '').toLowerCase();
  const googleSub = userInfo.sub || '';
  const googleName = userInfo.name || '';
  const googleAvatar = userInfo.picture || '';

  if (!googleEmail) return failRedirect('no_email', FRONTEND_SITE_URL);

  // 判斷身份：主辦方 / 報名者 / 兩者
  const isStaff = await checkIsStaff(env, googleEmail, tenant);
  const isMember = await checkIsMember(env, googleEmail, tenant);

  // 記錄登入
  await logAdminLogin(env, tenant, null, googleEmail, 'google', 'success', 'unified_login', '', '');

  if (isStaff && isMember && next === 'auto') {
    // 兩種身份都有 → 跳轉到選擇頁
    const memberToken = await issueMemberToken({ email: googleEmail, google_sub: googleSub, display_name: googleName, avatar_url: googleAvatar }, env);
    const staffToken = await issueStaffTokenByEmail(env, googleEmail, tenant);
    const u = new URL(FRONTEND_SITE_URL || 'https://2b-love.com/register.html');
    u.searchParams.set('choose_role', '1');
    u.searchParams.set('member_token', memberToken);
    u.searchParams.set('admin_token', staffToken);
    u.searchParams.set('tenant', tenant);
    u.searchParams.set('display_name', googleName);
    return Response.redirect(u.toString(), 302);
  }

  if ((isStaff && next === 'auto') || next === 'admin') {
    // 主辦方 → 進後台
    if (!isStaff) return failRedirect('not_authorized', ADMIN_SITE_URL);
    const lockCheck = await checkTenantLocked(env, tenant);
    const staffToken = await issueStaffTokenByEmail(env, googleEmail, tenant);
    await updateStaffLastLogin(env, googleEmail, tenant, googleName);
    const u = new URL(ADMIN_SITE_URL || 'https://2b-love.com/admin.html');
    u.searchParams.set('admin_token', staffToken);
    u.searchParams.set('tenant', tenant);
    if (lockCheck.locked) u.searchParams.set('locked', '1');
    return Response.redirect(u.toString(), 302);
  }

  // 報名者 → 進前台
  await updateMemberLastLogin(env, googleEmail, tenant, googleSub, googleName, googleAvatar);
  const memberToken = await issueMemberToken({ email: googleEmail, google_sub: googleSub, display_name: googleName, avatar_url: googleAvatar }, env);
  const u = new URL(FRONTEND_SITE_URL || 'https://2b-love.com/register.html');
  u.searchParams.set('member_token', memberToken);
  u.searchParams.set('tenant', tenant);
  u.searchParams.set('display_name', googleName);
  return Response.redirect(u.toString(), 302);
}

// 輔助：檢查是否為 staff
async function checkIsStaff(env, email, tenantId) {
  const platformRows = await dbGet(env, 'platform_staff', `email=eq.${encodeURIComponent(email)}&is_active=eq.true&select=id`).catch(()=>[]);
  if (platformRows[0]) return true;
  const rows = await dbGet(env, 'staff', `tenant_id=eq.${tenantId}&email=eq.${encodeURIComponent(email)}&select=id,is_active,active`).catch(()=>[]);
  if (!rows[0]) return false;
  return rows[0].is_active !== undefined ? rows[0].is_active : rows[0].active;
}

// 輔助：檢查是否為 member
async function checkIsMember(env, email, tenantId) {
  const rows = await dbGet(env, 'members', `tenant_id=eq.${tenantId}&email=eq.${encodeURIComponent(email)}&select=email`).catch(()=>[]);
  return rows.length > 0;
}

// 輔助：用 email 簽發 staff token
async function issueStaffTokenByEmail(env, email, tenantId) {
  const platformRows = await dbGet(env, 'platform_staff', `email=eq.${encodeURIComponent(email)}&is_active=eq.true&select=*`).catch(()=>[]);
  if (platformRows[0]) return issueAdminToken({ ...platformRows[0], email }, 'platform', env);
  const rows = await dbGet(env, 'staff', `tenant_id=eq.${tenantId}&email=eq.${encodeURIComponent(email)}&select=*`).catch(()=>[]);
  if (!rows[0]) throw new Error('staff not found');
  return issueAdminToken({ ...rows[0], email }, tenantId, env);
}

// 輔助：更新 staff 最後登入
async function updateStaffLastLogin(env, email, tenantId, displayName) {
  await dbUpdate(env, 'staff', `tenant_id=eq.${tenantId}&email=eq.${encodeURIComponent(email)}`,
    { last_login_at: new Date().toISOString(), display_name: displayName }).catch(()=>{});
}

// 輔助：更新 member 最後登入 + Google 資料
async function updateMemberLastLogin(env, email, tenantId, googleSub, displayName, avatarUrl) {
  const rows = await dbGet(env, 'members', `tenant_id=eq.${tenantId}&email=eq.${encodeURIComponent(email)}&select=email`).catch(()=>[]);
  if (rows[0]) {
    await dbUpdate(env, 'members', `tenant_id=eq.${tenantId}&email=eq.${encodeURIComponent(email)}`,
      { last_login_at: new Date().toISOString(), google_sub: googleSub, display_name: displayName, avatar_url: avatarUrl, login_provider: 'google' }).catch(()=>{});
  } else {
    // 新會員：建立記錄
    await dbInsert(env, 'members', {
      email, tenant_id: tenantId, google_sub: googleSub,
      display_name: displayName, avatar_url: avatarUrl,
      login_provider: 'google', last_login_at: new Date().toISOString(),
      joined_at: new Date().toISOString(), updated_at: new Date().toISOString(),
    }).catch(()=>{});
  }
}

// ── 申請試用 API ──────────────────────────────────────────────────

// POST /apply — 客戶申請試用（不需登入）
async function hApplyTrial(env, b) {
  if (!b.brand_name || !b.contact_email) return jsonErr('請填寫品牌名稱與 Email');

  // 檢查是否已申請
  const existing = await dbGet(env, 'tenant_apply_logs',
    `contact_email=eq.${encodeURIComponent(b.contact_email)}&status=eq.pending&select=id`).catch(()=>[]);
  if (existing.length) return jsonErr('此 Email 已有待處理的申請，請稍候或聯繫我們');

  const id = genId('APL');
  await dbInsert(env, 'tenant_apply_logs', {
    id,
    brand_name: b.brand_name,
    contact_name: b.contact_name || '',
    contact_email: b.contact_email.toLowerCase(),
    contact_phone: b.contact_phone || '',
    event_type: b.event_type || '',
    plan_type: 'trial',
    note: b.note || '',
    status: 'pending',
    created_at: new Date().toISOString(),
  });

  // 寄通知給你（系統管理者）
  const adminEmail = env.PLATFORM_ADMIN_EMAIL || 'ndiangrace@gmail.com';
  await sendEmail(env, {
    to: adminEmail,
    subject: `【2b-love.com】新申請：${b.brand_name}`,
    html: `
      <h2>新試用申請</h2>
      <p><b>品牌名稱：</b>${b.brand_name}</p>
      <p><b>聯絡人：</b>${b.contact_name || '未填'}</p>
      <p><b>Email：</b>${b.contact_email}</p>
      <p><b>電話：</b>${b.contact_phone || '未填'}</p>
      <p><b>活動類型：</b>${b.event_type || '未填'}</p>
      <p><b>備註：</b>${b.note || '無'}</p>
      <p><b>申請編號：</b>${id}</p>
      <br>
      <a href="${env.ADMIN_SITE_URL || ''}?manage=1">前往開通工具</a>
    `,
  }).catch(()=>{});

  return jsonOk({ ok: true, apply_id: id, message: '申請已送出，我們將在 1–2 個工作天內與您聯繫' });
}

// POST /approveApply — 你的一鍵開通（需平台管理員身份）
async function hApproveApply(env, b) {
  // 驗證是平台管理員
  const payload = await verifyAdminJwt(b.token, env);
  if (!payload || payload.normalized_role !== 'platform_super_admin') return jsonErr('無權限', 401);

  const applyId = b.apply_id;
  if (!applyId) return jsonErr('缺少 apply_id');

  const applyRows = await dbGet(env, 'tenant_apply_logs', `id=eq.${applyId}&select=*`);
  const apply = applyRows[0];
  if (!apply) return jsonErr('找不到申請記錄');
  if (apply.status !== 'pending') return jsonErr('此申請已處理');

  // 建立新 tenant
  const tenantId = b.tenant_id || apply.brand_name.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0, 20) + '_' + Date.now().toString().slice(-4);
  const now = new Date();
  const trialEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30天試用

  await dbInsert(env, 'tenants', {
    id: tenantId,
    slug: tenantId,
    name: apply.brand_name,
    status: 'active',
    plan_type: 'trial',
    trial_start_at: now.toISOString(),
    trial_end_at: trialEnd.toISOString(),
    is_locked: false,
    contact_name: apply.contact_name,
    contact_phone: apply.contact_phone,
    event_type: apply.event_type,
    apply_note: apply.note,
    notify_email: apply.contact_email,
    config_json: '{}',
    payment_config_json: '{}',
    default_refund_rules_json: '{}',
    created_at: now.toISOString(),
    updated_at: now.toISOString(),
  });

  // 建立 staff（主辦者）
  const staffId = genId('STF');
  await dbInsert(env, 'staff', {
    id: staffId,
    tenant_id: tenantId,
    email: apply.contact_email,
    name: apply.contact_name || apply.brand_name,
    role: 'organizer_owner',
    normalized_role: 'organizer_owner',
    is_active: true,
    display_name: apply.contact_name || apply.brand_name,
    perms_json: '{}',
    created_at: now.toISOString(),
    updated_at: now.toISOString(),
  });

  // 更新申請記錄
  await dbUpdate(env, 'tenant_apply_logs', `id=eq.${applyId}`, {
    status: 'approved',
    tenant_id: tenantId,
    approved_at: now.toISOString(),
    approved_by: payload.email,
  });

  // 寄開通通知給客戶
  const loginUrl = `${env.FRONTEND_SITE_URL || ''}?tenant=${tenantId}`;
  await sendEmail(env, {
    to: apply.contact_email,
    subject: '【兔彼樂市集活動系統】您的試用帳號已開通！',
    html: `
      <h2>恭喜！您的試用帳號已開通</h2>
      <p>您好，${apply.contact_name || apply.brand_name}！</p>
      <p>您申請的「兔彼樂市集活動系統」試用帳號已開通。</p>
      <p><b>試用期限：</b>30天（至 ${trialEnd.toLocaleDateString('zh-TW')}）</p>
      <p><b>試用限制：</b>最多建立 2 個場次</p>
      <br>
      <p>請使用您的 Google 帳號（${apply.contact_email}）登入：</p>
      <a href="${loginUrl}" style="background:#3a7d5c;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold">立即登入後台</a>
      <br><br>
      <p>如有任何問題，請聯繫我們：ndiangrace@gmail.com</p>
      <p>兔彼樂市集活動系統</p>
    `,
  }).catch(()=>{});

  return jsonOk({ ok: true, tenant_id: tenantId, message: `已開通，開通信已寄至 ${apply.contact_email}` });
}

// GET /apply/list — 查詢申請列表（平台管理員用）
// GET /getTenantsAdmin — 平台管理員查詢所有租戶
// BUG-B FIX 2025-06
async function hGetTenantsAdmin(env, p) {
  const payload = await verifyAdminJwt(p.token, env);
  if (!payload || payload.normalized_role !== 'platform_super_admin') return jsonErr('無權限', 401);
  const rows = await dbGet(env, 'tenants',
    'order=created_at.desc&select=id,name,slug,plan_type,is_locked,locked_reason,trial_start_at,trial_end_at,session_count_used,contact_name,contact_phone,notify_email,created_at'
  );
  return jsonOk(rows);
}

async function hApplyList(env, p) {
  const payload = await verifyAdminJwt(p.token, env);
  if (!payload || payload.normalized_role !== 'platform_super_admin') return jsonErr('無權限', 401);
  const rows = await dbGet(env, 'tenant_apply_logs', `order=created_at.desc&limit=50&select=*`);
  return jsonOk(rows);
}

// ── 鎖定 / 停用機制 API ──────────────────────────────────────────

// POST /lockTenant — 鎖定租戶（平台管理員用）
async function hLockTenant(env, b) {
  const payload = await verifyAdminJwt(b.token, env);
  if (!payload || payload.normalized_role !== 'platform_super_admin') return jsonErr('無權限', 401);
  await dbUpdate(env, 'tenants', `id=eq.${b.tenant_id}`, {
    is_locked: true,
    locked_at: new Date().toISOString(),
    locked_reason: b.reason || '帳號鎖定',
    updated_at: new Date().toISOString(),
  });
  return jsonOk({ ok: true });
}

// POST /unlockTenant — 解鎖租戶（收到付款後）
async function hUnlockTenant(env, b) {
  const payload = await verifyAdminJwt(b.token, env);
  if (!payload || payload.normalized_role !== 'platform_super_admin') return jsonErr('無權限', 401);
  const now = new Date();
  const newEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  await dbUpdate(env, 'tenants', `id=eq.${b.tenant_id}`, {
    is_locked: false,
    locked_at: null,
    locked_reason: null,
    plan_type: 'active',
    trial_end_at: newEnd.toISOString(),
    updated_at: now.toISOString(),
  });
  // 記錄計費
  await dbInsert(env, 'billing_logs', {
    id: genId('BIL'),
    tenant_id: b.tenant_id,
    billing_type: 'manual',
    amount: Number(b.amount) || 0,
    tax: Number(b.tax) || 0,
    total: (Number(b.amount) || 0) + (Number(b.tax) || 0),
    status: 'confirmed',
    confirmed_at: now.toISOString(),
    confirmed_by: payload.email,
    period_start: now.toISOString(),
    period_end: newEnd.toISOString(),
    note: b.note || '手動續費',
    created_at: now.toISOString(),
  });
  // 寄通知給客戶
  const tenant = (await dbGet(env, 'tenants', `id=eq.${b.tenant_id}&select=notify_email,name`))[0];
  if (tenant?.notify_email) {
    await sendEmail(env, {
      to: tenant.notify_email,
      subject: '【兔彼樂市集活動系統】您的帳號已恢復正常',
      html: `<p>您好！您的帳號已恢復正常，可以繼續使用所有功能。</p><p>有效期至：${newEnd.toLocaleDateString('zh-TW')}</p>`,
    }).catch(()=>{});
  }
  return jsonOk({ ok: true });
}

// ── 場次下載 Excel ────────────────────────────────────────────────

// GET /downloadSession — 下載單場次完整 Excel
async function hDownloadSession(env, p) {
  const TENANT = p._tenantId;
  if (!await verifyStaff(env, p.email, p.token, TENANT)) return jsonErr('無權限');

  // 鎖定中不可下載
  const lockCheck = await checkTenantLocked(env, TENANT);
  if (lockCheck.locked) return jsonErr('帳號已鎖定，無法下載資料，請先續費');

  const sesId = p.sessionId;
  if (!sesId) return jsonErr('請指定場次');

  // 取場次資料
  const sessions = await dbGet(env, 'sessions', `id=eq.${sesId}&tenant_id=eq.${TENANT}&select=*`);
  const session = sessions[0];
  if (!session) return jsonErr('找不到場次');

  // 取報名資料
  const regs = await dbGet(env, 'registrations',
    `session_id=eq.${sesId}&tenant_id=eq.${TENANT}&select=*&order=created_at.asc`);

  // 建立 CSV（兩個工作表用分隔符區分，前端再分割）
  const regHeaders = ['報名編號','品牌名稱','聯絡人','Email','電話','攤位號碼','設備','報名費','押金','審核狀態','繳費狀態','報到狀態','申請時間'];
  const regRows = regs.map(r => [
    r.registration_no || r.id,
    r.brand_name || r.brand || '',
    r.name || '',
    r.email || '',
    r.phone || '',
    r.stall_no || '',
    r.equip_summary || '',
    r.amount || 0,
    r.deposit || 0,
    r.review_status || '',
    r.payment_status || '',
    r.checkin_status || '',
    r.created_at ? new Date(r.created_at).toLocaleString('zh-TW') : '',
  ]);

  // 財務統計
  const totalAmount = regs.filter(r=>r.payment_status==='已繳費').reduce((s,r)=>s+(Number(r.amount)||0),0);
  const totalDeposit = regs.filter(r=>r.payment_status==='已繳費').reduce((s,r)=>s+(Number(r.deposit)||0),0);
  const totalRefund = regs.filter(r=>r.transfer_status==='已退費').reduce((s,r)=>s+(Number(r.amount)||0),0);
  const finHeaders = ['項目','金額'];
  const finRows = [
    ['總報名數', regs.length],
    ['已繳費數', regs.filter(r=>r.payment_status==='已繳費').length],
    ['總收入（報名費）', totalAmount],
    ['總押金', totalDeposit],
    ['總退費', totalRefund],
    ['淨收入', totalAmount + totalDeposit - totalRefund],
  ];

  // 輸出 JSON 讓前端轉 Excel
  return jsonOk({
    session: {
      name: session.name,
      date: session.dates_json ? JSON.parse(session.dates_json)[0]?.date : '',
      venue: session.venue || '',
    },
    registrations: { headers: regHeaders, rows: regRows },
    finance: { headers: finHeaders, rows: finRows },
  });
}

// ── Cron：試用到期提醒 ────────────────────────────────────────────
async function cronTrialExpireReminders(env) {
  const now = new Date();
  const sevenDaysLater = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  // 找 7 天後到期的試用帳號
  const expiring = await dbGet(env, 'tenants',
    `plan_type=eq.trial&is_locked=eq.false&trial_end_at=lte.${sevenDaysLater.toISOString()}&trial_end_at=gte.${now.toISOString()}&select=id,name,notify_email,trial_end_at`
  ).catch(()=>[]);

  for (const t of expiring) {
    if (!t.notify_email) continue;
    const endDate = new Date(t.trial_end_at).toLocaleDateString('zh-TW');
    await sendEmail(env, {
      to: t.notify_email,
      subject: `【兔彼樂市集活動系統】您的試用將於 ${endDate} 到期`,
      html: `
        <h2>試用期即將結束</h2>
        <p>您好！您的「${t.name}」試用帳號將於 <b>${endDate}</b> 到期。</p>
        <p>到期後帳號將自動鎖定，功能暫停使用，但歷史資料保留。</p>
        <p>如需繼續使用，請聯繫我們續費：</p>
        <p>Email：ndiangrace@gmail.com</p>
        <p>LINE：@2beloved</p>
      `,
    }).catch(()=>{});
  }

  // 自動鎖定已到期的試用帳號
  const expired = await dbGet(env, 'tenants',
    `plan_type=eq.trial&is_locked=eq.false&trial_end_at=lt.${now.toISOString()}&select=id,name,notify_email`
  ).catch(()=>[]);

  for (const t of expired) {
    await dbUpdate(env, 'tenants', `id=eq.${t.id}`, {
      is_locked: true,
      locked_at: now.toISOString(),
      locked_reason: '試用期已結束',
      updated_at: now.toISOString(),
    }).catch(()=>{});

    if (!t.notify_email) continue;
    await sendEmail(env, {
      to: t.notify_email,
      subject: '【兔彼樂市集活動系統】試用期已結束，帳號已鎖定',
      html: `
        <h2>試用期已結束</h2>
        <p>您的帳號已鎖定，目前只能查看歷史資料，無法新增或操作。</p>
        <p>如需繼續使用，請聯繫我們續費：</p>
        <p>Email：ndiangrace@gmail.com</p>
        <p>LINE：@2beloved</p>
      `,
    }).catch(()=>{});
  }
}



// GET /auth/google/start
async function hGoogleStart(env, url) {
  const GOOGLE_CLIENT_ID = env.GOOGLE_CLIENT_ID;
  const GOOGLE_REDIRECT_URI = env.GOOGLE_REDIRECT_URI;
  if (!GOOGLE_CLIENT_ID || !GOOGLE_REDIRECT_URI) {
    return new Response('Google OAuth 未設定，請檢查 Cloudflare Worker 環境變數', { status: 500 });
  }
  const tenant = url.searchParams.get('tenant') || 'tuibile';
  // state = base64(tenant:timestamp:hmac) 防 CSRF
  const rawState = `${tenant}:${Date.now()}:${Math.random().toString(36).slice(2)}`;
  const state = btoa(rawState);
  const params = new URLSearchParams({
    client_id: GOOGLE_CLIENT_ID,
    redirect_uri: GOOGLE_REDIRECT_URI,
    response_type: 'code',
    scope: 'openid email profile',
    state,
    access_type: 'online',
    prompt: 'select_account',
  });
  return Response.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`, 302);
}

// GET /auth/google/callback
async function hGoogleCallback(env, url) {
  const GOOGLE_CLIENT_ID = env.GOOGLE_CLIENT_ID;
  const GOOGLE_CLIENT_SECRET = env.GOOGLE_CLIENT_SECRET;
  const GOOGLE_REDIRECT_URI = env.GOOGLE_REDIRECT_URI;
  const ADMIN_SITE_URL = env.ADMIN_SITE_URL || '';

  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const errorParam = url.searchParams.get('error');

  const failRedirect = (reason) => {
    const u = new URL(ADMIN_SITE_URL || 'https://2b-love.com/admin.html');
    u.searchParams.set('login_error', reason);
    return Response.redirect(u.toString(), 302);
  };

  if (errorParam) return failRedirect('google_cancelled');
  if (!code || !state) return failRedirect('missing_params');

  // 解碼 state，取 tenant
  let tenant = 'tuibile';
  try {
    const raw = atob(state);
    tenant = raw.split(':')[0] || 'tuibile';
  } catch(e) { return failRedirect('invalid_state'); }

  // 用 code 換 token
  let tokenRes;
  try {
    tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code, client_id: GOOGLE_CLIENT_ID,
        client_secret: GOOGLE_CLIENT_SECRET,
        redirect_uri: GOOGLE_REDIRECT_URI,
        grant_type: 'authorization_code',
      }),
    }).then(r => r.json());
  } catch(e) {
    await logAdminLogin(env, tenant, null, '', 'google', 'error', 'token_exchange_failed', '', '');
    return failRedirect('token_exchange_failed');
  }

  if (!tokenRes.id_token) {
    await logAdminLogin(env, tenant, null, '', 'google', 'error', 'no_id_token', '', '');
    return failRedirect('no_id_token');
  }

  // 驗證 id_token（向 Google tokeninfo 端點驗證）
  let userInfo;
  try {
    const infoRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${tokenRes.id_token}`);
    userInfo = await infoRes.json();
    if (userInfo.error || userInfo.aud !== GOOGLE_CLIENT_ID) throw new Error('invalid_token');
  } catch(e) {
    await logAdminLogin(env, tenant, null, '', 'google', 'denied', 'id_token_verify_failed', '', '');
    return failRedirect('id_token_verify_failed');
  }

  const googleEmail = (userInfo.email || '').toLowerCase();
  const googleName = userInfo.name || '';
  if (!googleEmail) return failRedirect('no_email');

  // 查 platform_staff（跨 tenant 超管）
  const platformRows = await dbGet(env, 'platform_staff',
    `email=eq.${encodeURIComponent(googleEmail)}&is_active=eq.true&select=*`).catch(()=>[]);
  if (platformRows[0]) {
    const ps = platformRows[0];
    const adminToken = await issueAdminToken({ ...ps, email: googleEmail, name: ps.name||googleName }, 'platform', env);
    await dbUpdate(env, 'platform_staff', `email=eq.${encodeURIComponent(googleEmail)}`, { last_login_at: new Date().toISOString() });
    await logAdminLogin(env, tenant, ps.id, googleEmail, 'google', 'success', '', '', '');
    const u = new URL(ADMIN_SITE_URL || 'https://2b-love.com/admin.html');
    u.searchParams.set('admin_token', adminToken);
    u.searchParams.set('tenant', tenant);
    return Response.redirect(u.toString(), 302);
  }

  // 查 tenant staff
  const rows = await dbGet(env, 'staff',
    `tenant_id=eq.${tenant}&email=eq.${encodeURIComponent(googleEmail)}&select=*`);
  const staff = rows[0];

  if (!staff) {
    await logAdminLogin(env, tenant, null, googleEmail, 'google', 'denied', 'email_not_in_staff', '', '');
    return failRedirect('not_authorized');
  }
  // is_active 欄位（相容 active / is_active 兩種欄位名）
  const isActive = staff.is_active !== undefined ? staff.is_active : staff.active;
  if (!isActive) {
    await logAdminLogin(env, tenant, staff.id, googleEmail, 'google', 'denied', 'staff_inactive', '', '');
    return failRedirect('staff_inactive');
  }

  // 更新 last_login_at / display_name
  await dbUpdate(env, 'staff', `id=eq.${encodeURIComponent(staff.id)}`, { last_login_at: new Date().toISOString(), display_name: staff.display_name||googleName }).catch(()=>{});

  const adminToken = await issueAdminToken({ ...staff, email: googleEmail }, tenant, env);
  await logAdminLogin(env, tenant, staff.id, googleEmail, 'google', 'success', '', '', '');

  const u = new URL(ADMIN_SITE_URL || 'https://2b-love.com/admin.html');
  u.searchParams.set('admin_token', adminToken);
  u.searchParams.set('tenant', tenant);
  return Response.redirect(u.toString(), 302);
}

// POST /admin/logout
async function hAdminLogout(env, b) {
  // 前端負責清除 token；後端可在此將 token 加入黑名單（可擴充）
  // 目前：記錄登出事件
  if (b && b.email && b.token) {
    const payload = await verifyAdminJwt(b.token, env).catch(()=>null);
    if (payload) {
      await logAdminLogin(env, payload.tenant_id||'', payload.staff_id||'', payload.email||b.email, 'google', 'success', 'logout', '', '');
    }
  }
  return jsonOk({ ok: true, message: '已登出' });
}

// GET /admin/me
async function hAdminMe(env, p) {
  const token = p.token || p.admin_token;
  const email = p.email;
  if (!token) return jsonErr('未帶 token', 401);
  const payload = await verifyAdminJwt(token, env);
  if (!payload) return jsonErr('token 無效或已過期，請重新登入', 401);
  // email=_ 表示由 JWT 自行驗證，不做 email 比對
  if (email && email !== '_' && email !== '__jwt__' && payload.email !== email) return jsonErr('token 與 email 不符', 401);
  return jsonOk({
    email: payload.email,
    tenant_id: payload.tenant_id,
    staff_id: payload.staff_id,
    role: payload.role,
    normalized_role: payload.normalized_role,
    limit_sessions: payload.limit_sessions,
    display_name: payload.display_name,
    issued_at: payload.issued_at,
    expires_at: payload.expires_at,
  });
}

// 記錄登入 log
async function logAdminLogin(env, tenantId, staffId, email, provider, status, reason, ip, ua) {
  try {
    await dbInsert(env, 'admin_login_logs', {
      id: genId('LOG'),
      tenant_id: tenantId || '',
      staff_id: staffId || null,
      email: email || '',
      provider: provider || 'google',
      login_status: status || 'error',
      reason: reason || '',
      ip: ip || '',
      user_agent: ua || '',
      created_at: new Date().toISOString(),
    });
  } catch(e) { /* 登入 log 失敗不影響主流程 */ }
}

// adminLogin（保留用於緊急後門，但改為需要系統設定的 EMERGENCY_ADMIN_KEY）
async function hAdminLogin(env, p) {
  // Google OAuth 升級後，此 endpoint 僅供緊急恢復用
  // 必須提供 EMERGENCY_ADMIN_KEY 環境變數才能使用
  const emergencyKey = env.EMERGENCY_ADMIN_KEY;
  if (!emergencyKey) return jsonErr('Email 直接登入已停用，請使用 Google OAuth 登入');
  if (!p.emergency_key || p.emergency_key !== emergencyKey) return jsonErr('無效的緊急登入金鑰');

  const TENANT = p && p._tenantId;
  if (!TENANT) return jsonErr('缺少 tenant 參數');
  if (!p.email) return jsonErr('請提供 email');

  const platformRows = await dbGet(env, 'platform_staff',
    `email=eq.${encodeURIComponent(p.email)}&is_active=eq.true&select=*`).catch(()=>[]);
  if (platformRows.length) {
    const ps = platformRows[0];
    const token = await issueAdminToken({ ...ps, email: p.email }, 'platform', env);
    const tc = await getTenantCtx(env, TENANT);
    return jsonOk({ success:true, role:ps.role, name:ps.name||'', token, tenantId:TENANT, tenantName:tc.name, isPlatformStaff:true });
  }

  const rows = await dbGet(env, 'staff', `tenant_id=eq.${TENANT}&email=eq.${encodeURIComponent(p.email)}&select=*`);
  if (!rows.length) return jsonErr('此帳號無管理員權限');
  const isActive = rows[0].is_active !== undefined ? rows[0].is_active : rows[0].active;
  if (!isActive) return jsonErr('此帳號已停用');
  const token = await issueAdminToken({ ...rows[0], email: p.email }, TENANT, env);
  const tc = await getTenantCtx(env, TENANT);
  return jsonOk({ success:true, role:rows[0].role, name:rows[0].name||'', token, tenantId:TENANT, tenantName:tc.name });
}

// getDashboard
async function hGetDashboard(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env, p.email, p.token, TENANT)) return jsonErr('無權限');
  let qs = `tenant_id=eq.${TENANT}&select=review_status,payment_status,amount,transfer_status,refund_amount`;
  if (p.sessionId) qs += `&session_id=eq.${encodeURIComponent(p.sessionId)}`;
  if (p.eventId)   qs += `&event_id=eq.${encodeURIComponent(p.eventId)}`;
  const [regs, sesCnt, evtCnt] = await Promise.all([
    dbGet(env, 'registrations', qs),
    dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&status=eq.報名中&select=id`),
    dbGet(env, 'events', `tenant_id=eq.${TENANT}&status=neq.停用&select=id`),
  ]);
  const paidList = regs.filter(r=>isPaidStatus(r.payment_status));
  return jsonOk({
    total:regs.length,
    pending:regs.filter(r=>r.review_status==='待審核').length,
    approved:regs.filter(r=>r.review_status==='已錄取').length,
    rejected:regs.filter(r=>r.review_status==='不錄取').length,
    paid:paidList.length,
    revenue:paidList.reduce((s,r)=>s+(Number(r.amount)||0),0) - regs.reduce((s,r)=>s+safeNum(r.refund_amount),0),
    sessionCount:sesCnt.length, eventCount:evtCnt.length,
  });
}

// getSessionDashboard
async function hGetSessionDashboard(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env, p.email, p.token, TENANT)) return jsonErr('無權限');

  // 單場模式：帶 sessionId 時只撈該場，不撈全部
  if (p.sessionId) {
    const [sesRows, regs, events] = await Promise.all([
      dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(p.sessionId)}&select=*`),
      dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(p.sessionId)}&select=*`),
      dbGet(env, 'events', `tenant_id=eq.${TENANT}&select=*`),
    ]);
    if (!sesRows.length) return jsonOk([]);
    const evtMap = {}; events.forEach(e=>evtMap[e.id]=e);
    const s = sesRows[0];
    const list = regs;
    const paid = list.filter(r=>isPaidStatus(r.payment_status));
    const refundReq = list.filter(r=>String(r.transfer_status||'')==='申請退費');
    const refundedAmount = list.reduce((sum,r)=>sum+safeNum(r.refund_amount),0);
    const approved = list.filter(r=>r.review_status==='已錄取'||isPaidStatus(r.payment_status));
    const equipNeed={}, equipAll={};
    approved.forEach(r=>{ const eq=safeJson(r.equipment_json,{}); Object.entries(eq).forEach(([k,v])=>{ if(Number(v)>0) equipNeed[k]=(equipNeed[k]||0)+Number(v); }); });
    list.forEach(r=>{ const eq=safeJson(r.equipment_json,{}); Object.entries(eq).forEach(([k,v])=>{ if(Number(v)>0) equipAll[k]=(equipAll[k]||0)+Number(v); }); });
    const evt = evtMap[s.event_id]||{};
    return jsonOk([{
      ...formatSession(s),
      eventName:evt.title||'', eventCover:evt.cover_url||'',
      total:list.length,
      pending:list.filter(r=>r.review_status==='待審核').length,
      approved:approved.length,
      rejected:list.filter(r=>r.review_status==='不錄取').length,
      paid:paid.length,
      seated:list.filter(r=>r.checkin_status==='已報到').length,
      revenue:Math.max(0,paid.reduce((s,r)=>s+(Number(r.amount)||0),0)-refundedAmount),
      depositTotal:paid.reduce((s,r)=>s+(Number(r.deposit)||0),0),
      refundReq:refundReq.length, refundedAmount,
      equipNeed, equipAll,
    }]);
  }

  // 總覽模式：不帶 sessionId 時撈全部（後台總覽頁使用）
  const [allRegs, sessions, events] = await Promise.all([
    dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&select=*`),
    dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&select=*`),
    dbGet(env, 'events', `tenant_id=eq.${TENANT}&select=*`),
  ]);
  const evtMap = {}; events.forEach(e=>evtMap[e.id]=e);
  return jsonOk(sessions.map(s=>{
    const list = allRegs.filter(r=>r.session_id===s.id);
    const paid = list.filter(r=>isPaidStatus(r.payment_status));
    const refundReq = list.filter(r=>String(r.transfer_status||'')==='申請退費');
    const refundedAmount = list.reduce((sum,r)=>sum+safeNum(r.refund_amount),0);
    const approved = list.filter(r=>r.review_status==='已錄取'||isPaidStatus(r.payment_status));
    const equipNeed={}, equipAll={};
    approved.forEach(r=>{ const eq=safeJson(r.equipment_json,{}); Object.entries(eq).forEach(([k,v])=>{ if(Number(v)>0) equipNeed[k]=(equipNeed[k]||0)+Number(v); }); });
    list.forEach(r=>{ const eq=safeJson(r.equipment_json,{}); Object.entries(eq).forEach(([k,v])=>{ if(Number(v)>0) equipAll[k]=(equipAll[k]||0)+Number(v); }); });
    const evt = evtMap[s.event_id]||{};
    return {
      ...formatSession(s),
      eventName:evt.title||'', eventCover:evt.cover_url||'',
      total:list.length,
      pending:list.filter(r=>r.review_status==='待審核').length,
      approved:approved.length,
      rejected:list.filter(r=>r.review_status==='不錄取').length,
      paid:paid.length,
      seated:list.filter(r=>r.checkin_status==='已報到').length,
      revenue:Math.max(0,paid.reduce((s,r)=>s+(Number(r.amount)||0),0)-refundedAmount),
      depositTotal:paid.reduce((s,r)=>s+(Number(r.deposit)||0),0),
      refundReq:refundReq.length, refundedAmount,
      equipNeed, equipAll,
    };
  }));
}

// getRegs
async function hGetRegs(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env, p.email, p.token, TENANT)) return jsonErr('無權限');
  let qs = `tenant_id=eq.${TENANT}&select=*`;
  if (p.sessionId) qs += `&session_id=eq.${encodeURIComponent(p.sessionId)}`;
  if (p.eventId)   qs += `&event_id=eq.${encodeURIComponent(p.eventId)}`;
  const rows = await dbGet(env, 'registrations', qs);
  return jsonOk(rows.map(r=>({
    id:r.id, sessionId:r.session_id, eventId:r.event_id,
    email:r.email, name:r.name, phone:r.phone,
    brand:r.brand_name, brandIntro:r.brand_intro||'', sellCat:r.sell_category,
    products:r.sell_items||'', photo:r.photo_url,
    fb:r.fb_url||'', ig:r.ig_url||'',
    equip:r.equipment_json, customFields:r.custom_fields_json,
    participants:safeJson(r.participants_json,{}),
    status:r.review_status, payStatus:r.payment_status,
    stallCount:safeNum(r.stall_count)||1,
    selectedDates:safeJson(r.selected_dates_json,[]),
    amount:safeNum(r.amount), totalAmount:safeNum(r.total_amount), deposit:safeNum(r.deposit),
    payMethod:r.payment_method||'', payLast5:r.payment_last5||'', payReportAmount:safeNum(r.payment_report_amount),
    paymentLineCardText:r.payment_line_card_text||'', paymentScreenshotStatus:r.payment_screenshot_status||'', paymentReportedAt:r.payment_reported_at||'',
    paidAt:r.paid_at||'',
    checkin:r.checkin_status, clearStatus:r.clear_status,
    depositRefunded:r.deposit_refunded||'未退押金',
    transferStatus:r.transfer_status||'', transferChosenAt:r.transfer_chosen_at||'',
    refundAmount:safeNum(r.refund_amount), refundAdminFee:safeNum(r.refund_admin_fee),
    refundTransferFee:safeNum(r.refund_transfer_fee), refundRuleLabel:r.refund_rule_label||'', refundedAt:r.refunded_at||'', refundNote:r.refund_note||'',
    adminNote:r.admin_note, createdAt:r.created_at,
    // ── 合約同意紀錄 ──────────────────────────────────
    agreementAccepted:      r.agreement_accepted || false,
    agreementViewed:        r.agreement_viewed   || false,
    agreementViewedAt:      r.agreement_viewed_at   || '',
    agreementAcceptedAt:    r.agreement_accepted_at || '',
    agreementEmail:         r.agreement_email    || '',
    agreementVersion:       r.agreement_version  || '',
    agreementTitleSnapshot: r.agreement_title_snapshot   || '',
  })));
}

// getRegsBySession
async function hGetRegsBySession(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env, p.email, p.token, TENANT)) return jsonErr('無權限');
  const sId = p.sessionId || p.session_id;
  if (!sId) return jsonErr('請提供 sessionId');
  const rows = await dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(sId)}&select=*`);
  return jsonOk(rows.map(r=>({
    id:r.id, sessionId:r.session_id, eventId:r.event_id,
    email:r.email, name:r.name, phone:r.phone,
    brand:r.brand_name, brandIntro:r.brand_intro||'',
    sellCat:r.sell_category||'', products:r.sell_items||'',
    fb:r.fb_url||'', ig:r.ig_url||'',
    stallCount:safeNum(r.stall_count)||1,
    equip:r.equipment_json||'{}',
    addonQty:safeJson(r.addon_qty_json,{}),
    selectedDates:safeJson(r.selected_dates_json,[]),
    customFields:safeJson(r.custom_fields_json,[]),
    participants:safeJson(r.participants_json,{}),
    status:r.review_status||'待審核',
    payStatus:r.payment_status||'未繳費',
    payMethod:r.payment_method||'',
    paidAt:r.paid_at||'',
    payLast5:r.payment_last5||'',
    payReportAmount:safeNum(r.payment_report_amount),
    amount:safeNum(r.amount), deposit:safeNum(r.deposit),
    checkin:r.checkin_status||'未報到',
    clearStatus:r.clear_status||'未清場',
    depositRefunded:r.deposit_refunded||'未退押金',
    refundAmount:safeNum(r.refund_amount), refundAdminFee:safeNum(r.refund_admin_fee),
    refundTransferFee:safeNum(r.refund_transfer_fee), refundRuleLabel:r.refund_rule_label||'',
    refundedAt:r.refunded_at||'', refundNote:r.refund_note||'',
    stallNo:r.stall_number||'',
    taxId:r.tax_id||'', invoiceTitle:r.invoice_title||'',
    invoiceEmail:r.invoice_email||'', invoiceStatus:r.invoice_status||'',
    transferStatus:r.transfer_status||'',
    createdAt:r.created_at||'', adminNote:r.admin_note||'',
  })));
}

// getStaff
async function hGetStaff(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,p.email,p.token,TENANT,'superadmin')) return jsonErr('無權限');
  const rows = await dbGet(env, 'staff', `tenant_id=eq.${TENANT}&select=*`);
  return jsonOk(rows.map(r=>({
    email:r.email, name:r.name, role:r.role,
    permsJson:r.perms_json||'{}',
    limitSessions:r.limit_sessions ? String(r.limit_sessions).split(',').filter(Boolean) : [],
    joinedAt:r.created_at,
  })));
}

// getEventsAdmin
async function hGetEventsAdmin(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env, p.email, p.token, TENANT)) return jsonErr('無權限');
  const rows = await dbGet(env, 'events', `tenant_id=eq.${TENANT}&select=*`);
  return jsonOk(rows.map(r=>({id:r.id,title:r.title,desc:r.description,location:r.location,cover:r.cover_url,status:r.status,createdAt:r.created_at})));
}

// getSessionsAdmin
async function hGetSessionsAdmin(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env, p.email, p.token, TENANT)) return jsonErr('無權限');
  let qs = `tenant_id=eq.${TENANT}&select=*`;
  if (p.eventId) qs += `&event_id=eq.${encodeURIComponent(p.eventId)}`;
  const [sessions, allRegs] = await Promise.all([
    dbGet(env, 'sessions', qs),
    dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&select=session_id,review_status,payment_status,amount,deposit`),
  ]);
  return jsonOk(sessions.map(s=>{
    const list = allRegs.filter(r=>r.session_id===s.id);
    const paid = list.filter(r=>isPaidStatus(r.payment_status));
    const fmt = formatSession(s);
    fmt.total   = list.length;
    fmt.pending  = list.filter(r=>r.review_status==='待審核').length;
    fmt.approved = list.filter(r=>r.review_status==='已錄取').length;
    fmt.paid     = paid.length;
    fmt.revenue  = paid.reduce((s,r)=>s+(Number(r.amount)||0),0);
    fmt.depositTotal = paid.reduce((s,r)=>s+(Number(r.deposit)||0),0);
    return fmt;
  }));
}

// getPayments
async function hGetPayments(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env, p.email, p.token, TENANT, 'finance')) return jsonErr('無權限');
  const rows = await dbGet(env, 'payments', `tenant_id=eq.${TENANT}&select=*`);
  return jsonOk(rows.map(r=>({id:r.id,regId:r.reg_id,sessionId:r.session_id,email:r.email,amount:r.amount,method:r.method,status:r.status,tradeNo:r.trade_no,paidAt:r.paid_at,createdAt:r.created_at})));
}

// getFinance
async function hGetFinance(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,p.email,p.token,TENANT,'finance')) return jsonErr('無權限');
  const sId = p.sessionId||p.session_id;
  if (!sId) return jsonErr('請提供 sessionId');
  const rows = await dbGet(env, 'finance_items', `tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(sId)}&select=*`);
  return jsonOk(rows.map(r=>({id:r.id,sessionId:r.session_id,type:r.type,name:r.name,amount:r.amount,isAuto:r.is_auto,createdAt:r.created_at})));
}

// getInvoiceList
async function hGetInvoiceList(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env, p.email, p.token, TENANT, 'finance')) return jsonErr('無權限');
  const sId = p.sessionId||p.session_id;
  if (!sId) return jsonErr('請提供 sessionId');
  const rows = await dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(sId)}&select=*`);
  return jsonOk(rows.map(r=>({
    id:r.id, email:r.email, name:r.name, brand:r.brand_name, phone:r.phone,
    invoiceType:r.tax_id ? '公司／機關' : '個人',
    taxId:r.tax_id||'', invoiceTitle:r.invoice_title||r.brand_name||'',
    invoiceEmail:r.invoice_email||r.email,
    deposit:safeNum(r.deposit), amount:safeNum(r.amount),
    untaxedAmount:Math.round(safeNum(r.amount)/1.05),
    taxAmount:Math.round(safeNum(r.amount)/1.05*0.05),
    invoiceStatus:r.invoice_status||'待開立',
    note:r.admin_note||'',
  })));
}

// getSiteConfig
async function hGetSiteConfig(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const rows = await dbGet(env, 'tenants', `id=eq.${TENANT}&select=config_json,line_url,bank_info`);
  if (!rows.length) return jsonOk({heroImg:'',infoText:''});
  const cfg = safeJson(rows[0].config_json, {});
  return jsonOk({
    heroImg:cfg.heroImg||'', infoText:cfg.infoText||'',
    lineUrl:rows[0].line_url||'',
    bankInfo:rows[0].bank_info||'',
  });
}

// getForceRefundList
async function hGetForceRefundList(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env, p.email, p.token, TENANT, 'finance')) return jsonErr('無權限');
  // 合併：舊版 transfer_status=申請退費 + 新版 force_status in (refund_requested, auto_refund_requested, refund_only_auto)
  const [legacy, forceRows] = await Promise.all([
    dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&transfer_status=eq.申請退費&select=*`),
    dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&force_status=in.(refund_requested,auto_refund_requested,refund_only_auto)&select=*`),
  ]);
  // 合併去重（同一筆報名不重複）
  const seen = new Set();
  const rows = [];
  for (const r of [...forceRows, ...legacy]) {
    if (!seen.has(r.id)) { seen.add(r.id); rows.push(r); }
  }
  // 取得場次名稱
  const sesIds = [...new Set(rows.map(r=>r.session_id).filter(Boolean))];
  const sesNames = {};
  if (sesIds.length) {
    const sesRows = await dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&id=in.(${sesIds.map(id=>encodeURIComponent(id)).join(',')})&select=id,name`);
    sesRows.forEach(s=>sesNames[s.id]=s.name||s.id);
  }
  return jsonOk(rows.map(r=>{
    const forceS = String(r.force_status||'');
    let applySource = '一般申請退費';
    if (forceS === 'auto_refund_requested') applySource = '逾期自動申請退費';
    else if (forceS === 'refund_only_auto') applySource = '無延期場次自動進入退費';
    else if (forceS === 'refund_requested') applySource = '主動申請退費（不可抗力）';
    return {
      id:r.id, sessionId:r.session_id, sessionName:sesNames[r.session_id]||r.session_id,
      email:r.email, name:r.name, brand:r.brand_name, phone:r.phone||'',
      amount:safeNum(r.amount), deposit:safeNum(r.deposit),
      payStatus:r.payment_status||'',
      transferChosenAt:r.transfer_chosen_at||'', depositRefunded:r.deposit_refunded||'未退押金',
      refundAmount:safeNum(r.refund_amount), refundAdminFee:safeNum(r.refund_admin_fee),
      refundTransferFee:safeNum(r.refund_transfer_fee), refundRuleLabel:r.refund_rule_label||'',
      refundedAt:r.refunded_at||'', refundNote:r.refund_note||'',
      // 不可抗力欄位
      forceStatus:forceS||'',
      applySource,
      forceRefundRequestedAt:r.force_refund_requested_at||r.transfer_chosen_at||'',
      forceRefundedAt:r.force_refunded_at||'',
      forceRefundNote:r.force_refund_note||'',
    };
  }));
}

// ── SECTION 12: POST Handlers ────────────────────────────────────

// register
async function hRegister(env, b, ctx) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const ses = await getSessionRow(env, b.sessionId, TENANT);
  if (!ses) return jsonErr('找不到場次');
  if (ses.status==='關閉'||ses.status==='停用') return jsonErr('此場次已關閉報名');

  // ── 合約同意驗證（後端硬性規則）──────────────────────────
  // 只要場次 agreement_required 不是 false，就必須收到完整同意
  const agreementRequired = ses.agreement_required !== false;
  if (agreementRequired) {
    if (!b.agreementViewed)   return jsonErr('請先點開並閱讀報名合約，才能送出報名。');
    if (!b.agreementAccepted) return jsonErr('請勾選同意報名合約後，才能送出報名。');
  }

  const sesType = ses.type||'市集場次';
  const stallMax = (sesType==='市集場次'||sesType==='通路寄賣') ? 3 : 10;
  const stallCount = Math.min(Math.max(parseInt(b.stallCount)||1,1),stallMax);
  const selectedDates = Array.isArray(b.selectedDates) ? b.selectedDates : [];
  const dates = safeJson(ses.dates_json, []);

  // 逐日名額檢查
  if (dates.length>0 && selectedDates.length>0) {
    const existing = await dbGet(env, 'registrations',
      `tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(b.sessionId)}&select=selected_dates_json,stall_count,review_status,registration_status,transfer_status`);
    for (const sd of selectedDates) {
      const def = dates.find(d=>d.date===sd);
      if (!def) continue;
      const dayLimit = Number(def.limit)||0;
      if (!dayLimit) continue;
      const dayUsed = existing.reduce((s,r)=>{
        if (!isActiveForCapacity(r)) return s;
        const rd = safeJson(r.selected_dates_json,[]);
        return s+(rd.includes(sd)?(Number(r.stall_count)||1):0);
      },0);
      if (dayUsed+stallCount>dayLimit) return jsonErr(sd.slice(5).replace('-','/')+'當日名額不足，剩 '+(dayLimit-dayUsed)+' 攤');
    }
  } else {
    const cur = safeNum(ses.current_count), lim = safeNum(ses.limit_count);
    if (lim>0 && cur+stallCount>lim) return jsonErr('名額不足，剩 '+(lim-cur)+' 攤');
  }

  // H-02：依 tenant_settings.module_flags_json.requireSocialLinks 決定是否強制 FB/IG
  try {
    const tsRows = await dbGet(env, 'tenant_settings', `tenant_id=eq.${TENANT}&select=module_flags_json`);
    const mf = safeJson(tsRows.length ? tsRows[0].module_flags_json : '{}', {});
    if (mf.requireSocialLinks === true) {
      const hasSocial = String(b.fb || b.fb_url || '').trim() || String(b.ig || b.ig_url || '').trim();
      if (!hasSocial) return jsonErr('FB 或 IG 連結為必填（至少填一個）');
    }
  } catch(e) { console.error('requireSocialLinks check skipped', e && e.message); }

  // 重複報名檢查（已取消也算，除了不錄取）
  const dup = await dbGet(env, 'registrations',
    `tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(b.sessionId)}&email=eq.${encodeURIComponent(b.email)}&review_status=not.in.(不錄取,已取消)&select=id`);
  if (dup.length) return jsonErr('您已報名此場次');

  // 審核規則以後台場次設定為唯一依據：需要審核→待審核，不需要審核→已錄取。
  // fast_pass 不覆蓋場次審核設定，避免需要審核的場次被自動放行。
  const needReview = ses.need_review===true||ses.need_review==='true';
  const status = needReview ? '待審核' : '已錄取';

  // 費用計算（後端計算）
  const fee = calcFee(ses, selectedDates, stallCount);
  const deposit = Number(ses.deposit)||0;
  const equipTotal = calcEquipTotal(b.equip||{}, ses.equip_json, stallCount, ses.basic_equip||'');
  let addonTotal=0;
  try {
    const addonDefs = safeJson(ses.addons_json,[]);
    const addonQty = b.addonQty||{};
    addonDefs.forEach((a,i)=>{ if(a&&a.open===true) addonTotal+=(Number(a.price)||0)*(Number(addonQty[i])||0); });
  } catch {}
  const total = fee+deposit+equipTotal+addonTotal;
  const pjSrc = (b.participantsJson && typeof b.participantsJson==='object') ? b.participantsJson : {};
  const adultCount = Math.max(0, parseInt(b.adultCount ?? pjSrc.adultCount ?? 0, 10) || 0);
  const childCount = Math.max(0, parseInt(b.childCount ?? pjSrc.childCount ?? 0, 10) || 0);
  const childAgesRaw = Array.isArray(b.childAges) ? b.childAges : (Array.isArray(pjSrc.childAges) ? pjSrc.childAges : []);
  const childAges = childAgesRaw.slice(0, childCount).map(x=>Number(x)).filter(x=>Number.isFinite(x) && x>=0);
  const participantsJson = {adultCount, childCount, childAges, totalCount: adultCount + childCount};

  const invoiceStatus = ((b.needInvoice===false||b.invoiceType==='不需要')?'':'待開立');

  // M-01：在 insert 之前原子鎖定名額（claim 失敗直接返回，不寫報名資料）
  const claimResult = await dbRpc(env, 'claim_session_slot', {
    p_tenant_id: TENANT, p_session_id: b.sessionId, p_stall_count: stallCount
  });
  if (!claimResult || claimResult.ok === false) {
    return jsonErr(claimResult ? (claimResult.error || '名額不足') : '名額鎖定失敗，請稍後再試');
  }

  // 新增報名
  const id = genId('REG');
  try {
    await dbInsert(env, 'registrations', {
      id, tenant_id:TENANT,
      session_id:b.sessionId, event_id:cleanEventId(ses.event_id),
      email:b.email, name:b.name, phone:String(b.phone||''),
      brand_name:b.brand||'', brand_intro:b.brandIntro||'',
      sell_category:b.sellCat||b.sellCategory||'', sell_items:b.sellItem||'',
      sell_link:b.sellLink||'', photo_url:b.photo||'', fb_url:b.fb||'', ig_url:b.ig||'',
      equipment_json:(b.equip||{}),
      custom_fields_json:(b.customFields||[]),
      participants_json:participantsJson,
      stall_count:stallCount, deposit,
      review_status:status,
      payment_status:total===0?'免費':'未繳費',
      // H-01: pay_status 欄位廢棄，不再寫入
      amount:total, total_amount:total, addon_amount:addonTotal,
      checkin_status:'未報到', clear_status:'未清場',
      deposit_refunded:'未退押金', stall_number:'',
      selected_dates_json:selectedDates,
      addon_qty_json:(b.addonQty||{}),
      tax_id:b.taxId||'', invoice_title:b.invoiceTitle||'',
      invoice_type:b.invoiceType||'', invoice_email:b.invoiceEmail||'', invoice_carrier:b.invoiceCarrier||'',
      invoice_status:invoiceStatus,
      reminder_sent:false, created_at:nowIso(),
      // ── 合約同意快照 ──────────────────────────────────────
      agreement_accepted:         agreementRequired ? true : (b.agreementAccepted===true),
      agreement_viewed:           agreementRequired ? true : (b.agreementViewed===true),
      agreement_viewed_at:        agreementRequired ? nowIso() : null,
      agreement_accepted_at:      agreementRequired ? nowIso() : null,
      agreement_email:            b.email || '',
      agreement_version:          ses.agreement_version || '',
      agreement_title_snapshot:   ses.agreement_title  || '',
      agreement_content_snapshot: ses.agreement_content || '',
    });
  } catch(e) {
    // FIX-02：registrations 寫入失敗，將名額還回去
    try {
      await dbRpc(env, 'release_session_slot', {
        p_tenant_id: TENANT, p_session_id: b.sessionId, p_stall_count: stallCount
      });
    } catch(re) { console.error('release_session_slot failed after register error', re&&re.message); }
    return jsonErr('報名建立失敗，請稍後再試（名額已釋放）');
  }

  // 建立財務明細：押金獨立列，不列入發票
  try {
    await createRegistrationFinanceRecords(env, TENANT, id, b.sessionId, b.email, fee, deposit, equipTotal, addonTotal, {
      invoice_status: invoiceStatus,
      invoice_type: b.invoiceType || '',
      invoice_title: b.invoiceTitle || '',
      tax_id: b.taxId || '',
      invoice_email: b.invoiceEmail || '',
      invoice_carrier: b.invoiceCarrier || '',
    });
  } catch(e) {
    console.error('create registration finance records skipped', e && e.message ? e.message : e);
  }

  // M-01：current_count 已由 claim_session_slot RPC 原子更新，此處不再重複寫入

  // Upsert 會員
  await upsertMember(env, b);

  // 攤位預留
  if (b.stallNumber) {
    try { await holdStall(env, b.sessionId, b.stallNumber, id, b.email||'', TENANT); } catch {}
  }

  // 報名成功後寄送既有正式版報名確認信（不改信件文案）。寄信失敗不阻斷資料寫入。
  try {
    const tcReg = await getTenantCtx(env, TENANT);
    const dn = getDisplayName(b.name, b.brand || '', sesType);
    await mailRegConfirm(env, b.email, dn, ses.name || b.sessionId, id, total, stallCount, selectedDates, b.equip || {}, tcReg);
  } catch(e) {
    console.error('mailRegConfirm after register failed:', e && e.message ? e.message : String(e));
  }
  return jsonOk({success:true, id, status, total});
}


async function createRegistrationFinanceRecords(env, TENANT, regId, sessionId, email, fee, deposit, equipTotal, addonTotal, invoicePayload) {
  const items = [];
  if (safeNum(fee) > 0) items.push({id:genId('ITEM'), tenant_id:TENANT, registration_id:regId, session_id:sessionId, item_type:'stall_fee', item_name:'報名費／攤位費', quantity:1, unit_price:safeNum(fee), amount:safeNum(fee), tax_included:true, meta_json:{}});
  if (safeNum(deposit) > 0) items.push({id:genId('ITEM'), tenant_id:TENANT, registration_id:regId, session_id:sessionId, item_type:'deposit', item_name:'押金', quantity:1, unit_price:safeNum(deposit), amount:safeNum(deposit), tax_included:false, meta_json:{excludeFromInvoice:true}});
  if (safeNum(equipTotal) > 0) items.push({id:genId('ITEM'), tenant_id:TENANT, registration_id:regId, session_id:sessionId, item_type:'equipment', item_name:'設備費', quantity:1, unit_price:safeNum(equipTotal), amount:safeNum(equipTotal), tax_included:false, meta_json:{}});
  if (safeNum(addonTotal) > 0) items.push({id:genId('ITEM'), tenant_id:TENANT, registration_id:regId, session_id:sessionId, item_type:'addon', item_name:'加購項目', quantity:1, unit_price:safeNum(addonTotal), amount:safeNum(addonTotal), tax_included:true, meta_json:{}});
  for (const it of items) await dbInsert(env, 'registration_items', it);

  const invoiceTotal = safeNum(fee) + safeNum(equipTotal) + safeNum(addonTotal);
  if (invoiceTotal > 0 && invoicePayload && invoicePayload.invoice_status) {
    const untaxed = Math.round(invoiceTotal / 1.05);
    const tax = invoiceTotal - untaxed;
    await dbInsert(env, 'invoices', {
      id: genId('INV'),
      tenant_id: TENANT,
      reg_id: regId,
      session_id: sessionId,
      invoice_type: invoicePayload.invoice_type || '',
      invoice_title: invoicePayload.invoice_title || '',
      tax_id: invoicePayload.tax_id || '',
      invoice_email: invoicePayload.invoice_email || email || '',
      invoice_carrier: invoicePayload.invoice_carrier || '',
      amount_total: invoiceTotal,
      amount_untaxed: untaxed,
      tax_amount: tax,
      status: invoicePayload.invoice_status,
      note: '2BL V8 自動建立：押金不列入發票',
      created_at: nowIso(),
    });
  }
}

// upsertMember
async function upsertMember(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!b.email) return;
  const now = nowIso();
  const rows = await dbGet(env, 'members', `tenant_id=eq.${TENANT}&email=eq.${encodeURIComponent(b.email)}&select=joined_at`);
  const data = {
    email:b.email, tenant_id:TENANT,
    name:b.name||'', phone:String(b.phone||''),
    brand_name:b.brand||'', brand_intro:b.brandIntro||'',
    sell_category:b.sellCat||b.sellCategory||'',
    photo_url:b.photo||'', fb_url:b.fb||'', ig_url:b.ig||'',
    collab_url:b.collabUrl||'', collab_desc:b.collabDesc||'',
    company:b.company||b.invoiceTitle||'', tax_id:b.taxId||'',
    invoice_type:b.invoiceType||'', invoice_title:b.invoiceTitle||b.company||'',
    invoice_email:b.invoiceEmail||'', invoice_carrier:b.invoiceCarrier||'',
    collab_items:b.collabItems||'', city:b.city||'', line_id:b.lineId||'', updated_at:now,
  };
  if (!rows.length) {
    data.joined_at = now; data.fast_pass = false;
    await dbInsert(env, 'members', data);
  } else {
    data.joined_at = rows[0].joined_at;
    await dbUpdate(env, 'members', `email=eq.${encodeURIComponent(b.email)}&tenant_id=eq.${TENANT}`, data);
  }
}

// holdStall helper
async function holdStall(env, sessionId, stallNumber, regId, email, tenantId) {
  const TENANT = tenantId ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const rows = await dbGet(env, 'stalls', `tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(sessionId)}&stall_no=eq.${encodeURIComponent(stallNumber)}&select=*`);
  if (!rows.length) return;
  const s = rows[0];
  if ((s.status==='鎖定'||s.status==='預留') && s.reg_id!==regId) return;
  await dbUpdate(env, 'stalls', `id=eq.${s.id}&tenant_id=eq.${TENANT}`, {status:'預留',reg_id:regId,email,hold_time:nowIso()});
}

// saveMember
async function hSaveMember(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!b.email) return jsonErr('請提供 email');
  await upsertMember(env, b);
  return jsonOk({success:true});
}

// cancelReg
async function hCancelReg(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const rows = await dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (b.email && String(reg.email||'').toLowerCase()!==String(b.email||'').toLowerCase()) return jsonErr('無權限取消此報名');
  if (isPaidStatus(reg.payment_status)) return jsonErr('已繳費報名不可直接取消，請走退款申請流程');
  if (isCapacityInactiveTransferStatus(reg.transfer_status)) return jsonErr('此報名已進入退款或退費完成流程，不能用取消流程處理');
  if (String(reg.review_status||'')==='已取消' || String(reg.registration_status||'')==='cancelled') return jsonOk({success:true, alreadyCancelled:true});
  const wasActiveCapacity = isActiveForCapacity(reg);
  const oldNote = String(reg.admin_note||'').trim();
  const append = `[前台] 取消未繳費／待確認報名 ${nowTaipeiText()}`;
  await dbUpdate(env, 'registrations', `id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`, {review_status:'已取消', registration_status:'cancelled', transfer_status:null, admin_note:(oldNote ? oldNote + ' ' : '') + append});
  // 釋出名額：只在原本仍有效佔用名額時扣回，避免重複取消多扣
  if (wasActiveCapacity) await adjustSessionCurrentCount(env, TENANT, reg.session_id, -(safeNum(reg.stall_count)||1));
  // 釋出攤位
  try {
    const st = await dbGet(env, 'stalls', `tenant_id=eq.${TENANT}&reg_id=eq.${encodeURIComponent(b.regId)}&select=id`);
    for (const s of st) await dbUpdate(env, 'stalls', `id=eq.${s.id}&tenant_id=eq.${TENANT}`, {status:'空閒',reg_id:null,email:null,hold_time:null});
  } catch {}
  // 通知信
  try {
    const sesName = await getSessionName(env, reg.session_id, TENANT);
    const dn = getDisplayName(reg.name, reg.brand_name||'', '');
    const tc = await getTenantCtx(env, TENANT);
    await mailCancelReg(env, reg.email, dn, sesName, tc);
  } catch {}
  return jsonOk({success:true});
}

// selectStall
async function hSelectStall(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const stalls = Array.isArray(b.stalls)?b.stalls:(b.stalls?[b.stalls]:(b.stallNumber?[b.stallNumber]:[]));
  if (!stalls.length) return jsonErr('請選擇攤位');
  if (!b.regId) return jsonErr('請提供報名編號');
  if (!b.sessionId) return jsonErr('請提供場次編號');

  const regRows = await dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!regRows.length) return jsonErr('找不到報名紀錄');
  const reg = regRows[0];
  if (String(reg.session_id||'') !== String(b.sessionId||'')) return jsonErr('報名與場次不一致，不能選位');
  if (b.email && reg.email && String(reg.email).toLowerCase() !== String(b.email).toLowerCase()) return jsonErr('無權限選擇此報名的攤位');
  if (String(reg.review_status||'') !== '已錄取') return jsonErr('尚未錄取，不能選位');
  if (!(isPaidStatus(reg.payment_status) || String(reg.payment_status||'') === '免費')) return jsonErr('尚未完成付款，不能選位');
  if (String(reg.review_status||'') === '已取消') return jsonErr('此報名已取消，不能選位');
  if (isCapacityInactiveTransferStatus(reg.transfer_status)) return jsonErr('此報名已進入退費流程，不能選位');
  const maxStalls = Math.max(1, Number(reg.stall_count)||1);
  if (stalls.length > maxStalls) return jsonErr('選位數量不可超過報名攤位數');

  const all = await dbGet(env, 'stalls', `tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(b.sessionId)}&select=*`);
  for (const num of stalls) {
    const s = all.find(x=>(x.stall_no||x.number)===num);
    if (!s) return jsonErr('找不到攤位 '+num);
    if ((s.status==='鎖定'||s.status==='預留')&&s.reg_id!==b.regId) return jsonErr('攤位 '+num+' 已被選走');
  }
  const myOld = all.filter(s=>s.reg_id===b.regId&&!stalls.includes(s.stall_no||s.number));
  for (const s of myOld) await dbUpdate(env, 'stalls', `id=eq.${s.id}&tenant_id=eq.${TENANT}`, {status:'空閒',reg_id:null,email:null,hold_time:null});
  for (const num of stalls) {
    const s = all.find(x=>(x.stall_no||x.number)===num);
    await dbUpdate(env, 'stalls', `id=eq.${s.id}&tenant_id=eq.${TENANT}`, {status:'鎖定',reg_id:b.regId,email:reg.email||b.email||'',hold_time:nowIso()});
  }
  await dbUpdate(env, 'registrations', `id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`, {stall_number:stalls.join(',')});
  return jsonOk({success:true, stalls});
}

// submitPayment（攤友回報匯款）
async function hSubmitPayment(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const rows = await dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名紀錄');
  const reg = rows[0];
  if (reg.email && b.email && String(reg.email).toLowerCase() !== String(b.email).toLowerCase()) return jsonErr('無權限回報此報名');
  if (reg.review_status!=='已錄取') return jsonErr('尚未錄取，無法回報繳費');
  if (isPaidStatus(reg.payment_status)) return jsonErr('此報名已完成繳費');
  const now = nowIso();
  const method = b.method || '匯款';
  const amount = Number(b.amount)||Number(reg.total_amount)||Number(reg.amount)||0;
  const isBank = /ATM|銀行|轉帳|匯款/.test(String(method));
  const last5 = isBank ? String(b.lastFive||b.last5||'').trim() : '';
  if (isBank && !last5) return jsonErr('ATM／銀行轉帳需填帳號末五碼');
  const sesName = await getSessionName(env, reg.session_id, TENANT);
  const cardText = buildPaymentLineCardText(reg, sesName, method, amount);
  const note = (reg.admin_note||'')+` [攤友回報] ${method} NT$${amount||''}${last5?' 末5碼:'+last5:''} 時間:${nowTaipeiText()}`;
  await dbUpdate(env, 'registrations', `id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`, {
    payment_status:'待確認', payment_method:method,
    payment_report_amount:amount, payment_last5:last5, payment_reported_at:now,
    admin_note:note,
  });
  // 選配欄位：若資料庫尚未新增，不能讓付款回報失敗。
  try {
    await dbUpdate(env, 'registrations', `id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`, {
      payment_line_card_text:cardText,
      payment_screenshot_status:'待補截圖',
    });
  } catch(e) { console.error('optional payment columns update skipped', e.message||e); }
  try {
    const existingPayRows = await dbGet(env,'payments',`tenant_id=eq.${TENANT}&reg_id=eq.${encodeURIComponent(b.regId)}&status=eq.待確認&select=id`);
    if (existingPayRows.length) {
      await dbUpdate(env,'payments',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(existingPayRows[0].id)}`,{session_id:reg.session_id,email:reg.email,amount,method,status:'待確認',trade_no:last5,paid_at:null,created_at:now});
    } else {
      await dbInsert(env,'payments',{id:genId('PAY'),tenant_id:TENANT,reg_id:b.regId,session_id:reg.session_id,email:reg.email,amount,method,status:'待確認',trade_no:last5,paid_at:null,created_at:now});
    }
  } catch(e) { console.error('payments upsert pending failed', e.message||e); }
  try {
    const sesType = await getSessionType(env, reg.session_id, TENANT);
    const dn = getDisplayName(reg.name, reg.brand_name||'', sesType);
    const tc = await getTenantCtx(env, TENANT);
    await mailPaymentReceived(env, reg.email, dn, sesName, method, amount, last5, b.regId, tc);
  } catch(e) { console.error('mailPaymentReceived failed:', e&&e.message?e.message:e); }
  return jsonOk({success:true, lineCardText:cardText, paymentLineCardText:cardText, payStatus:'待確認'});
}

// createLinePayOrder
async function hCreateLinePayOrder(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  return jsonErr('目前採外部付款連結＋人工確認，未啟用 LINE Pay API');
  const rows = await dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (reg.review_status!=='已錄取') return jsonErr('尚未錄取');
  if (isPaidStatus(reg.payment_status)) return jsonErr('已完成繳費');
  const amount = Number(reg.amount)||0;
  if (amount<=0) return jsonErr('金額錯誤');
  const orderId = 'TBL'+Date.now().toString().slice(-12);
  const sesName = await getSessionName(env, reg.session_id, TENANT);
  const workerUrl = (env.WORKER_URL||WORKER_PUBLIC_URL).replace(/\/$/,'');
  const confirmUrl = workerUrl+'/?action=linePayConfirm&orderId='+orderId;
  const cancelUrl = workerUrl+'/?action=linePayCancel';
  const payload = {
    amount, currency:'TWD', orderId,
    packages:[{id:'pkg_'+orderId, amount, products:[{name:sesName.slice(0,50), quantity:1, price:amount}]}],
    redirectUrls:{confirmUrl, cancelUrl},
  };
  const secret = env.LINEPAY_SECRET||LINEPAY_SECRET;
  const channelId = env.LINEPAY_CHANNEL_ID||LINEPAY_CHANNEL_ID;
  const apiUrl = env.LINEPAY_API_URL||LINEPAY_API_URL;
  const nonce = crypto.randomUUID();
  const ts = Date.now().toString();
  const uri = '/v3/payments/request';
  const sig = await hmacSha256Base64(secret, secret+uri+JSON.stringify(payload)+nonce+ts);
  try {
    const res = await fetch(apiUrl+uri, {
      method:'POST', body:JSON.stringify(payload),
      headers:{'Content-Type':'application/json','X-LINE-ChannelId':channelId,'X-LINE-Authorization-Nonce':nonce,'X-LINE-Authorization-Date':ts,'X-LINE-Authorization':sig},
    });
    const data = await res.json();
    if (data.returnCode!=='0000') return jsonErr(data.returnMessage||'LINE Pay 錯誤');
    await dbInsert(env, 'payments', {id:genId('PAY'),tenant_id:TENANT,reg_id:b.regId,session_id:reg.session_id,email:reg.email,amount,method:'LINE Pay',status:'待付款',trade_no:orderId,created_at:nowIso()});
    return jsonOk({success:true, paymentUrl:data.info.paymentUrl.web});
  } catch(e) { return jsonErr('LINE Pay 連線失敗: '+e.message); }
}

// createEcpayOrder
async function hCreateEcpayOrder(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  return jsonErr('目前採外部付款連結＋人工確認，未啟用信用卡 API');
  const rows = await dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (reg.review_status!=='已錄取') return jsonErr('尚未錄取');
  if (isPaidStatus(reg.payment_status)) return jsonErr('已完成繳費');
  const amount = Number(reg.amount)||0;
  if (amount<=0) return jsonErr('金額錯誤');
  const merchantId = env.ECPAY_MERCHANT_ID||ECPAY_MERCHANT_ID;
  const hashKey = env.ECPAY_HASH_KEY||ECPAY_HASH_KEY;
  const hashIv = env.ECPAY_HASH_IV||ECPAY_HASH_IV;
  const apiUrl = env.ECPAY_API_URL||ECPAY_API_URL;
  const tradeNo = 'TBL'+Date.now().toString().slice(-10);
  const now = new Date();
  const pad = n=>String(n).padStart(2,'0');
  const td = `${now.getFullYear()}/${pad(now.getMonth()+1)}/${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
  const sesName = await getSessionName(env, reg.session_id, TENANT);
  const workerUrl = (env.WORKER_URL||WORKER_PUBLIC_URL).replace(/\/$/,'');
  const params = {
    MerchantID:merchantId, MerchantTradeNo:tradeNo, MerchantTradeDate:td,
    PaymentType:'aio', TotalAmount:String(amount),
    TradeDesc:encodeURIComponent(((await getTenantCtx(env,TENANT)).name||FALLBACK_TENANT_NAME)+'報名費'),
    ItemName:encodeURIComponent(sesName||'報名費'),
    ReturnURL:`${workerUrl}/?action=ecpayReturn`,
    OrderResultURL:(await getTenantCtx(env,TENANT)).siteUrl+'?pay_result=1',
    ChoosePayment:'ALL', EncryptType:'1', ClientBackURL:(await getTenantCtx(env,TENANT)).siteUrl,
  };
  params.CheckMacValue = await ecpayMac(params, hashKey, hashIv);
  await dbInsert(env, 'payments', {id:genId('PAY'),tenant_id:TENANT,reg_id:b.regId,session_id:reg.session_id,email:reg.email,amount,method:'綠界',status:'待付款',trade_no:tradeNo,created_at:nowIso()});
  return jsonOk({success:true, params, apiUrl});
}

async function ecpayMac(params, hashKey, hashIv) {
  const sorted = Object.keys(params).sort((a,b)=>a.toLowerCase().localeCompare(b.toLowerCase()));
  let str = 'HashKey='+hashKey+'&'+sorted.map(k=>k+'='+params[k]).join('&')+'&HashIV='+hashIv;
  str = encodeURIComponent(str).toLowerCase()
    .replace(/%20/g,'+').replace(/%21/g,'!').replace(/%28/g,'(')
    .replace(/%29/g,')').replace(/%2a/g,'*').replace(/%2d/g,'-')
    .replace(/%2e/g,'.').replace(/%5f/g,'_');
  return sha256Hex(str);
}

// createEvent
async function hCreateEvent(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'events')) return jsonErr('無權限');
  const id = genId('EVT');
  await dbInsert(env,'events',{id,tenant_id:TENANT,title:b.title,description:b.desc||'',location:b.location||'',cover_url:b.cover||'',status:'開放中',created_at:nowIso()});
  return jsonOk({success:true,id});
}
// updateEvent
async function hUpdateEvent(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'events')) return jsonErr('無權限');
  const data = {title:b.title,description:b.desc||'',location:b.location||'',cover_url:b.cover||''};
  if (b.status) data.status=b.status;
  await dbUpdate(env,'events',`id=eq.${encodeURIComponent(b.id)}&tenant_id=eq.${TENANT}`,data);
  return jsonOk({success:true});
}
// deleteEvent
async function hDeleteEvent(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'superadmin')) return jsonErr('無權限');
  await dbDelete(env,'events',`id=eq.${encodeURIComponent(b.id)}&tenant_id=eq.${TENANT}`);
  return jsonOk({success:true});
}

// createSession
async function hCreateSession(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'sessions')) return jsonErr('無權限');
  const id = genId('SES');
  await dbInsert(env,'sessions',{
    id, tenant_id:TENANT, event_id:cleanEventId(b.eventId),
    name:b.name, type:b.type||'市集場次', region:b.region||'',
    dates_json:JSON.stringify(b.dates||[]),
    venue:b.venue||'', fee:Number(b.fee)||0, deposit:Number(b.deposit)||0,
    limit_count:Number(b.limit)||0, max_stalls:Number(b.maxStalls)||0, current_count:0,
    status:'報名中', need_review:b.needReview?true:false,
    modules_json:JSON.stringify(b.modules||{}),
    equip_json:JSON.stringify(b.equip||{}),
    basic_equip:b.basicEquip||'',
    invoice_tax_json:JSON.stringify(b.invoiceTax||{stall:true,equip:false,extra:false}),
    theme:b.theme||'', organizer:b.organizer||'', co_organizer:b.coorg||'',
    portals:(b.portals||[]).join(','),
    custom_fields_json:JSON.stringify(b.customFields||[]),
    addons_json:JSON.stringify(b.addons||[]),
    cover_url:b.cover||'', description:b.desc||'',
    stall_list_json:JSON.stringify(b.stallList||[]),
    assigned_staff:(b.assignedStaff||[]).join(','),
    force_cancel:false, created_at:nowIso(),
    // ── 合約同意設定 ──────────────────────────────────
    agreement_required:   b.agreementRequired !== false,
    agreement_title:      b.agreementTitle || '報名合約／活動細則與攤商規範',
    agreement_content:    b.agreementContent || '',
    agreement_version:    b.agreementVersion || '',
    agreement_updated_at: nowIso(),
  });
  return jsonOk({success:true,id});
}
// updateSession
async function hUpdateSession(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'sessions')) return jsonErr('無權限');
  await dbUpdate(env,'sessions',`id=eq.${encodeURIComponent(b.id)}&tenant_id=eq.${TENANT}`,{
    event_id:cleanEventId(b.eventId), name:b.name, type:b.type||'市集場次', region:b.region||'',
    dates_json:JSON.stringify(b.dates||[]),
    venue:b.venue||'', fee:Number(b.fee)||0, deposit:Number(b.deposit)||0,
    limit_count:Number(b.limit)||0, max_stalls:Number(b.maxStalls)||0,
    status:b.status||'報名中', need_review:b.needReview?true:false,
    modules_json:JSON.stringify(b.modules||{}),
    equip_json:JSON.stringify(b.equip||{}),
    basic_equip:b.basicEquip||'',
    invoice_tax_json:JSON.stringify(b.invoiceTax||{stall:true,equip:false,extra:false}),
    theme:b.theme||'', organizer:b.organizer||'', co_organizer:b.coorg||'',
    portals:(b.portals||[]).join(','),
    custom_fields_json:JSON.stringify(b.customFields||[]),
    addons_json:JSON.stringify(b.addons||[]),
    cover_url:b.cover||'', description:b.desc||'',
    stall_list_json:JSON.stringify(b.stallList||[]),
    assigned_staff:(b.assignedStaff||[]).join(','),
    // ── 合約同意設定 ──────────────────────────────────
    agreement_required:   b.agreementRequired !== false,
    agreement_title:      b.agreementTitle || '報名合約／活動細則與攤商規範',
    agreement_content:    b.agreementContent || '',
    agreement_version:    b.agreementVersion || '',
    agreement_updated_at: nowIso(),
  });
  return jsonOk({success:true});
}
// deleteSession
async function hDeleteSession(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'superadmin')) return jsonErr('無權限');
  await dbDelete(env,'sessions',`id=eq.${encodeURIComponent(b.id)}&tenant_id=eq.${TENANT}`);
  return jsonOk({success:true});
}
// toggleSession
async function hToggleSession(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'sessions')) return jsonErr('無權限');
  const id = b.id||b.sessionId;
  const rows = await dbGet(env,'sessions',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(id)}&select=status`);
  if (!rows.length) return jsonErr('找不到場次');
  const next = rows[0].status==='關閉'?'報名中':'關閉';
  await dbUpdate(env,'sessions',`id=eq.${encodeURIComponent(id)}&tenant_id=eq.${TENANT}`,{status:next});
  return jsonOk({success:true, status:next});
}
// toggleSessionStatus（直接設定指定 status）
async function hToggleSessionStatus(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'sessions')) return jsonErr('無權限');
  await dbUpdate(env,'sessions',`id=eq.${encodeURIComponent(b.sessionId)}&tenant_id=eq.${TENANT}`,{status:b.status||'已截止'});
  return jsonOk({success:true});
}
// copySession
async function hCopySession(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'sessions')) return jsonErr('無權限');
  const rows = await dbGet(env,'sessions',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.id)}&select=*`);
  if (!rows.length) return jsonErr('找不到場次');
  const src = {...rows[0]};
  const newId = genId('SES');
  src.id=newId; src.name=(src.name||'')+'（複製）';
  src.current_count=0; src.status='報名中';
  src.force_cancel=false; src.force_cancel_target_id=null; src.force_cancel_deadline=null;
  src.created_at=nowIso();
  await dbInsert(env,'sessions',src);
  return jsonOk({success:true,id:newId});
}


async function applyReviewStatusChange(env, TENANT, reg, nextStatus, adminNote) {
  const beforeActive = isActiveForCapacity(reg);
  const upd = {review_status: nextStatus};
  if (adminNote) upd.admin_note = adminNote;
  await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(reg.id)}&tenant_id=eq.${TENANT}`,upd);
  const nextReg = {...reg, review_status: nextStatus};
  const afterActive = isActiveForCapacity(nextReg);
  if (beforeActive !== afterActive) {
    await adjustSessionCurrentCount(env, TENANT, reg.session_id, afterActive ? (safeNum(reg.stall_count)||1) : -(safeNum(reg.stall_count)||1));
    await writeAuditLog(env, TENANT, '', 'system', 'review_status_capacity_adjust', 'registrations', reg.id, {review_status:reg.review_status}, {review_status:nextStatus}, {capacity_delta:afterActive ? (safeNum(reg.stall_count)||1) : -(safeNum(reg.stall_count)||1)});
  }
}

// updateRegStatus（單筆）
async function hUpdateRegStatus(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'review')) return jsonErr('無權限');
  const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  await applyReviewStatusChange(env, TENANT, reg, b.status, b.adminNote);
  await sendStatusEmail(env, b.status, reg);
  return jsonOk({success:true});
}

// batchUpdateStatus（批次）
async function hBatchUpdateStatus(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'review')) return jsonErr('無權限');
  const results=[];
  for (const regId of (b.regIds||[])) {
    try {
      const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(regId)}&select=*`);
      if (!rows.length) { results.push({error:'找不到報名'}); continue; }
      const reg = rows[0];
      await applyReviewStatusChange(env, TENANT, reg, b.status, b.adminNote);
      await sendStatusEmail(env, b.status, reg);
      results.push({success:true});
    } catch(e) { results.push({error:e.message}); }
  }
  return jsonOk({success:true, results});
}

// 共用：依審核狀態寄信
async function sendStatusEmail(env, status, reg) {
  const TENANT = (reg && reg.tenant_id) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  try {
    const sesName = await getSessionName(env, reg.session_id, TENANT);
    const sesType = await getSessionType(env, reg.session_id, TENANT);
    const dn = getDisplayName(reg.name, reg.brand_name||'', sesType);
    const tc = await getTenantCtx(env, TENANT);
    if (status==='已錄取') {
      const sr = await dbGet(env,'sessions',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(reg.session_id)}&select=basic_equip`);
      const be = sr.length?sr[0].basic_equip||'':'';
      await mailApproval(env,reg.email,dn,sesName,reg.id,Number(reg.amount)||0,reg.stall_count,safeJson(reg.selected_dates_json,[]),reg.equipment_json,be,tc);
    }
    if (status==='不錄取') await mailRejection(env,reg.email,dn,sesName,tc);
  } catch {}
}

// approveReg（與 updateRegStatus 功能相同，保留接口相容性）
async function hApproveReg(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'review')) return jsonErr('無權限');
  const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  const status = b.status||(b.approved?'已錄取':'不錄取');
  await applyReviewStatusChange(env, TENANT, reg, status, b.adminNote);
  await sendStatusEmail(env, status, reg);
  return jsonOk({success:true, status});
}

// confirmPayment（後台手動確認）
async function hConfirmPayment(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token, TENANT, 'finance')) return jsonErr('無權限');
  const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (String(reg.review_status||'') !== '已錄取') return jsonErr('尚未錄取，不能確認付款');
  if (isPaidStatus(reg.payment_status)) return jsonErr('此報名已完成繳費，不能重複確認');
  if (isCapacityInactiveTransferStatus(reg.transfer_status)) return jsonErr('此報名已進入退費流程，不能確認付款');
  const now = nowIso();
  const method = b.method || reg.payment_method || '手動確認';
  const amount = safeNum(reg.payment_report_amount) || safeNum(reg.total_amount) || safeNum(reg.amount);
  await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`,{
    payment_status:'已繳費', payment_method:method, paid_at:now,
  });
  try {
    const pendingPayRows = await dbGet(env,'payments',`tenant_id=eq.${TENANT}&reg_id=eq.${encodeURIComponent(b.regId)}&status=eq.待確認&select=id`);
    if (pendingPayRows.length) {
      for (const pr of pendingPayRows) {
        await dbUpdate(env,'payments',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(pr.id)}`,{session_id:reg.session_id,email:reg.email,amount,method,status:'已確認',trade_no:b.merchantTradeNo||reg.payment_last5||'',paid_at:now});
      }
    } else {
      await dbInsert(env,'payments',{id:genId('PAY'),tenant_id:TENANT,reg_id:b.regId,session_id:reg.session_id,email:reg.email,amount,method,status:'已確認',trade_no:b.merchantTradeNo||reg.payment_last5||'',paid_at:now,created_at:now});
    }
  } catch(e) {
    console.error('payments confirm update failed', e && e.message ? e.message : e);
  }
  try { await dbUpdate(env,'stalls',`tenant_id=eq.${TENANT}&reg_id=eq.${encodeURIComponent(b.regId)}&status=eq.預留`,{status:'鎖定'}); } catch {}
  const sesName = await getSessionName(env, reg.session_id, TENANT);
  const sesType = await getSessionType(env, reg.session_id, TENANT);
  const dn = getDisplayName(reg.name, reg.brand_name||'', sesType);
  let equipStr='';
  try { const eq=safeJson(reg.equipment_json,{}); equipStr=Object.entries(eq).filter(([k,v])=>v>0).map(([k,v])=>k+'x'+v).join('、'); } catch {}
  const tc = await getTenantCtx(env, TENANT);
  try { await mailPaymentConfirm(env,reg.email,dn,sesName,amount,equipStr,reg.stall_number||'',tc); } catch {}
  return jsonOk({success:true});
}

// markPaymentScreenshot（後台標記已回報客服／已收到匯款截圖）
async function hMarkPaymentScreenshot(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token, TENANT)) return jsonErr('無權限');
  const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (isPaidStatus(reg.payment_status)) return jsonErr('此報名已確認付款，不需再標記客服回報');
  if (String(reg.review_status||'')==='已取消') return jsonErr('此報名已取消，不能標記客服回報');
  const now = nowIso();
  const oldNote = String(reg.admin_note||'').trim();
  const append = `[後台] 已回報客服／已收到匯款截圖 ${nowTaipeiText()}`;
  const data = {
    payment_screenshot_status:'已回報客服',
    payment_screenshot_received_at:now,
    admin_note:(oldNote ? oldNote + ' ' : '') + append,
  };
  await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`,data);
  try {
    await dbUpdate(env,'payments',`tenant_id=eq.${TENANT}&reg_id=eq.${encodeURIComponent(b.regId)}&status=eq.待確認`,{
      screenshot_status:'已回報客服',
      screenshot_received_at:now,
      admin_note:append,
    });
  } catch(e) { console.error('payments screenshot optional update skipped', e&&e.message?e.message:e); }
  return jsonOk({success:true, paymentScreenshotStatus:'已回報客服', paymentScreenshotReceivedAt:now});
}

// adminCancelReg（後台取消未繳費／待確認報名，保留資料不刪除）
async function hAdminCancelReg(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token, TENANT)) return jsonErr('無權限');
  const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (isPaidStatus(reg.payment_status)) return jsonErr('已繳費報名不可直接取消，請走退款申請流程');
  if (isCapacityInactiveTransferStatus(reg.transfer_status)) return jsonErr('此報名已進入退款或退費完成流程，不能用取消流程處理');
  if (String(reg.review_status||'')==='已取消' || String(reg.registration_status||'')==='cancelled') return jsonOk({success:true, alreadyCancelled:true});
  const wasActiveCapacity = isActiveForCapacity(reg);
  const now = nowIso();
  const oldNote = String(reg.admin_note||'').trim();
  const append = `[後台] 取消未繳費／待確認報名 ${nowTaipeiText()}`;
  await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`,{
    review_status:'已取消',
    registration_status:'cancelled',
    transfer_status:null,
    admin_note:(oldNote ? oldNote + ' ' : '') + append,
  });
  try {
    if (wasActiveCapacity) await adjustSessionCurrentCount(env, TENANT, reg.session_id, -(safeNum(reg.stall_count)||1));
  } catch(e) { console.error('admin cancel session count skipped', e&&e.message?e.message:e); }
  try {
    const st = await dbGet(env, 'stalls', `tenant_id=eq.${TENANT}&reg_id=eq.${encodeURIComponent(b.regId)}&select=id`);
    for (const s of st) await dbUpdate(env, 'stalls', `id=eq.${s.id}&tenant_id=eq.${TENANT}`, {status:'空閒',reg_id:null,email:null,hold_time:null});
  } catch(e) { console.error('admin cancel stall release skipped', e&&e.message?e.message:e); }
  return jsonOk({success:true, status:'已取消'});
}

// refundDeposit
async function hRefundDeposit(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token, TENANT, 'finance')) return jsonErr('無權限');
  const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=review_status,payment_status,transfer_status,deposit`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (String(reg.review_status||'') === '已取消') return jsonErr('已取消報名不可退押金');
  if (['申請退費','已退費'].includes(String(reg.transfer_status||''))) return jsonErr('退費中或已退費報名不可走退押金流程');
  if (!(isPaidStatus(reg.payment_status) || String(reg.payment_status||'') === '免費')) return jsonErr('尚未完成付款，不能退押金');
  await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`,{deposit_refunded:'已退押金'});
  return jsonOk({success:true});
}

// checkin
async function hCheckin(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'checkin')) return jsonErr('無權限');
  const undo = b.undo===true||b.undo==='true';
  const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=review_status,payment_status,transfer_status`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (!undo) {
    if (reg.review_status !== '已錄取') return jsonErr('尚未錄取，不能報到');
    if (!(isPaidStatus(reg.payment_status) || reg.payment_status === '免費')) return jsonErr('尚未完成繳費，不能報到');
    if (['申請退費','已退費'].includes(String(reg.transfer_status||''))) return jsonErr('此報名已進入退費流程，不能報到');
  }
  await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`,
    undo ? {checkin_status:null,checkin_at:null} : {checkin_status:'已報到',checkin_at:nowIso()});
  return jsonOk({success:true, undo});
}

// markClear（已清場）
async function hMarkClear(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'checkin')) return jsonErr('無權限');
  const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=review_status,payment_status,transfer_status`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (String(reg.review_status||'') !== '已錄取') return jsonErr('尚未錄取，不能清場');
  if (!(isPaidStatus(reg.payment_status) || String(reg.payment_status||'') === '免費')) return jsonErr('尚未完成付款，不能清場');
  if (['申請退費','已退費'].includes(String(reg.transfer_status||''))) return jsonErr('此報名已進入退費流程，不能清場');
  const data = {clear_status:'已清場'};
  if (b.refunded) data.deposit_refunded='已退押金';
  await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`,data);
  return jsonOk({success:true});
}

// sendNotify
async function hSendNotify(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const ok = (await verifyStaff(env,b.email,b.token,TENANT,'review'))||(await verifyStaff(env,b.email,b.token,TENANT,'announce'));
  if (!ok) return jsonErr('無權限');
  let qs = `tenant_id=eq.${TENANT}&select=email,name,review_status`;
  if (b.sessionId) qs+=`&session_id=eq.${encodeURIComponent(b.sessionId)}`;
  if (b.regId) qs+=`&id=eq.${encodeURIComponent(b.regId)}`;
  let rows = await dbGet(env,'registrations',qs);
  if (b.target&&b.target!=='all') rows=rows.filter(r=>r.review_status===b.target);
  let sent=0;
  for (const r of rows) if(r.email) { try { await sendEmail(env,r.email,b.subject,b.content); sent++; } catch {} }
  return jsonOk({success:true, sent});
}

// resendInvite
async function hResendInvite(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'superadmin')) return jsonErr('無權限');
  const rows = await dbGet(env,'staff',`tenant_id=eq.${TENANT}&email=eq.${encodeURIComponent(b.targetEmail)}&select=*`);
  if (!rows.length) return jsonErr('找不到此管理員');
  const s=rows[0];
  const ls=s.limit_sessions?String(s.limit_sessions).split(',').filter(Boolean):[];
  const tc = await getTenantCtx(env, TENANT);
  try { await mailStaffInvite(env,s.email,s.name||'',s.role||'活動夥伴',safeJson(s.perms_json,{}),ls,tc); } catch(e) { return jsonErr('寄信失敗：'+e.message); }
  return jsonOk({success:true});
}

// addStaff
async function hAddStaff(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'superadmin')) return jsonErr('無權限');
  const ex = await dbGet(env,'staff',`tenant_id=eq.${TENANT}&email=eq.${encodeURIComponent(b.targetEmail)}&select=email`);
  if (ex.length) return jsonErr('此帳號已存在');
  await dbInsert(env,'staff',{
    id:genId('STF'),
    email:b.targetEmail, tenant_id:TENANT, name:b.targetName||'',
    role:b.role||'活動夥伴', perms_json:JSON.stringify(b.perms||{}),
    limit_sessions:(b.limitSessions||[]).join(','), created_at:nowIso(),
  });
  const tcStaff = await getTenantCtx(env, TENANT);
  try { await mailStaffInvite(env,b.targetEmail,b.targetName||'',b.role||'活動夥伴',b.perms||{},b.limitSessions||[],tcStaff); } catch {}
  return jsonOk({success:true});
}
// removeStaff
async function hRemoveStaff(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'superadmin')) return jsonErr('無權限');
  await dbDelete(env,'staff',`email=eq.${encodeURIComponent(b.targetEmail)}&tenant_id=eq.${TENANT}`);
  return jsonOk({success:true});
}
// updateStaffPerms
async function hUpdateStaffPerms(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'superadmin')) return jsonErr('無權限');
  await dbUpdate(env,'staff',`email=eq.${encodeURIComponent(b.targetEmail)}&tenant_id=eq.${TENANT}`,{perms_json:JSON.stringify(b.perms||{})});
  return jsonOk({success:true});
}
// updateStaffSessions
async function hUpdateStaffSessions(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'superadmin')) return jsonErr('無權限');
  await dbUpdate(env,'staff',`email=eq.${encodeURIComponent(b.targetEmail)}&tenant_id=eq.${TENANT}`,{limit_sessions:(b.sessions||[]).join(',')});
  return jsonOk({success:true});
}

// saveAnnouncement
async function hSaveAnnouncement(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'announce')) return jsonErr('無權限');
  if (b.id) {
    await dbUpdate(env,'announcements',`id=eq.${encodeURIComponent(b.id)}&tenant_id=eq.${TENANT}`,{title:b.title,content:b.content||'',url:b.url||'',url_text:b.urlText||''});
    return jsonOk({success:true});
  }
  const id=genId('ANN');
  await dbInsert(env,'announcements',{id,tenant_id:TENANT,title:b.title,content:b.content||'',url:b.url||'',url_text:b.urlText||'',created_at:nowIso()});
  return jsonOk({success:true,id});
}
// deleteAnnouncement
async function hDeleteAnnouncement(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'announce')) return jsonErr('無權限');
  await dbDelete(env,'announcements',`id=eq.${encodeURIComponent(b.id)}&tenant_id=eq.${TENANT}`);
  return jsonOk({success:true});
}

// saveFinanceItem
async function hSaveFinanceItem(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'finance')) return jsonErr('無權限');
  const id=genId('FIN');
  await dbInsert(env,'finance_items',{id,tenant_id:TENANT,session_id:b.sessionId,type:b.type,name:b.name,amount:Number(b.amount)||0,is_auto:b.auto?true:false,created_at:nowIso()});
  return jsonOk({success:true,id});
}
// deleteFinanceItem
async function hDeleteFinanceItem(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'finance')) return jsonErr('無權限');
  await dbDelete(env,'finance_items',`id=eq.${encodeURIComponent(b.id)}&tenant_id=eq.${TENANT}`);
  return jsonOk({success:true});
}
// updateInvoiceStatus
async function hUpdateInvoiceStatus(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token, TENANT)) return jsonErr('無權限');
  await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`,{invoice_status:b.status});
  return jsonOk({success:true});
}

// initStalls
async function hInitStalls(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'sessions')) return jsonErr('無權限');
  await dbDelete(env,'stalls',`session_id=eq.${encodeURIComponent(b.sessionId)}&tenant_id=eq.${TENANT}`);
  const numbers=(b.stallNumbers||'').split(/[,，\n\r]/).map(s=>s.trim()).filter(Boolean);
  for (const num of numbers) await dbInsert(env,'stalls',{id:genId('STL'),tenant_id:TENANT,session_id:b.sessionId,stall_no:num,status:'空閒',reg_id:null,email:null,hold_time:null,created_at:nowIso()});
  return jsonOk({success:true, count:numbers.length});
}
// saveStallConfig
async function hSaveStallConfig(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'sessions')) return jsonErr('無權限');
  const ex = await dbGet(env,'stalls',`tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(b.sessionId)}&status=eq.空閒&select=id`);
  for (const s of ex) await dbDelete(env,'stalls',`id=eq.${s.id}&tenant_id=eq.${TENANT}`);
  for (const num of (b.stalls||[])) await dbInsert(env,'stalls',{id:genId('STL'),tenant_id:TENANT,session_id:b.sessionId,stall_no:num,status:'空閒',reg_id:null,email:null,hold_time:null,created_at:nowIso()});
  return jsonOk({success:true});
}
// setFastPass
async function hSetFastPass(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'checkin')) return jsonErr('無權限');
  const rows = await dbGet(env,'members',`tenant_id=eq.${TENANT}&email=eq.${encodeURIComponent(b.targetEmail)}&select=email`);
  if (!rows.length) return jsonErr('找不到會員');
  await dbUpdate(env,'members',`email=eq.${encodeURIComponent(b.targetEmail)}&tenant_id=eq.${TENANT}`,{fast_pass:b.enable?true:false});
  return jsonOk({success:true});
}
// saveSiteConfig
async function hSaveSiteConfig(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'superadmin')) return jsonErr('無權限');
  // 先讀現有 config_json，再合併，保留 brandColor/portals/siteUrl 等其他欄位
  const existing = await dbGet(env,'tenants',`id=eq.${TENANT}&select=config_json`);
  const oldCfg = existing.length ? safeJson(existing[0].config_json, {}) : {};
  const config = {...oldCfg, heroImg:b.heroImg||'', infoText:b.infoText||''};
  await dbUpdate(env,'tenants',`id=eq.${TENANT}`,{config_json:JSON.stringify(config)});
  return jsonOk({success:true});
}


// getAgreementTemplates（取得所有範本，最多3款，向下相容舊資料）
async function hGetAgreementTemplate(env, p) {
  const TENANT = (p && p._tenantId);
  const rows = await dbGet(env, 'tenant_agreement_templates',
    `tenant_id=eq.${TENANT}&select=*&order=created_at.asc`);
  // 向下相容：舊資料沒有 slot_no，自動指派為 slot 1
  const slotMap = {};
  rows.forEach((r, i) => {
    const slot = (r.slot_no && r.slot_no >= 1 && r.slot_no <= 3) ? r.slot_no : (i + 1);
    if (!slotMap[slot]) slotMap[slot] = r;
  });
  const result = [1,2,3].map(slot => {
    const r = slotMap[slot] || {};
    return {
      slot_no: slot,
      label: r.label || (slot === 1 && r.title ? '預設合約' : `範本${slot}`),
      title: r.title || '',
      content: r.content || '',
      version: r.version || '',
    };
  });
  return jsonOk(result);
}

// saveAgreementTemplate（儲存指定 slot 的範本）
async function hSaveAgreementTemplate(env, b) {
  const TENANT = (b && b._tenantId);
  if (!await verifyStaff(env, b.email, b.token, TENANT, 'superadmin')) return jsonErr('無權限');
  const slot = Number(b.slot_no) || 1;
  if (slot < 1 || slot > 3) return jsonErr('slot_no 必須為 1~3');
  const now = new Date().toISOString();
  const rows = await dbGet(env, 'tenant_agreement_templates',
    `tenant_id=eq.${TENANT}&slot_no=eq.${slot}&select=id`);
  if (rows.length) {
    await dbUpdate(env, 'tenant_agreement_templates',
      `tenant_id=eq.${TENANT}&slot_no=eq.${slot}`, {
      label: b.label || `範本${slot}`,
      title: b.title || '',
      content: b.content || '',
      version: b.version || '',
      updated_at: now,
    });
  } else {
    await dbInsert(env, 'tenant_agreement_templates', {
      id: genId('AGT'),
      tenant_id: TENANT,
      slot_no: slot,
      label: b.label || `範本${slot}`,
      title: b.title || '',
      content: b.content || '',
      version: b.version || '',
      updated_at: now,
      created_at: now,
    });
  }
  return jsonOk({ ok: true });
}

// forceCancel（不可抗力宣告）
async function hForceCancel(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token,TENANT,'sessions')) return jsonErr('無權限');
  const dl = new Date(); dl.setHours(dl.getHours()+48);
  await dbUpdate(env,'sessions',`id=eq.${encodeURIComponent(b.sessionId)}&tenant_id=eq.${TENANT}`,{
    force_cancel:true, force_cancel_target_id:b.targetSessionId||null, force_cancel_deadline:dl.toISOString(),
  });
  const sesName = await getSessionName(env, b.sessionId, TENANT);
  let targetSesName='';
  if (b.targetSessionId) targetSesName=await getSessionName(env, b.targetSessionId, TENANT);
  const dlStr=`${dl.getMonth()+1}/${dl.getDate()} ${dl.getHours()}:00`;
  const regs = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(b.sessionId)}&review_status=in.(已錄取,待審核)&select=*`);
  const tcForce = await getTenantCtx(env, TENANT);
  for (const r of regs) {
    const st = await getSessionType(env, r.session_id, TENANT);
    const dn = getDisplayName(r.name,r.brand_name||'',st);
    try { await mailForceCancelChoice(env,r.email,dn,sesName,targetSesName,dlStr,tcForce); } catch {}
  }
  return jsonOk({success:true, notified:regs.length});
}

// agreeTransfer（延期）
async function hAgreeTransfer(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  // 身份驗證：前台必須傳入 email，驗證與報名 email 吻合（不可讓不相關者觸發延期）
  if (!b.email) return jsonErr('請提供 email');
  if (String(reg.email||'').toLowerCase() !== String(b.email||'').toLowerCase()) return jsonErr('無權限操作此報名');
  const now = nowIso();
  await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`,{
    transfer_status:'已延期', transfer_target_session_id:b.targetSessionId, transfer_chosen_at:now,
  });
  const newSes = await getSessionRow(env, b.targetSessionId, TENANT);
  if (!newSes) return jsonErr('找不到目標場次');
  const newRegId = genId('REG');
  const newFee = calcFee(newSes, safeJson(reg.selected_dates_json,[]), reg.stall_count);
  const newTotal = newFee+(Number(newSes.deposit)||0);
  await dbInsert(env,'registrations',{
    id:newRegId, tenant_id:TENANT,
    session_id:b.targetSessionId, event_id:cleanEventId(newSes.event_id),
    email:reg.email, name:reg.name, phone:reg.phone,
    brand_name:reg.brand_name||'', brand_intro:reg.brand_intro||'',
    sell_category:reg.sell_category||'', sell_items:reg.sell_items||'',
    sell_link:reg.sell_link||'', photo_url:reg.photo_url||'',
    equipment_json:reg.equipment_json||'{}',
    custom_fields_json:reg.custom_fields_json||'{}',
    stall_count:reg.stall_count, deposit:Number(newSes.deposit)||0,
    review_status:'已錄取',
    payment_status:isPaidStatus(reg.payment_status)?reg.payment_status:'未繳費',
    amount:newTotal, total_amount:newTotal,
    checkin_status:'未報到', clear_status:'未清場', deposit_refunded:'未退押金',
    stall_number:'', selected_dates_json:reg.selected_dates_json||'[]',
    original_session_id:reg.session_id, created_at:now,
  });
  // M-01：延期新場次名額扣減改用原子 RPC
  await dbRpc(env, 'claim_session_slot', {
    p_tenant_id: TENANT, p_session_id: b.targetSessionId, p_stall_count: (safeNum(reg.stall_count)||1)
  });
  const oldFee = Number(reg.amount||0);
  const dn = getDisplayName(reg.name, reg.brand_name||'', newSes.type||'');
  const tcTransfer = await getTenantCtx(env, TENANT);
  try {
    if (newTotal!==oldFee) await mailTransferDiffFee(env,reg.email,dn,newSes.name,newTotal,oldFee,tcTransfer);
    else await mailTransferSameFee(env,reg.email,dn,newSes.name,tcTransfer);
  } catch {}
  return jsonOk({success:true, newRegId});
}


// ── AA8-2 退款規則：由資料庫規則帶出行政費建議，退款金額由扣項自動計算 ──
function firstSessionDateValue(ses, reg) {
  const selected = safeJson(reg && reg.selected_dates_json, []);
  if (Array.isArray(selected) && selected.length) return selected[0];
  const dates = safeJson(ses && ses.dates_json, []);
  if (Array.isArray(dates) && dates.length) return dates.map(d=>d.date||d.startDate||d.day||'').filter(Boolean)[0] || '';
  return (ses && (ses.date || ses.start_date || ses.start_at)) || '';
}
function daysBeforeEvent(eventDateValue, baseIso) {
  if (!eventDateValue) return null;
  const eventDate = new Date(String(eventDateValue).slice(0,10) + 'T00:00:00+08:00');
  const baseDate = new Date(String(baseIso || nowIso()).slice(0,10) + 'T00:00:00+08:00');
  if (isNaN(eventDate.getTime()) || isNaN(baseDate.getTime())) return null;
  return Math.floor((eventDate.getTime() - baseDate.getTime()) / 86400000);
}
function normalizeRefundRules(rawRules) {
  const rulesObj = rawRules && typeof rawRules === 'object' ? rawRules : DEFAULT_REFUND_RULES;
  const list = Array.isArray(rulesObj.rules) && rulesObj.rules.length ? rulesObj.rules : DEFAULT_REFUND_RULES.rules;
  return { transferFeeDefault: safeNum(rulesObj.transferFeeDefault), rules:list };
}
function pickRefundRule(rulesObj, daysBefore) {
  const rules = normalizeRefundRules(rulesObj).rules;
  if (daysBefore === null || daysBefore === undefined) return { key:'manual', label:'無法自動判斷日期，請主辦手動確認', adminFeeType:'fixed', adminFee:0 };
  const sorted = rules.slice().sort((a,b)=>(Number(b.minDays)||-9999)-(Number(a.minDays)||-9999));
  return sorted.find(rule=>{
    const min = rule.minDays === undefined ? -9999 : Number(rule.minDays);
    const max = rule.maxDays === undefined ? 99999 : Number(rule.maxDays);
    return daysBefore >= min && daysBefore <= max;
  }) || sorted[sorted.length-1] || DEFAULT_REFUND_RULES.rules[DEFAULT_REFUND_RULES.rules.length-1];
}
function calcAdminFeeByRule(rule, paidAmount) {
  const paid = safeNum(paidAmount);
  if (!rule) return 0;
  if (rule.adminFeeType === 'percent') return Math.round(paid * (Number(rule.adminFeePercent)||0) / 100);
  return Math.min(paid, safeNum(rule.adminFee));
}
async function calcRefundSuggestion(env, TENANT, reg) {
  const [sesRows, tenantCtx] = await Promise.all([
    dbGet(env,'sessions',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(reg.session_id)}&select=*`),
    getTenantCtx(env,TENANT)
  ]);
  const ses = sesRows[0] || {};
  const sessionRules = safeJson(ses.refund_rules_json, null);
  const rulesObj = normalizeRefundRules(sessionRules || tenantCtx.defaultRefundRules || DEFAULT_REFUND_RULES);
  const paidAmount = safeNum(reg.amount || reg.total_amount);
  const requestDate = reg.transfer_chosen_at || nowIso();
  const eventDate = firstSessionDateValue(ses, reg);
  const daysBefore = daysBeforeEvent(eventDate, requestDate);
  const rule = pickRefundRule(rulesObj, daysBefore);
  const refundAdminFee = Math.min(paidAmount, calcAdminFeeByRule(rule, paidAmount));
  const refundTransferFee = Math.min(Math.max(0, paidAmount - refundAdminFee), safeNum(rulesObj.transferFeeDefault));
  const refundAmount = Math.max(0, paidAmount - refundAdminFee - refundTransferFee);
  return {
    paidAmount,
    eventDate: eventDate || '',
    requestDate,
    daysBefore,
    refundRuleKey: rule.key || '',
    refundRuleLabel: rule.label || '主辦手動確認',
    refundAdminFee,
    refundTransferFee,
    refundAmount,
  };
}

// getRefundSuggestion（後台開啟退費彈窗時，從 Worker 依資料庫規則帶出建議扣項）
async function hGetRefundSuggestion(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token, TENANT, 'finance')) return jsonErr('無權限');
  const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (!isPaidStatus(reg.payment_status)) return jsonErr('此報名尚未完成付款，不能退費');
  const suggestion = await calcRefundSuggestion(env, TENANT, reg);
  return jsonOk({success:true, ...suggestion});
}

// applyRefund（攤友申請退費）
async function hApplyRefund(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (b.email && reg.email && String(reg.email).toLowerCase() !== String(b.email).toLowerCase()) return jsonErr('無權限申請退款');
  if (!isPaidStatus(reg.payment_status)) return jsonErr('尚未確認付款，不能申請退款');
  if (['申請退費','退費中','refund_pending'].includes(String(reg.transfer_status||''))) return jsonOk({success:true, duplicate:true});
  if (['已退費','refunded'].includes(String(reg.transfer_status||'')) || String(reg.registration_status||'')==='refunded') return jsonErr('此報名已完成退費');
  const wasActiveCapacity = isActiveForCapacity(reg);
  await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`,{transfer_status:'退費中',transfer_chosen_at:nowIso()});
  if (wasActiveCapacity) {
    await adjustSessionCurrentCount(env, TENANT, reg.session_id, -(safeNum(reg.stall_count)||1));
    await writeAuditLog(env, TENANT, b.email || reg.email, 'member', 'refund_requested_release_capacity', 'registrations', b.regId, {transfer_status:reg.transfer_status, registration_status:reg.registration_status}, {transfer_status:'退費中'}, {capacity_delta:-(safeNum(reg.stall_count)||1)});
  }
  try {
    const sesName = await getSessionName(env, reg.session_id, TENANT);
    const sesType = await getSessionType(env, reg.session_id, TENANT);
    const dn = getDisplayName(reg.name,reg.brand_name||'',sesType);
    const tc = await getTenantCtx(env, TENANT);
    await mailRefundRequestReceived(env,reg.email,dn,sesName,tc);
  } catch(e) { console.error('mailRefundRequestReceived failed:', e&&e.message?e.message:e); }
  return jsonOk({success:true});
}

// confirmRefund（後台確認退款）
async function hConfirmRefund(env, b) {
  const TENANT = (b && b._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  if (!await verifyStaff(env,b.email,b.token, TENANT, 'finance')) return jsonErr('無權限');
  const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (!isPaidStatus(reg.payment_status)) return jsonErr('此報名尚未完成付款，不能退費');
  if (['已退費','refunded'].includes(String(reg.transfer_status||'')) || String(reg.registration_status||'')==='refunded') return jsonErr('此報名已完成退費');
  const wasActiveCapacity = isActiveForCapacity(reg);
  const paidAmount = safeNum(reg.amount || reg.total_amount);
  const refundAdminFee = safeNum(b.refundAdminFee ?? b.refund_admin_fee);
  const refundTransferFee = safeNum(b.refundTransferFee ?? b.refund_transfer_fee);
  if (refundAdminFee < 0 || refundTransferFee < 0) return jsonErr('扣項金額不可小於 0');
  if (refundAdminFee + refundTransferFee > paidAmount) return jsonErr('行政費與轉帳手續費不可大於已繳金額');
  const refundAmount = Math.max(0, paidAmount - refundAdminFee - refundTransferFee);
  const suggestion = await calcRefundSuggestion(env, TENANT, reg);
  const ruleLabel = String(b.refundRuleLabel || b.refund_rule_label || suggestion.refundRuleLabel || '主辦手動確認').slice(0,120);
  const upd={
    transfer_status:'已退費',
    payment_status:'已退費',
    registration_status:'refunded',
    // H-01: pay_status 欄位已廢棄，僅更新 payment_status
    refund_amount:refundAmount,
    refund_admin_fee:refundAdminFee,
    refund_transfer_fee:refundTransferFee,
    refund_rule_label:ruleLabel,
    refunded_at:nowIso(),
    refund_note:String(b.refundNote||'').slice(0,500),
  };
  await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`,upd);
  if (wasActiveCapacity) {
    await adjustSessionCurrentCount(env, TENANT, reg.session_id, -(safeNum(reg.stall_count)||1));
  }
  try {
    const st = await dbGet(env, 'stalls', `tenant_id=eq.${TENANT}&reg_id=eq.${encodeURIComponent(b.regId)}&select=id`);
    for (const s of st) await dbUpdate(env, 'stalls', `id=eq.${s.id}&tenant_id=eq.${TENANT}`, {status:'空閒',reg_id:null,email:null,hold_time:null});
  } catch(e) { console.error('refund stall release skipped', e&&e.message?e.message:e); }
  await writeAuditLog(env, TENANT, b.email || '', 'finance_admin', 'refund_confirmed_release_capacity_and_stall', 'registrations', b.regId, {transfer_status:reg.transfer_status, registration_status:reg.registration_status}, upd, {capacity_delta:wasActiveCapacity ? -(safeNum(reg.stall_count)||1) : 0, stall_release:true});
  const sesName = await getSessionName(env, reg.session_id, TENANT);
  const sesType = await getSessionType(env, reg.session_id, TENANT);
  const dn = getDisplayName(reg.name,reg.brand_name||'',sesType);
  const tc = await getTenantCtx(env, TENANT);
  try { await mailRefundConfirm(env,reg.email,dn,sesName,tc); } catch {}
  return jsonOk({success:true, paidAmount, refundAmount, refundAdminFee, refundTransferFee, refundRuleLabel:ruleLabel});
}

// ── SECTION 12-FM: 不可抗力取消／延期／退款模組 ─────────────────

// 1. previewForceCancelSession（GET：預覽不可抗力影響人數，不寫入資料）
async function hPreviewForceCancelSession(env, p) {
  const TENANT = (p && p._tenantId) ;
  if (!await verifyStaff(env, p.email, p.token, TENANT)) return jsonErr('無權限');
  const sesId = p.sessionId || p.session_id;
  if (!sesId) return jsonErr('請提供 sessionId');
  const sesRows = await dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(sesId)}&select=*`);
  if (!sesRows.length) return jsonErr('找不到場次');
  const ses = sesRows[0];
  if (ses.force_cancelled) return jsonErr('此場次已啟動不可抗力處理，不可重複啟動');
  const forceMode = p.forceMode || p.force_mode || '';
  if (!['transfer_or_refund','refund_only'].includes(forceMode)) return jsonErr('請選擇處理模式（transfer_or_refund 或 refund_only）');
  const regs = await dbGet(env, 'registrations',
    `tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(sesId)}&select=review_status,payment_status,registration_status,transfer_status`);
  const tier1 = [], tier2 = [], tier3 = [];
  for (const r of regs) {
    const layer = classifyForceLayer(r);
    if (layer === 1) tier1.push(r);
    else if (layer === 2) tier2.push(r);
    else tier3.push(r);
  }
  return jsonOk({
    ok: true,
    sessionId: sesId,
    sessionName: ses.name || sesId,
    forceMode,
    eligible_count: tier1.length,    // 第一層：可選延期或退費
    notice_only_count: tier2.length, // 第二層：只通知
    skip_count: tier3.length,        // 第三層：不進入流程
    total: regs.length,
    breakdown: {
      tier1_labels: tier1.map(r=>({review_status:r.review_status,payment_status:r.payment_status})),
      tier2_labels: tier2.map(r=>({review_status:r.review_status,payment_status:r.payment_status})),
    },
  });
}

// 2. forceCancelSession（POST：正式啟動不可抗力處理）
async function hForceCancelSession(env, b) {
  const TENANT = (b && b._tenantId) ;
  if (!await verifyStaff(env, b.email, b.token, TENANT, 'sessions')) return jsonErr('無權限');
  const sesId = b.sessionId || b.session_id;
  if (!sesId) return jsonErr('請提供 sessionId');
  const reasonCode = b.reasonCode || b.reason_code || '';
  if (!FORCE_REASON_CODES[reasonCode]) return jsonErr('不可抗力原因代碼不合法，請使用正確的 reason_code');
  const reasonLabel = FORCE_REASON_CODES[reasonCode];
  const forceMode = b.forceMode || b.force_mode || '';
  if (!['transfer_or_refund','refund_only'].includes(forceMode)) return jsonErr('請選擇正確的處理模式');
  if (forceMode === 'transfer_or_refund' && !(b.transferTargetSessionId||b.transfer_target_session_id)) return jsonErr('提供延期場次模式必須指定目標場次 ID');
  if (forceMode === 'refund_only' && (b.transferTargetSessionId||b.transfer_target_session_id)) return jsonErr('無延期模式不可指定延期目標場次');
  const targetSesId = (forceMode === 'transfer_or_refund') ? (b.transferTargetSessionId||b.transfer_target_session_id) : null;

  const sesRows = await dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(sesId)}&select=*`);
  if (!sesRows.length) return jsonErr('找不到場次');
  const ses = sesRows[0];
  if (ses.force_cancelled) return jsonErr('此場次已啟動不可抗力處理，不可重複啟動');
  if (targetSesId) {
    const tgtRows = await dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(targetSesId)}&select=id,name`);
    if (!tgtRows.length) return jsonErr('找不到延期目標場次');
  }

  const now = new Date();
  const deadline = new Date(now.getTime() + FORCE_CHOICE_HOURS * 60 * 60 * 1000);

  // 更新場次狀態
  await dbUpdate(env, 'sessions', `id=eq.${encodeURIComponent(sesId)}&tenant_id=eq.${TENANT}`, {
    force_cancelled: true,
    force_cancel_reason_code: reasonCode,
    force_cancel_reason_label: reasonLabel,
    force_cancel_note: b.note || '',
    force_cancelled_at: now.toISOString(),
    force_mode: forceMode,
    force_transfer_target_session_id: targetSesId || null,
    force_choice_deadline: deadline.toISOString(),
    status: '關閉',
    updated_at: now.toISOString(),
  });

  // 撈所有有效報名
  const regs = await dbGet(env, 'registrations',
    `tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(sesId)}&select=*`);
  const tc = await getTenantCtx(env, TENANT);
  let notified = 0, tier1cnt = 0, tier2cnt = 0, skipped = 0;
  const logEntries = [];

  for (const r of regs) {
    if (String(r.force_status||'').length > 0) continue; // 已有 force_status，跳過
    const layer = classifyForceLayer(r);
    let newForceStatus = 'no_force_action';
    if (layer === 1) {
      newForceStatus = (forceMode === 'refund_only') ? 'refund_only_auto' : 'pending_force_choice';
      tier1cnt++;
    } else if (layer === 2) {
      newForceStatus = 'cancel_notice_only';
      tier2cnt++;
    } else {
      newForceStatus = 'no_force_action';
      skipped++;
    }
    await dbUpdate(env, 'registrations', `id=eq.${encodeURIComponent(r.id)}&tenant_id=eq.${TENANT}`, {
      force_status: newForceStatus,
      ...(newForceStatus === 'refund_only_auto' ? { force_refund_requested_at: now.toISOString() } : {}),
    });
    logEntries.push({ id: genId('FML'), tenant_id: TENANT, registration_id: r.id, session_id: sesId,
      action: 'force_cancel_session', old_status: null, new_status: newForceStatus,
      actor_type: 'admin', actor_email: b.email || '', reason_code: reasonCode,
      target_session_id: targetSesId || null, note: `模式:${forceMode}`, created_at: now.toISOString() });
    // 寄不可抗力取消通知信
    if (layer <= 2 && r.email) {
      try {
        const sesType = ses.type || '';
        const dn = getDisplayName(r.name, r.brand_name||'', sesType);
        await mailForceCancelNotice(env, r.email, dn, ses.name||sesId, tc);
        notified++;
      } catch(e) { console.error('mailForceCancelNotice failed', r.email, e&&e.message); }
    }
  }
  // 批次寫入 log
  for (const entry of logEntries) { try { await dbInsert(env, 'force_majeure_logs', entry); } catch {} }

  // 更新寄信時間
  try {
    await dbUpdate(env, 'sessions', `id=eq.${encodeURIComponent(sesId)}&tenant_id=eq.${TENANT}`,
      { force_notice_sent_at: now.toISOString() });
  } catch {}

  return jsonOk({
    success: true, sessionId: sesId, reasonCode, reasonLabel, forceMode, targetSesId,
    notified, tier1: tier1cnt, tier2: tier2cnt, skipped,
    forceChoiceDeadline: deadline.toISOString(),
  });
}

// 3. agreeForceTransfer（POST：攤友同意延期 — 不可抗力專用）
async function hAgreeForceTransfer(env, b) {
  const TENANT = (b && b._tenantId) ;
  if (!b.email) return jsonErr('請提供 email');
  if (!b.regId) return jsonErr('請提供報名編號');
  const rows = await dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (String(reg.email||'').toLowerCase() !== String(b.email||'').toLowerCase()) return jsonErr('無權限操作此報名');
  if (String(reg.force_status||'') !== 'pending_force_choice') return jsonErr('此報名不在可選延期狀態，目前狀態：' + (reg.force_status||'無不可抗力流程'));

  const sesRows = await dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(reg.session_id)}&select=*`);
  if (!sesRows.length) return jsonErr('找不到原場次');
  const ses = sesRows[0];
  if (!ses.force_cancelled) return jsonErr('此場次尚未啟動不可抗力處理');
  if (ses.force_mode !== 'transfer_or_refund') return jsonErr('此場次不提供延期，只能申請退費');
  const targetSesId = ses.force_transfer_target_session_id;
  if (!targetSesId) return jsonErr('未設定延期目標場次');

  // 檢查逾期
  if (ses.force_choice_deadline && new Date() > new Date(ses.force_choice_deadline)) return jsonErr('選擇期限已過（48小時），已自動申請退費');

  // 檢查目標場次名額
  const tgtRows = await dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(targetSesId)}&select=*`);
  if (!tgtRows.length) return jsonErr('找不到延期目標場次');
  const tgtSes = tgtRows[0];
  const claimResult = await dbRpc(env, 'claim_session_slot', {
    p_tenant_id: TENANT, p_session_id: targetSesId, p_stall_count: safeNum(reg.stall_count)||1
  });
  if (!claimResult || claimResult.ok === false) {
    return jsonErr(claimResult ? (claimResult.error || '目標場次名額不足') : '名額鎖定失敗，請稍後再試');
  }

  const now = new Date();
  const nowStr = now.toISOString();
  // 建立新報名
  const newRegId = genId('REG');
  try {
    await dbInsert(env, 'registrations', {
      id: newRegId, tenant_id: TENANT,
      session_id: targetSesId, event_id: cleanEventId(tgtSes.event_id),
      email: reg.email, name: reg.name, phone: reg.phone||'',
      brand_name: reg.brand_name||'', brand_intro: reg.brand_intro||'',
      sell_category: reg.sell_category||'', sell_items: reg.sell_items||'',
      sell_link: reg.sell_link||'', photo_url: reg.photo_url||'',
      fb_url: reg.fb_url||'', ig_url: reg.ig_url||'',
      equipment_json: reg.equipment_json||'{}',
      custom_fields_json: reg.custom_fields_json||'[]',
      participants_json: reg.participants_json||'{}',
      stall_count: reg.stall_count||1, deposit: reg.deposit||0,
      review_status: '已錄取',
      payment_status: reg.payment_status,  // 沿用原付款狀態
      amount: reg.amount||0, total_amount: reg.total_amount||reg.amount||0,
      paid_at: reg.paid_at||null, payment_method: reg.payment_method||'',
      payment_last5: reg.payment_last5||'',
      addon_qty_json: reg.addon_qty_json||'{}', addon_amount: reg.addon_amount||0,
      selected_dates_json: reg.selected_dates_json||'[]',
      stall_number: '', checkin_status: '未報到', clear_status: '未清場',
      deposit_refunded: '未退押金', reminder_sent: false,
      original_session_id: reg.session_id,  // 原場次 ID
      transferred_from_registration_id: reg.id,  // 來自哪筆原始報名
      force_status: null,              // 延期建立的新報名本身是正常有效報名，不繼承 force_status
      force_choice_at: nowStr,
      force_choice_email: reg.email,
      created_at: nowStr,
    });
  } catch(e) {
    // FIX-03：新報名寫入失敗，將目標場次名額還回去
    try {
      await dbRpc(env, 'release_session_slot', {
        p_tenant_id: TENANT, p_session_id: targetSesId, p_stall_count: safeNum(reg.stall_count)||1
      });
    } catch(re) { console.error('release_session_slot failed after force transfer error', re&&re.message); }
    return jsonErr('延期處理失敗，請稍後再試（名額已釋放）');
  }
  // 更新原報名
  await dbUpdate(env, 'registrations', `id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`, {
    force_status: 'transferred',
    transferred_to_session_id: targetSesId,
    force_choice_at: nowStr,
    force_choice_email: reg.email,
    force_choice_ip: b._ip || null,
    force_choice_user_agent: b._userAgent || null,
  });
  // 寫 log
  try { await dbInsert(env, 'force_majeure_logs', { id:genId('FML'), tenant_id:TENANT,
    registration_id:b.regId, session_id:reg.session_id, action:'agree_force_transfer',
    old_status:'pending_force_choice', new_status:'transferred',
    actor_type:'member', actor_email:reg.email,
    target_session_id:targetSesId, note:`新報名:${newRegId}`,
    ip: b._ip||null, user_agent: b._userAgent||null,
    created_at:nowStr }); } catch {}
  // 信件
  try {
    const tc = await getTenantCtx(env, TENANT);
    const dn = getDisplayName(reg.name, reg.brand_name||'', ses.type||'');
    await mailForceTransferDone(env, reg.email, dn, ses.name||reg.session_id, tgtSes.name||targetSesId, safeNum(reg.amount), tc);
  } catch(e) { console.error('mailForceTransferDone failed', e&&e.message); }
  return jsonOk({ success:true, newRegId, transferredTo:targetSesId });
}

// 4. applyForceRefundFM（POST：攤友選擇申請退費 — 不可抗力專用）
async function hApplyForceRefundFM(env, b) {
  const TENANT = (b && b._tenantId) ;
  if (!b.email) return jsonErr('請提供 email');
  if (!b.regId) return jsonErr('請提供報名編號');
  const rows = await dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  if (String(reg.email||'').toLowerCase() !== String(b.email||'').toLowerCase()) return jsonErr('無權限操作此報名');
  const fs = String(reg.force_status||'');
  if (fs !== 'pending_force_choice') return jsonErr('此報名不在可申請退費狀態，目前狀態：' + (fs||'無不可抗力流程'));

  const sesRows = await dbGet(env, 'sessions', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(reg.session_id)}&select=force_choice_deadline,name,type`);
  const ses = sesRows[0]||{};
  if (ses.force_choice_deadline && new Date() > new Date(ses.force_choice_deadline)) return jsonErr('選擇期限已過');
  const now = nowIso();
  await dbUpdate(env, 'registrations', `id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`, {
    force_status: 'refund_requested',
    force_choice_at: now,
    force_choice_email: reg.email,
    force_choice_ip: b._ip || null,
    force_choice_user_agent: b._userAgent || null,
    force_refund_requested_at: now,
  });
  try { await dbInsert(env, 'force_majeure_logs', { id:genId('FML'), tenant_id:TENANT,
    registration_id:b.regId, session_id:reg.session_id, action:'apply_force_refund',
    old_status:'pending_force_choice', new_status:'refund_requested',
    actor_type:'member', actor_email:reg.email,
    ip: b._ip||null, user_agent: b._userAgent||null,
    created_at:now }); } catch {}
  // 無需寄信（前台顯示更新，主辦後台看退費清單）
  return jsonOk({ success:true, forceStatus:'refund_requested' });
}

// 5. runForceChoiceDeadline（POST：系統排程或手動執行 48 小時逾期處理）
async function hRunForceChoiceDeadline(env, b) {
  const TENANT = (b && b._tenantId) ;
  // 允許管理員手動執行，或由 cron 呼叫（cron 時 b.email/token 可為空）
  if (b.email && b.token) {
    if (!await verifyStaff(env, b.email, b.token, TENANT)) return jsonErr('無權限');
  }
  const now = new Date();
  // 找出所有已過期的 pending_force_choice
  let qsBase = `force_status=eq.pending_force_choice&select=*`;
  if (TENANT) qsBase = `tenant_id=eq.${TENANT}&` + qsBase;
  const regs = await dbGet(env, 'registrations', qsBase);
  // 取得對應場次的 force_choice_deadline
  const sesIds = [...new Set(regs.map(r=>r.session_id).filter(Boolean))];
  const sesDeadlines = {};
  if (sesIds.length) {
    const sesRows = await dbGet(env, 'sessions', sesIds.length === 1
      ? `id=eq.${encodeURIComponent(sesIds[0])}&select=id,force_choice_deadline,name,type`
      : `id=in.(${sesIds.map(s=>encodeURIComponent(s)).join(',')})&select=id,force_choice_deadline,name,type`);
    sesRows.forEach(s => sesDeadlines[s.id] = { deadline: s.force_choice_deadline, name: s.name, type: s.type });
  }
  let processed = 0;
  for (const r of regs) {
    const sesInfo = sesDeadlines[r.session_id];
    if (!sesInfo || !sesInfo.deadline) continue;
    if (now < new Date(sesInfo.deadline)) continue; // 尚未逾期
    const nowStr = now.toISOString();
    await dbUpdate(env, 'registrations', `id=eq.${encodeURIComponent(r.id)}&tenant_id=eq.${r.tenant_id}`, {
      force_status: 'auto_refund_requested',
      force_refund_requested_at: nowStr,
    });
    try { await dbInsert(env, 'force_majeure_logs', { id:genId('FML'), tenant_id:r.tenant_id,
      registration_id:r.id, session_id:r.session_id, action:'auto_refund_deadline_expired',
      old_status:'pending_force_choice', new_status:'auto_refund_requested',
      actor_type:'system', ip:null, user_agent:null,
      created_at:nowStr }); } catch {}
    processed++;
    // 寄逾期自動退費通知
    try {
      const tc = await getTenantCtx(env, r.tenant_id);
      const dn = getDisplayName(r.name, r.brand_name||'', sesInfo.type||'');
      await mailForceCancelNotice(env, r.email, dn, sesInfo.name||r.session_id, tc);
    } catch {}
  }
  return jsonOk({ success:true, processed });
}

// 6. confirmForceRefund（POST：後台確認不可抗力退款完成）
async function hConfirmForceRefund(env, b) {
  const TENANT = (b && b._tenantId) ;
  if (!await verifyStaff(env, b.email, b.token, TENANT)) return jsonErr('無權限');
  if (!b.regId) return jsonErr('請提供報名編號');
  const rows = await dbGet(env, 'registrations', `tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
  if (!rows.length) return jsonErr('找不到報名');
  const reg = rows[0];
  const fs = String(reg.force_status||'');
  if (!['refund_requested','auto_refund_requested','refund_only_auto','申請退費'].includes(fs) &&
      String(reg.transfer_status||'') !== '申請退費') {
    return jsonErr('此報名不在可確認退款狀態，force_status：' + (fs||'空'));
  }
  if (fs === 'refunded') return jsonErr('此報名已完成退費');
  const refundAmount = safeNum(b.refundAmount ?? b.refund_amount ?? reg.amount);
  if (refundAmount < 0) return jsonErr('退費金額不可小於 0');
  const nowStr = nowIso();
  await dbUpdate(env, 'registrations', `id=eq.${encodeURIComponent(b.regId)}&tenant_id=eq.${TENANT}`, {
    force_status: 'refunded',
    force_refunded_at: nowStr,
    force_refund_note: String(b.note||b.refundNote||'').slice(0,500),
    refund_amount: refundAmount,
    payment_status: '已退費',
    registration_status: 'refunded',
  });
  try { await dbInsert(env, 'force_majeure_logs', { id:genId('FML'), tenant_id:TENANT,
    registration_id:b.regId, session_id:reg.session_id, action:'confirm_force_refund',
    old_status:fs, new_status:'refunded', actor_type:'admin', actor_email:b.email||'',
    note:`退費金額:${refundAmount}`,
    ip: b._ip||null, user_agent: b._userAgent||null,
    created_at:nowStr }); } catch {}
  // 釋出攤位
  try {
    const st = await dbGet(env, 'stalls', `tenant_id=eq.${TENANT}&reg_id=eq.${encodeURIComponent(b.regId)}&select=id`);
    for (const s of st) await dbUpdate(env, 'stalls', `id=eq.${s.id}&tenant_id=eq.${TENANT}`, {status:'空閒',reg_id:null,email:null,hold_time:null});
  } catch {}
  // 寄退費完成信
  try {
    const tc = await getTenantCtx(env, TENANT);
    const sesName = await getSessionName(env, reg.session_id, TENANT);
    const sesType = await getSessionType(env, reg.session_id, TENANT);
    const dn = getDisplayName(reg.name, reg.brand_name||'', sesType);
    await mailForceRefundDone(env, reg.email, dn, sesName, refundAmount, tc);
  } catch(e) { console.error('mailForceRefundDone failed', e&&e.message); }
  return jsonOk({ success:true, forceStatus:'refunded', refundAmount });
}

// ── SECTION 13: ECPay / LINE Pay 回調 ───────────────────────────

// ECPay 付款回調（POST form）
async function handleEcpayReturn(env, params) {
  // 注意：ECPay 尚未正式啟用多租戶，此 callback 暫停處理
  // TODO: 待 ECPay 啟用時，需依 MerchantTradeNo 前綴解析租戶
  try {
    if (params.RtnCode!=='1') return new Response('0|RtnCode not 1',{status:200});
    const tradeNo = params.MerchantTradeNo;
    // 不限租戶查詢（由 trade_no 唯一性保證）
    const pays = await dbGet(env,'payments',`trade_no=eq.${encodeURIComponent(tradeNo)}&select=*`);
    if (!pays.length) return new Response('0|tradeNo not found',{status:200});
    const pay = pays[0];
    const TENANT = pay.tenant_id ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
    await dbUpdate(env,'payments',`id=eq.${pay.id}&tenant_id=eq.${TENANT}`,{status:'已確認',paid_at:nowIso()});
    const regs = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(pay.reg_id)}&select=*`);
    if (!regs.length) return new Response('0|reg not found',{status:200});
    const reg = regs[0];
    await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(pay.reg_id)}&tenant_id=eq.${TENANT}`,{payment_status:'已繳費',payment_method:'綠界',paid_at:nowIso()});
    try { await dbUpdate(env,'stalls',`tenant_id=eq.${TENANT}&reg_id=eq.${encodeURIComponent(pay.reg_id)}&status=eq.預留`,{status:'鎖定'}); } catch {}
    const sesName = await getSessionName(env, reg.session_id, TENANT);
    const sesType = await getSessionType(env, reg.session_id, TENANT);
    const dn = getDisplayName(reg.name,reg.brand_name||'',sesType);
    let equipStr=''; try { const eq=safeJson(reg.equipment_json,{}); equipStr=Object.entries(eq).filter(([k,v])=>v>0).map(([k,v])=>k+'x'+v).join('、'); } catch {}
    const tcEcpay = await getTenantCtx(env, TENANT);
    try { await mailPaymentConfirm(env,reg.email,dn,sesName,reg.amount,equipStr,reg.stall_number||'',tcEcpay); } catch {}
    return new Response('1|OK',{status:200});
  } catch(e) { return new Response('0|'+e.message,{status:200}); }
}

// LINE Pay confirm redirect（GET）
async function handleLinePayConfirm(env, p) {
  const TENANT = (p && p._tenantId) ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
  const {transactionId, orderId} = p;
  if (!transactionId||!orderId) return Response.redirect(FALLBACK_SITE_URL+'?linepay_cancel=1',302);
  try {
    const pays = await dbGet(env,'payments',`tenant_id=eq.${TENANT}&trade_no=eq.${encodeURIComponent(orderId)}&select=*`);
    if (!pays.length) return Response.redirect(FALLBACK_SITE_URL+'?pay_result=fail',302);
    const pay = pays[0];
    const secret = env.LINEPAY_SECRET||LINEPAY_SECRET;
    const channelId = env.LINEPAY_CHANNEL_ID||LINEPAY_CHANNEL_ID;
    const apiUrl = env.LINEPAY_API_URL||LINEPAY_API_URL;
    const uri = `/v3/payments/${transactionId}/confirm`;
    const nonce = crypto.randomUUID();
    const ts = Date.now().toString();
    const confirmBody={amount:Number(pay.amount),currency:'TWD'};
    const sig = await hmacSha256Base64(secret,secret+uri+JSON.stringify(confirmBody)+nonce+ts);
    const res = await fetch(apiUrl+uri,{
      method:'POST',body:JSON.stringify(confirmBody),
      headers:{'Content-Type':'application/json','X-LINE-ChannelId':channelId,'X-LINE-Authorization-Nonce':nonce,'X-LINE-Authorization-Date':ts,'X-LINE-Authorization':sig},
    });
    const data = await res.json();
    if (data.returnCode!=='0000') return Response.redirect(FALLBACK_SITE_URL+'?pay_result=fail',302);
    await dbUpdate(env,'payments',`id=eq.${pay.id}&tenant_id=eq.${TENANT}`,{status:'已確認',paid_at:nowIso()});
    const regs = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(pay.reg_id)}&select=*`);
    if (regs.length) {
      const reg=regs[0];
      await dbUpdate(env,'registrations',`id=eq.${encodeURIComponent(pay.reg_id)}&tenant_id=eq.${TENANT}`,{payment_status:'已繳費',payment_method:'LINE Pay',paid_at:nowIso()});
      try { await dbUpdate(env,'stalls',`tenant_id=eq.${TENANT}&reg_id=eq.${encodeURIComponent(pay.reg_id)}&status=eq.預留`,{status:'鎖定'}); } catch {}
      const sesName=await getSessionName(env, reg.session_id, TENANT);
      const sesType=await getSessionType(env, reg.session_id, TENANT);
      const dn=getDisplayName(reg.name,reg.brand_name||'',sesType);
      const tcLp = await getTenantCtx(env, TENANT);
      try { await mailPaymentConfirm(env,reg.email,dn,sesName,reg.amount,'',reg.stall_number||'',tcLp); } catch {}
    }
    return Response.redirect((await getTenantCtx(env,TENANT)).siteUrl+'?pay_result=1&method=linepay',302);
  } catch { return Response.redirect(FALLBACK_SITE_URL+'?pay_result=fail',302); }
}

// ── SECTION 14: Cron 定時任務 ───────────────────────────────────

// 繳費期限檢查（02:00 UTC）
async function cronCheckPayments(env) {
  const now = new Date();
  // 跨租戶：撈所有租戶的待繳費報名
  const regs = await dbGet(env,'registrations',`review_status=eq.已錄取&payment_status=eq.未繳費&select=*`);
  // 快取 tenantCtx 避免重複 DB 查詢
  const tcCache = {};
  async function getTc(tid) {
    if (!tcCache[tid]) tcCache[tid] = await getTenantCtx(env, tid);
    return tcCache[tid];
  }
  for (const r of regs) {
    const TENANT = r.tenant_id ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
    const created = new Date(r.created_at);
    if (isNaN(created)) continue;
    const hrs = (now-created)/(1000*60*60);
    if (hrs>=PAY_DEADLINE_HOURS) {
      await dbUpdate(env,'registrations',`id=eq.${r.id}&tenant_id=eq.${TENANT}`,{review_status:'已取消',registration_status:'cancelled',admin_note:(r.admin_note||'')+' 逾期未繳費自動取消'});
      // M-01：逾期取消需釋放名額，與手動取消保持一致
      try { await adjustSessionCurrentCount(env, TENANT, r.session_id, -(safeNum(r.stall_count)||1)); } catch(e) { console.error('cronCheckPayments release slot failed', e&&e.message?e.message:e); }
      const sesName=await getSessionName(env, r.session_id, TENANT);
      const sesType=await getSessionType(env, r.session_id, TENANT);
      const dn=getDisplayName(r.name,r.brand_name||'',sesType);
      const tc=await getTc(TENANT);
      try { await mailAutoCancel(env,r.email,dn,sesName,tc); } catch {}
    } else if (hrs>=REMINDER_HOURS && !r.reminder_sent) {
      await dbUpdate(env,'registrations',`id=eq.${r.id}&tenant_id=eq.${TENANT}`,{reminder_sent:true});
      const sesName=await getSessionName(env, r.session_id, TENANT);
      const sesType=await getSessionType(env, r.session_id, TENANT);
      const dn=getDisplayName(r.name,r.brand_name||'',sesType);
      const sr=await dbGet(env,'sessions',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(r.session_id)}&select=basic_equip`);
      const be=sr.length?sr[0].basic_equip||'':'';
      const tc=await getTc(TENANT);
      try { await mailDeadlineReminder(env,r.email,dn,sesName,r.id,Number(r.amount||0),safeJson(r.selected_dates_json,[]),r.equipment_json,be,tc); } catch {}
    }
  }
}

// 釋出逾期預留攤位（02:00 UTC）
async function cronReleaseStalls(env) {
  const now = new Date();
  // 跨租戶：撈所有預留攤位
  const stalls = await dbGet(env,'stalls',`status=eq.預留&select=*`);
  for (const s of stalls) {
    if (!s.hold_time) continue;
    const TENANT = s.tenant_id ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
    const days = (now-new Date(s.hold_time))/(1000*60*60*24);
    if (days>=STALL_HOLD_DAYS) await dbUpdate(env,'stalls',`id=eq.${s.id}&tenant_id=eq.${TENANT}`,{status:'空閒',reg_id:null,email:null,hold_time:null});
  }
}

// 行前提醒（01:00 UTC = 09:00 台灣）
async function cronPreEventReminders(env) {
  const now = new Date();
  // 跨租戶：撈所有啟用場次
  const sessions = await dbGet(env,'sessions',`status=eq.報名中&select=*`);
  const tcCache = {};
  async function getTc(tid) {
    if (!tcCache[tid]) tcCache[tid] = await getTenantCtx(env, tid);
    return tcCache[tid];
  }
  for (const s of sessions) {
    const TENANT = s.tenant_id ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
    const dates = safeJson(s.dates_json,[]);
    if (!dates.length) continue;
    const first = new Date(dates[0].date);
    const diff = Math.ceil((first-now)/(1000*60*60*24));
    if (diff!==3) continue;
    const regs = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(s.id)}&review_status=eq.已錄取&select=*`);
    const tc = await getTc(TENANT);
    for (const r of regs) {
      if (!isPaidStatus(r.payment_status)) continue;
      const dn=getDisplayName(r.name,r.brand_name||'',s.type||'');
      try { await mailPreEventReminder(env,r.email,dn,s.name,dates[0].date,s.venue||'',tc); } catch {}
    }
  }
}

// 不可抗力逾期自動退費（02:00 UTC）
async function cronForceCancelExpiry(env) {
  const now = new Date();
  // 跨租戶
  const sessions = await dbGet(env,'sessions',`force_cancel=eq.true&select=*`);
  for (const s of sessions) {
    const TENANT = s.tenant_id ;  // M-02：tenant 已由路由層驗證（見 routeGet/routePost）
    if (!s.force_cancel_deadline) continue;
    if (now<new Date(s.force_cancel_deadline)) continue;
    // 找出未做選擇的報名（transfer_status 為空或 null）
    const regs = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&session_id=eq.${encodeURIComponent(s.id)}&review_status=in.(已錄取,待審核)&select=*`);
    const unprocessed = regs.filter(r=>!r.transfer_status||r.transfer_status==='');
    const tcFc = await getTenantCtx(env, TENANT);
    for (const r of unprocessed) {
      await dbUpdate(env,'registrations',`id=eq.${r.id}&tenant_id=eq.${TENANT}`,{transfer_status:'申請退費',transfer_chosen_at:nowIso()});
      const st=await getSessionType(env, r.session_id, TENANT);
      const dn=getDisplayName(r.name,r.brand_name||'',st);
      try { await mailAutoRefund(env,r.email,dn,s.name,tcFc); } catch {}
    }
  }
}

// ── SECTION 15: 路由 ────────────────────────────────────────────

async function routeGet(env, action, p, req) {
  // 不需要 tenant 的路由
  if (action==='adminMe') return await hAdminMe(env, p);
  if (action==='applyList') return await hApplyList(env, p);
  if (action==='getTenantsAdmin') return await hGetTenantsAdmin(env, p);

  // M-02：解析租戶，缺少 tenant 一律回傳 400
  const TENANT = getTenantId(p);
  if (!TENANT) {
    return new Response(JSON.stringify({ok:false, error:'缺少 tenant 參數'}), {status:400, headers:corsHeaders()});
  }
  p._tenantId = TENANT;  // 注入供 handler 使用
  // 連線測試 / 診斷
  if (action==='ping') {
    let supabaseOk=false, staffCount=0, sessionCount=0, errMsg='';
    try {
      const rows = await dbGet(env,'staff',`tenant_id=eq.${TENANT}&select=email,role`);
      supabaseOk=true; staffCount=rows.length;
    } catch(e) { errMsg=e.message; }
    try {
      const rows = await dbGet(env,'sessions',`tenant_id=eq.${TENANT}&select=id`);
      sessionCount=rows.length;
    } catch(e) {}
    return jsonOk({
      ok:true, tenant:TENANT,
      supabase: supabaseOk ? '✅ 正常' : '❌ 失敗：'+errMsg,
      staffCount, sessionCount,
      env_supabase_url: env.SUPABASE_URL ? '✅ 已設定' : '❌ 未設定',
      env_supabase_key: env.SUPABASE_KEY ? '✅ 已設定' : '❌ 未設定',
      env_resend_key: env.RESEND_KEY ? '✅ 已設定' : '❌ 未設定',
    });
  }
  if (action==='ecpayReturn') {
    return new Response('0|付款 API 尚未啟用',{status:200});
  }
  if (action==='linePayConfirm') return Response.redirect(FALLBACK_SITE_URL+'?pay_result=disabled',302);
  if (action==='linePayCancel') return Response.redirect(FALLBACK_SITE_URL+'?linepay_cancel=1',302);

  switch(action) {
    case 'frontBootstrap':      return hFrontBootstrap(env,p);
    case 'getEvents':           return hGetEvents(env,p);
    case 'getSessions':         return hGetSessions(env,p);
    case 'getSession':          return hGetSession(env,p);
    case 'getSessionAgreement': return hGetSessionAgreement(env,p);
    case 'getMember':           return hGetMember(env,p);
    case 'getMyRegs':           return hGetMyRegs(env,p);
    case 'getRegLookup':        return hGetRegLookup(env,p);
    case 'getAnnouncements':    return hGetAnnouncements(env,p);
    case 'getStalls':           return hGetStalls(env,p);
    case 'getMyStall':          return hGetMyStall(env,p);
    case 'getStallStatus':      return hGetStallStatus(env,p);
    case 'adminLogin':          return hAdminLogin(env,p);
    case 'applyTrial':          return hApplyTrial(env,p);
    case 'approveApply':        return hApproveApply(env,p);
    case 'lockTenant':          return hLockTenant(env,p);
    case 'unlockTenant':        return hUnlockTenant(env,p);
    case 'adminLogout':         return hAdminLogout(env,p);
    case 'adminMe':             return hAdminMe(env,p);
    case 'getDashboard':        return hGetDashboard(env,p);
    case 'getSessionDashboard': return hGetSessionDashboard(env,p);
    case 'downloadSession':     return hDownloadSession(env,p);
    case 'getRegs':             return hGetRegs(env,p);
    case 'getRegsBySession':    return hGetRegsBySession(env,p);
    case 'getStaff':            return hGetStaff(env,p);
    case 'getEventsAdmin':      return hGetEventsAdmin(env,p);
    case 'getSessionsAdmin':    return hGetSessionsAdmin(env,p);
    case 'getPayments':         return hGetPayments(env,p);
    case 'getFinance':          return hGetFinance(env,p);
    case 'getInvoiceList':      return hGetInvoiceList(env,p);
    case 'getSiteConfig':       return hGetSiteConfig(env,p);
    case 'getAgreementTemplate': return hGetAgreementTemplate(env,p);
    case 'getForceRefundList':  return hGetForceRefundList(env,p);
    case 'previewForceCancelSession': return hPreviewForceCancelSession(env,p);
    default: return jsonErr('unknown GET action: '+action);
  }
}

async function routePost(env, action, b, ctx, req) {
  // M-02：解析租戶，缺少 tenant 一律回傳 400
  const TENANT = getTenantId(b);
  if (!TENANT) {
    return new Response(JSON.stringify({ok:false, error:'缺少 tenant 參數'}), {status:400, headers:corsHeaders()});
  }
  b._tenantId = TENANT;  // 注入供 handler 使用
  // 注入來源 IP 與 User-Agent（供不可抗力同意證據寫入）
  if (req) {
    b._ip = req.headers.get('CF-Connecting-IP') || req.headers.get('X-Forwarded-For') || req.headers.get('X-Real-IP') || null;
    b._userAgent = req.headers.get('User-Agent') || null;
  }
  if (action==='resendRegConfirm') {
    if (!await verifyStaff(env,b.email,b.token,TENANT,'review')) return jsonErr('無權限');
    const rows = await dbGet(env,'registrations',`tenant_id=eq.${TENANT}&id=eq.${encodeURIComponent(b.regId)}&select=*`);
    if(!rows.length) return jsonErr('找不到報名資料');
    const reg=rows[0];
    const sesName = await getSessionName(env, reg.session_id, TENANT);
    const sesType = await getSessionType(env, reg.session_id, TENANT);
    const dn = getDisplayName(reg.name, reg.brand_name||'', sesType);
    const total = Number(reg.amount)||0;
    const stallCount = Number(reg.stall_count)||1;
    const selectedDates = safeJson(reg.selected_dates_json,[]);
    const equip = safeJson(reg.equipment_json,{});
    const tcResend = await getTenantCtx(env, TENANT);
    try { await mailRegConfirm(env,reg.email,dn,sesName,reg.id,total,stallCount,selectedDates,equip,tcResend); }
    catch(e){ return jsonErr('寄信失敗：'+e.message); }
    return jsonOk({ok:true});
  }
  if (action==='testEmail') {
    if (!await verifyStaff(env,b.email,b.token, TENANT)) return jsonErr('無權限');
    const to = b.to;
    if(!to) return jsonErr('缺少收件地址');
    const tcTest = await getTenantCtx(env, TENANT);
    const result = await sendEmail(env, to, `【${tcTest.name}】信件系統測試`, emailWrap(`
<p>✅ 這是一封測試信件。</p>
<p>如果您收到這封信，代表 <strong>${tcTest.name}</strong> 的信件系統設定正確！</p>
<p style="color:#888;font-size:12px">測試時間：${nowIso()}</p>
`, tcTest), tcTest);
    if(result.ok) return jsonOk({ok:true});
    return jsonErr('寄信失敗：'+(result.error||'未知錯誤'));
  }
  switch(action) {
    case 'register':            return hRegister(env,b,ctx);
    case 'saveMember':          return hSaveMember(env,b);
    case 'cancelReg':           return hCancelReg(env,b);
    case 'selectStall':         return hSelectStall(env,b);
    case 'submitPayment':       return hSubmitPayment(env,b);
    case 'createLinePayOrder':  return hCreateLinePayOrder(env,b);
    case 'createEcpayOrder':    return hCreateEcpayOrder(env,b);
    case 'createEvent':         return hCreateEvent(env,b);
    case 'updateEvent':         return hUpdateEvent(env,b);
    case 'deleteEvent':         return hDeleteEvent(env,b);
    case 'createSession':       return hCreateSession(env,b);
    case 'updateSession':       return hUpdateSession(env,b);
    case 'deleteSession':       return hDeleteSession(env,b);
    case 'toggleSession':       return hToggleSession(env,b);
    case 'toggleSessionStatus': return hToggleSessionStatus(env,b);
    case 'copySession':         return hCopySession(env,b);
    case 'updateRegStatus':     return hUpdateRegStatus(env,b);
    case 'batchUpdateStatus':   return hBatchUpdateStatus(env,b);
    case 'approveReg':          return hApproveReg(env,b);
    case 'confirmPayment':      return hConfirmPayment(env,b);
    case 'markPaymentScreenshot': return hMarkPaymentScreenshot(env,b);
    case 'adminCancelReg':      return hAdminCancelReg(env,b);
    case 'refundDeposit':       return hRefundDeposit(env,b);
    case 'checkin':             return hCheckin(env,b);
    case 'markClear':           return hMarkClear(env,b);
    case 'sendNotify':          return hSendNotify(env,b);
    case 'resendInvite':        return hResendInvite(env,b);
    case 'addStaff':            return hAddStaff(env,b);
    case 'removeStaff':         return hRemoveStaff(env,b);
    case 'updateStaffPerms':    return hUpdateStaffPerms(env,b);
    case 'updateStaffSessions': return hUpdateStaffSessions(env,b);
    case 'saveAnnouncement':    return hSaveAnnouncement(env,b);
    case 'deleteAnnouncement':  return hDeleteAnnouncement(env,b);
    case 'saveFinanceItem':     return hSaveFinanceItem(env,b);
    case 'deleteFinanceItem':   return hDeleteFinanceItem(env,b);
    case 'updateInvoiceStatus': return hUpdateInvoiceStatus(env,b);
    case 'initStalls':          return hInitStalls(env,b);
    case 'saveStallConfig':     return hSaveStallConfig(env,b);
    case 'setFastPass':         return hSetFastPass(env,b);
    case 'saveSiteConfig':      return hSaveSiteConfig(env,b);
    case 'saveAgreementTemplate': return hSaveAgreementTemplate(env,b);
    case 'forceCancel':         return hForceCancel(env,b);
    case 'agreeTransfer':       return hAgreeTransfer(env,b);
    case 'applyRefund':         return hApplyRefund(env,b);
    case 'confirmRefund':       return hConfirmRefund(env,b);
    // ── 不可抗力模組（獨立 action，不覆蓋原有邏輯）──
    case 'forceCancelSession':   return hForceCancelSession(env,b);
    case 'agreeForceTransfer':   return hAgreeForceTransfer(env,b);
    case 'applyForceRefund':     // alias：規格名稱
    case 'applyForceRefundFM':   return hApplyForceRefundFM(env,b);
    case 'runForceChoiceDeadline': return hRunForceChoiceDeadline(env,b);
    case 'confirmForceRefund':   return hConfirmForceRefund(env,b);
    case 'getRefundSuggestion': return hGetRefundSuggestion(env,b);
    // 允許 POST 呼叫的 GET actions
    case 'getFinance':          return hGetFinance(env,b);
    case 'getRegsBySession':    return hGetRegsBySession(env,b);
    case 'getStallStatus':      return hGetStallStatus(env,b);
    default: return jsonErr('unknown POST action: '+action);
  }
}

// ── SECTION 16: 主進入點 ────────────────────────────────────────
export default {
  async fetch(request, env, ctx) {
    // CORS preflight
    if (request.method==='OPTIONS') {
      return new Response(null, {status:204, headers:corsHeaders()});
    }
    try {
      const url = new URL(request.url);
      const pathname = url.pathname;
      const action = url.searchParams.get('action')||'';

      // ── Google OAuth 路由（GET）──
      if (request.method==='GET' && pathname.endsWith('/auth/google/start')) {
        return await hGoogleStart(env, url);
      }
      if (request.method==='GET' && pathname.endsWith('/auth/google/callback')) {
        return await hGoogleCallback(env, url);
      }
      // 統一登入
      if (request.method==='GET' && pathname.endsWith('/auth/google/unified/start')) {
        return await hGoogleUnifiedStart(env, url);
      }
      if (request.method==='GET' && pathname.endsWith('/auth/google/unified/callback')) {
        return await hGoogleUnifiedCallback(env, url);
      }

      if (request.method==='GET') {
        const p = Object.fromEntries(url.searchParams);
        // /admin/me
        if (pathname.endsWith('/admin/me') || action==='adminMe') return await hAdminMe(env, p);
        return await routeGet(env, action, p, request);
      }

      if (request.method==='POST') {
        // ECPay 回調：付款 API 尚未啟用
        if (action==='ecpayReturn') {
          return new Response('0|付款 API 尚未啟用',{status:200});
        }
        // 一般 POST：支援 application/json 與 text/plain 內的 JSON
        let body={};
        try {
          const raw = await request.text();
          body = raw ? JSON.parse(raw) : {};
        } catch(e) {
          return jsonErr('invalid JSON body');
        }
        // action 可在 URL 或 body 中
        const act = action || body.action || '';
        // /admin/logout
        if (pathname.endsWith('/admin/logout') || act==='adminLogout') return await hAdminLogout(env, body);
        // 申請試用（不需登入）
        if (pathname.endsWith('/apply') || act==='applyTrial') return await hApplyTrial(env, body);
        // 一鍵開通（平台管理員）
        if (act==='approveApply') return await hApproveApply(env, body);
        // 鎖定 / 解鎖
        if (act==='lockTenant') return await hLockTenant(env, body);
        if (act==='unlockTenant') return await hUnlockTenant(env, body);
        return await routePost(env, act, body, ctx, request);
      }

      return jsonErr('Method Not Allowed');
    } catch(e) {
      console.error('Worker error:', e);
      return jsonErr('Server Error: '+e.message);
    }
  },

  async scheduled(event, env, ctx) {
    const utcHour = new Date(event.scheduledTime).getUTCHours();
    if (utcHour===1) {
      await cronPreEventReminders(env);
      await cronTrialExpireReminders(env); // 試用到期提醒
    } else {
      // 02:00 UTC = 10:00 台灣 → 繳費期限 + 攤位釋出 + 不可抗力逾期
      await cronCheckPayments(env);
      await cronReleaseStalls(env);
      await cronForceCancelExpiry(env);
      // 不可抗力選擇逾期自動轉退費
      await hRunForceChoiceDeadline(env, {});
    }
  },
};
