# 給下一個 Claude 的交接說明
# 請在新對話第一句話把這份文件丟給 Claude

## 我是誰
曾信慧（Grace），兔彼樂共創活動有限公司（統編：90279650），台中。
不是工程師，所有專有名詞請解釋清楚。
**先討論，說執行才動手。**

## 重要連結
- 前台：https://2b-love.com/register.html
- 後台：https://2b-love.com/admin.html
- Worker：https://2bl-v7.ndiangrace.workers.dev
- GitHub：https://github.com/ndiangrace-create/2bL
- Supabase：https://supabase.com/dashboard/project/douhmxipedgpfbvfynbq
- Cloudflare：https://dash.cloudflare.com
- Google Cloud：https://console.cloud.google.com

## 技術架構
- 前端：register.html（前台）、admin.html（後台）→ GitHub Pages
- 後端：worker.js → Cloudflare Workers（服務名稱仍為 2bl-v7，僅為既有部署名稱，不代表系統版本）
- 資料庫：Supabase PostgreSQL（douhmxipedgpfbvfynbq，新加坡）
- 登入：Google OAuth
- 管理員：ndiangrace@gmail.com，tenant_id=tuibile，role=platform_super_admin

## 目前主線版本定義（2026年6月28日清理後）
正式主線為「2BL V8 整合版｜無選位版主線可驗收包」。
部署仍只使用三個主檔：
1. register.html
2. admin.html
3. worker.js

worker.txt 僅為由最新版 worker.js 同步產出的純文字備用版。
禁止使用舊 worker.txt 覆蓋 Cloudflare Worker。

## 這次對話完成的修正（2026年6月28日）

### register.html 修正
1. renderDynFormFull 重複定義 → 刪除殘缺版本
2. adjStall 找不到 stallInput → 同時更新 stallInput 和 stallDisplay
3. adjEquip 找 eq_num_ 但 HTML 用 eq_ → 修正為同時更新兩種格式
4. 設備顯示格式改為：帳篷 NT$450（本次含1）[−] 1 [+]（NT$0）
5. feeBaseRow 缺少 id → 補上
6. handleMemberOAuthCallback 每次刷新都觸發 → 只讀 pending token
7. navToTab 沒有寫入 2bl_page_state → 修正
8. bootDbFront 還原邏輯 → 完整還原包含報名表所有欄位
9. 已加上資料來源邊界註記：localStorage / sessionStorage 只可暫存，不可作為正式資料來源

### admin.html 修正
1. IIFE 清 URL 後 admin_token 消失 → 先存 sessionStorage 再清
2. applyAgreementTemplate 從空 DOM 讀 → 改從 API 直接讀
3. 按鈕顏色對比度 → 全部改為 color:#2C2C2C
4. staff 權限本機快取已降權，不再用 localStorage 覆蓋資料庫權限

### worker.js 修正
1. JWT 中文字符（btoa 問題）→ V8 已修正
2. email=_ 驗證邏輯 → V8 已修正
3. worker.js 為正式主線，worker.txt 已同步為 worker.js 的純文字副本
4. 移除 example.com fallback email，改為 2b-love.com fallback；正式寄件仍以 tenants 設定為準

## 選位模組狀態（重要）
選位 API 不是完全未合併。
目前 worker.js 已有部分選位 API，但正式選位規則尚未完全對齊。

目前狀態：
- worker.js 內已有 getStalls / getMyStall / getStallStatus / selectStall / initStalls / saveStallConfig 等部分 API
- 008_seat_selection.sql 已準備 seat_maps / seat_assignments / seat_operation_logs 等新資料結構
- 但 worker.js 尚未完整改用 008 的新資料結構
- 交接中規劃的正式規則「已錄取可預留、已付款後鎖定」尚未完成

因此：
- 選位模組暫時隔離
- 008_seat_selection.sql 保留待用，不納入無選位版主線驗收
- 不得從舊 modular 包整段覆蓋 worker.js
- 不得宣稱選位功能已正式完成

## 無選位版目前可驗收主線
1. 前台載入場次
2. Google / Email 會員登入
3. 填寫報名資料
4. 前台即時試算費用
5. Worker 送出時重新驗算費用
6. 合約閱讀與勾選
7. 報名寫入 registrations
8. 後台 Google 登入
9. 後台查看報名資料
10. 後台審核、付款狀態管理

## 資料來源硬規
正式資料一律以 Supabase / Worker 回傳為準。
前台與後台只能呼叫 API、顯示資料、送出操作。
localStorage / sessionStorage 只能用於 token、email、頁籤、暫存表單，不可判斷正式報名狀態、付款狀態或權限。

## 絕對不能動的東西
1. updateFee 函數（費用計算核心）
2. submitReg 函數（送出報名核心）
3. claim_session_slot RPC（攤位原子鎖定）
4. worker.js 的 calcFee 函數
5. registrations 表結構

## Grace 的工作習慣
1. 先討論，說執行才動手
2. 一次改完再給，不要分批
3. 改之前告訴影響範圍
4. SQL 改之前先 SELECT 確認
5. 不要質疑她的操作，她都是照指示做的

## 資料庫已執行的 SQL 順序
001 → functions/claim_session_slot → 002 → 003 → 004_google_oauth → 005 → 006 → 007
008_seat_selection 尚未納入無選位版主線驗收。

## staff 表特別說明
原本沒有 is_active 欄位，已執行：
ALTER TABLE staff ADD COLUMN IF NOT EXISTS is_active boolean DEFAULT true;
UPDATE staff SET is_active = true WHERE email = 'ndiangrace@gmail.com';
