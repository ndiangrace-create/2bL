# 2BL V8｜版本殘留清理報告

## 清理結論

本包已完成「版本殘留與舊資料清理」。
目前正式主線為：

- register.html
- admin.html
- worker.js

worker.txt 已同步為 worker.js 的純文字副本。
SQL 001–007 為無選位版主線資料庫；008_seat_selection.sql 保留待選位模組整合時使用。

## 已清除的高風險殘留

1. worker.js / worker.txt 不一致
   - 已清理。
   - 目前兩檔內容完全一致。

2. 操作手冊引導貼舊 worker.txt
   - 已清理。
   - 現在文件要求以最新版 worker.js 為準。

3. 交接說明誤寫「選位 API 尚未合併」
   - 已清理。
   - 現在改為「已半整合，但正式規則未對齊」。

4. 008_seat_selection.sql 標頭寫成 004
   - 已清理。

5. worker.js example.com fallback email
   - 已清理。
   - 改為 2b-love.com fallback；正式資料仍以 tenants 設定為準。

6. 後台 staff 權限 localStorage 快取覆蓋風險
   - 已清理。
   - localStorage 不再覆蓋 staff.perms_json。

7. localStorage 資料來源邊界不清
   - 已補註解。
   - 正式資料仍以 Worker / Supabase 為準。

8. V7 / V8 名稱混用
   - 已整理使用者可見與交接文字。
   - 既有 Worker 服務名稱 2bl-v7 保留，因為它是部署資源名稱。

## 保留但隔離的項目

1. 選位相關 API
   - worker.js 內已有部分選位 API，暫時保留，避免前後台引用壞掉。
   - 但不宣稱正式完成。

2. 008_seat_selection.sql
   - 保留待用。
   - 不納入目前無選位版主線必跑項目。

3. claim_session_slot.sql
   - 保留。
   - 目前不重寫 RPC。

## 禁止事項

- 禁止用舊 worker.txt 覆蓋 Cloudflare。
- 禁止從舊 modular 包整段覆蓋 worker.js。
- 禁止把 008 SQL 當作選位已完成證明。
- 禁止從 localStorage 判斷正式報名、付款或權限狀態。
