# 2BL V8｜版本殘留清理 changed_files

## 本次實際修改檔案

1. 【A】立即部署檔案/worker.js
   - 修正檔案開頭主線註解：worker.js 為正式主線，worker.txt 僅為同步備用版。
   - 移除 example.com fallback email，改為 2b-love.com fallback。
   - 將 fallback tenant / placeholder / invoice note / JWT issuer 版本字樣整理為 V8。
   - 保留既有 API 與主流程，未重寫 calcFee、register、Google OAuth、付款、合約流程。

2. 【A】立即部署檔案/worker.txt
   - 已由最新版 worker.js 完整同步產出。
   - worker.js 與 worker.txt 目前內容完全一致。
   - 此檔只作為 Cloudflare 貼上用純文字副本，不得獨立修改。

3. 【A】立即部署檔案/admin.html
   - 將 V7 註解整理為 V8。
   - staff 權限本機快取降權：不再使用 tb_staff_perms（舊前綴） localStorage 覆蓋資料庫權限。
   - 權限更新成功後重新載入 staff 清單，以 Worker / Supabase 回傳為準。
   - 未重做後台版型，未改登入主流程，未改報名、場次、合約、付款核心流程。

4. 【A】立即部署檔案/register.html
   - 新增資料來源邊界註解。
   - 明確標示 localStorage / sessionStorage 僅供 token、email、頁籤、表單暫存使用。
   - 明確禁止從 localStorage 判斷正式報名狀態或付款狀態。
   - 未重寫 updateFee、submitReg、會員載入、報名送出流程。

5. 【C】資料庫SQL/008_seat_selection.sql
   - 修正檔案內註解標頭：舊的錯誤 004 選位標頭 → 008_seat_selection.sql。
   - 未改 SQL 邏輯，未列入無選位版主線必跑項目。

6. 【C】資料庫SQL/*.sql
   - 將測試資料與註解中的 V7 字樣整理為 V8。
   - 將 seed 測試資料中不必要的 example.com / v7.test 殘留改為 V8 測試命名或 2b-love.com 測試占位。
   - 未刪資料表，未改正式資料表結構。

7. 【給下一個Claude的交接說明】.md
   - 重寫交接狀態，修正「選位 API 尚未合併」的錯誤描述。
   - 明確定義目前是「2BL V8 整合版｜無選位版主線可驗收包」。
   - 明確標註選位模組為「已半整合但待正式對齊」，不納入無選位版主線驗收。
   - 明確要求 worker.js 為主線，worker.txt 僅同步備用。

8. 【B】操作手冊/2BL_完整操作手冊.docx
   - 修改 Worker 部署說明：以最新版 worker.js 為準。
   - 補上 worker.txt 僅為同步副本，不可使用舊版覆蓋的註記。
   - 補上選位模組保留但隔離的註記。

## 本次未做事項

- 未接正式 Supabase 線上執行 SQL。
- 未登入 Google OAuth 實測。
- 未部署 Cloudflare Worker。
- 未修改正式資料庫資料。
- 未開發或完成選位正式功能。
