# 2BL V8｜清理後檢測與操作者流程模擬報告

## 檢測範圍

本次檢測針對本地交付包進行：

- 檔案版本一致性
- HTML 內嵌 JavaScript 語法檢查
- Worker JavaScript 語法檢查
- 前後台 action 與 Worker route 對應檢查
- 版本殘留關鍵字檢查
- localStorage 正式資料來源風險檢查
- DOCX 操作手冊渲染檢查
- 無選位版操作者流程靜態模擬

未執行項目：

- 未登入正式 Google OAuth。
- 未連線正式 Supabase 寫入資料。
- 未部署 Cloudflare Worker。
- 未操作正式 GitHub Pages。

## 自動檢查結果

1. worker.js 語法檢查
   - node --check：通過

2. register.html 內嵌 script 語法檢查
   - node --check：通過

3. admin.html 內嵌 script 語法檢查
   - node --check：通過

4. worker.js / worker.txt 一致性
   - cmp：通過
   - 兩檔大小一致，內容一致

5. 前台 action 對應 Worker route
   - register.html 共偵測 16 個 action
   - Worker 對應缺漏：0

6. 後台 action 對應 Worker route
   - admin.html 共偵測 52 個 action
   - Worker 對應缺漏：0

7. 高風險殘留關鍵字
   - 舊 noreply example 信箱：未發現
   - 舊 service example 信箱：未發現
   - 舊 worker.txt 部署註解：未發現
   - 舊選位未合併描述：未發現
   - 舊的錯誤 004 選位標頭：未發現
   - tb_staff_perms（舊前綴）：未發現
   - 舊 V7 版本字樣：未發現

8. localStorage 正式資料判斷風險
   - 未發現 localStorage 直接判斷 registration status / pay status 的殘留。
   - register.html 已補資料來源邊界註解。
   - admin.html staff 權限快取已降權。

9. 操作手冊 DOCX 渲染
   - render_docx.py：通過
   - 已產生頁面 PNG，視覺檢查未見明顯破版、重疊或缺字。

## 無選位版操作者流程模擬

### 前台流程

1. 使用者打開 register.html
   - API 指向既有 Worker：2bl-v7.ndiangrace.workers.dev
   - 備註：2bl-v7 是服務名稱，不代表版本。

2. 載入活動 / 場次
   - 前台透過 Worker action 載入，不使用硬寫正式資料。

3. Google / Email 登入
   - token 可暫存在 localStorage / sessionStorage。
   - 正式會員資料仍需透過 Worker / Supabase 回抓。

4. 填寫報名資料
   - register.html 保留原本表單流程。
   - 未重寫 submitReg。

5. 費用顯示
   - 前台 updateFee 只做畫面試算。
   - 正式金額送出時由 worker.js calcFee 重新驗算。

6. 合約閱讀與勾選
   - 合約內容來自 sessions / agreement templates。
   - 勾選狀態送出後寫入 registrations。

7. 送出報名
   - register.html 呼叫 Worker action。
   - Worker route 對應存在。

### 後台流程

1. 管理員打開 admin.html
   - API 指向既有 Worker。

2. Google 登入
   - admin_token 透過 sessionStorage pending 暫存，避免清 URL 後消失。

3. 載入報名與場次
   - 透過 Worker / Supabase，不使用本機資料作為正式來源。

4. 管理員權限
   - 權限顯示以 Worker / Supabase 回傳為準。
   - localStorage 不再覆蓋 staff.perms_json。

5. 審核與付款
   - 後台 action 對應 Worker route 均存在。

## 驗收結論

本包可作為：

2BL V8 整合版｜無選位版主線可驗收包

可進入前台報名、後台管理、會員、合約、費用、手動付款的閉環驗收。

選位模組仍保留但隔離，不列入本包完成範圍。
