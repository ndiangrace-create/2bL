-- ================================================================
-- 2BL V8｜全新 Supabase 測試資料
-- File: database/seed_test_data.sql
-- 修正版：2026-06-22（地基修正）
--   - 新增 platform_staff seed（H-03）
--   - staff 表移除 platform_super_admin（改用 platform_staff）
-- Run after: database/001_init.sql
-- Purpose: 建立可立即測試 2BL V8 MVP 的 tenants、角色、場次、報名、付款、退費、設備、選位、財務、發票資料。
-- ================================================================

begin;

-- ────────────────────────────────────────────────────────────────
-- Roles / permissions
-- ────────────────────────────────────────────────────────────────

insert into public.roles (id, name, level, description) values
('platform_super_admin','平台超級管理員',100,'可檢查多 tenant 與全平台設定'),
('organizer_owner','主辦 owner',90,'可管理本 tenant 所有資料'),
('organizer_admin','主辦管理員',80,'可管理本 tenant 活動、報名與基本設定'),
('session_admin','場次管理員',60,'僅能管理授權場次'),
('finance_admin','財務管理員',50,'可處理付款、退費、財報與發票'),
('onsite_staff','現場工作人員',30,'僅能處理報到、清場、押金等現場流程')
on conflict (id) do update set name=excluded.name, level=excluded.level, description=excluded.description;

insert into public.permissions (id, name, description) values
('tenant:all','tenant 全權限','tenant 內完整管理'),
('session:manage','場次管理','新增、修改、關閉場次'),
('registration:review','審核報名','審核錄取 / 不錄取'),
('payment:manage','付款管理','付款待確認與確認付款'),
('refund:manage','退費管理','申請、試算與確認退費'),
('checkin:manage','報到管理','現場報到與清場'),
('finance:read','財報讀取','財務、發票、匯出'),
('report:download','報表下載','CSV / 報表下載')
on conflict (id) do update set name=excluded.name, description=excluded.description;

insert into public.role_permissions (role_id, permission_id) values
('platform_super_admin','tenant:all'),
('organizer_owner','tenant:all'),
('organizer_admin','session:manage'),
('organizer_admin','registration:review'),
('organizer_admin','payment:manage'),
('organizer_admin','refund:manage'),
('organizer_admin','checkin:manage'),
('organizer_admin','finance:read'),
('organizer_admin','report:download'),
('session_admin','registration:review'),
('session_admin','checkin:manage'),
('session_admin','report:download'),
('finance_admin','payment:manage'),
('finance_admin','refund:manage'),
('finance_admin','finance:read'),
('finance_admin','report:download'),
('onsite_staff','checkin:manage')
on conflict (role_id, permission_id) do nothing;

-- ────────────────────────────────────────────────────────────────
-- Tenants / tenant settings
-- ────────────────────────────────────────────────────────────────

insert into public.tenants
(id, slug, name, status, site_url, line_url, bank_info, logo_url, cover_url, email_from, email_reply_to, footer_text, invoice_mode, config_json, payment_config_json, default_refund_rules_json)
values
(
'tuibile','tuibile','兔彼樂共創活動','active',
'https://2b-love.com/register.html',
'https://lin.ee/placeholder-tuibile',
'銀行代碼：000｜帳號：000000000000｜戶名：V8 測試戶',
'https://placehold.co/512x512?text=Tuibile',
'https://placehold.co/1200x628?text=Tuibile+Cover',
'活動報名系統 <no-reply@2b-love.com>',
'service@2b-love.com',
'兔彼樂共創活動｜V8 測試環境',
'manual',
$${
  "theme":{"primary":"#82ABA3","accent":"#F4E8C0"},
  "emailTemplatesMode":"placeholder",
  "modules":{"market":true,"consignment":true,"experience":true,"collaboration":true,"stallSelection":true}
}$$::jsonb,
$${
  "bank":{"enabled":true,"label":"ATM／銀行轉帳","bankInfo":"銀行代碼：000｜帳號：000000000000｜戶名：V8 測試戶"},
  "linePay":{"enabled":false,"url":"https://2b-love.com/linepay-placeholder"},
  "creditCard":{"enabled":false,"url":"https://2b-love.com/card-placeholder"}
}$$::jsonb,
$${
  "transferFeeDefault":15,
  "rules":[
    {"key":"before_7","label":"活動前 7 日以上：扣行政費 NT$500","minDays":7,"adminFeeType":"fixed","adminFee":500},
    {"key":"before_3_6","label":"活動前 3～6 日：退 50%","minDays":3,"maxDays":6,"adminFeeType":"percent","adminFeePercent":50},
    {"key":"within_3","label":"活動前 3 日內或當日：不退費","minDays":-9999,"maxDays":2,"adminFeeType":"percent","adminFeePercent":100}
  ]
}$$::jsonb
),
(
'demo_tenant','demo-tenant','第二測試主辦','active',
'https://2b-love.com/demo/',
'https://lin.ee/placeholder-demo',
'銀行代碼：999｜帳號：999999999999｜戶名：Demo 測試戶',
'https://placehold.co/512x512?text=Demo',
'https://placehold.co/1200x628?text=Demo+Cover',
'Demo 活動系統 <no-reply@2b-love.com>',
'demo@2b-love.com',
'第二測試主辦｜V8 測試環境',
'manual',
$${
  "theme":{"primary":"#B3CAD8","accent":"#EED1CC"},
  "emailTemplatesMode":"placeholder",
  "modules":{"market":true,"consignment":false,"experience":true,"collaboration":true,"stallSelection":true}
}$$::jsonb,
$${
  "bank":{"enabled":true,"label":"Demo 銀行轉帳","bankInfo":"銀行代碼：999｜帳號：999999999999｜戶名：Demo 測試戶"}
}$$::jsonb,
$${"transferFeeDefault":0,"rules":[{"key":"manual","label":"Demo：由主辦手動確認","adminFeeType":"fixed","adminFee":0}]}$$::jsonb
),
(
'noconfig_tenant','noconfig-tenant','未設定付款主辦','active',
'https://2b-love.com/noconfig/',
null,
null,
'https://placehold.co/512x512?text=NoConfig',
'https://placehold.co/1200x628?text=NoConfig+Cover',
'未設定付款主辦 <no-reply@2b-love.com>',
'noconfig@2b-love.com',
'未設定付款主辦｜V8 測試環境',
'manual',
$${"theme":{"primary":"#cccccc"},"emailTemplatesMode":"placeholder","modules":{"market":true}}$$::jsonb,
$${}$$::jsonb,
$${"transferFeeDefault":0,"rules":[]}$$::jsonb
)
on conflict (id) do update set
name=excluded.name,
slug=excluded.slug,
status=excluded.status,
site_url=excluded.site_url,
line_url=excluded.line_url,
bank_info=excluded.bank_info,
logo_url=excluded.logo_url,
cover_url=excluded.cover_url,
email_from=excluded.email_from,
email_reply_to=excluded.email_reply_to,
footer_text=excluded.footer_text,
invoice_mode=excluded.invoice_mode,
config_json=excluded.config_json,
payment_config_json=excluded.payment_config_json,
default_refund_rules_json=excluded.default_refund_rules_json;

insert into public.tenant_settings
(tenant_id, organizer_name, logo_url, cover_url, line_url, payment_config_json, email_templates_json, module_flags_json, refund_rules_json, theme_json)
select id, name, logo_url, cover_url, line_url, payment_config_json,
$${
  "registration_confirm":{"subject":"[placeholder] 報名確認","body":"[placeholder] 已收到報名，正式文案後續由 tenant 替換。"},
  "approval":{"subject":"[placeholder] 錄取通知","body":"[placeholder] 請回到我的紀錄查看付款資訊。"},
  "payment_confirm":{"subject":"[placeholder] 付款完成","body":"[placeholder] 付款已確認。"},
  "refund":{"subject":"[placeholder] 退費通知","body":"[placeholder] 退費狀態更新。"}
}$$::jsonb,
(config_json->'modules'),
default_refund_rules_json,
(config_json->'theme')
from public.tenants
where id in ('tuibile','demo_tenant')
on conflict (tenant_id) do update set
organizer_name=excluded.organizer_name,
logo_url=excluded.logo_url,
cover_url=excluded.cover_url,
line_url=excluded.line_url,
payment_config_json=excluded.payment_config_json,
email_templates_json=excluded.email_templates_json,
module_flags_json=excluded.module_flags_json,
refund_rules_json=excluded.refund_rules_json,
theme_json=excluded.theme_json;

-- ────────────────────────────────────────────────────────────────
-- Staff / roles accounts
-- 注意：V8 Worker 的 adminLogin 以 email 登入並回傳 token；測試時請用這些 email。
-- ────────────────────────────────────────────────────────────────

insert into public.staff (id, tenant_id, email, name, role, role_id, perms_json, limit_sessions) values
-- STF_PLATFORM 已移至 platform_staff 表（H-03）
('STF_OWNER','tuibile','owner@tuibile.test','兔彼樂 Owner','organizer_owner','organizer_owner','{}',null),
('STF_ADMIN','tuibile','admin@tuibile.test','兔彼樂管理員','organizer_admin','organizer_admin','{}',null),
('STF_SESSION','tuibile','session@tuibile.test','市集場次管理員','session_admin','session_admin','{}','SES_MARKET_REVIEW_PAID'),
('STF_FINANCE','tuibile','finance@tuibile.test','財務管理員','finance_admin','finance_admin','{}',null),
('STF_ONSITE','tuibile','onsite@tuibile.test','現場工作人員','onsite_staff','onsite_staff','{}','SES_MARKET_REVIEW_PAID,SES_EXP_FREE'),
('STF_DEMO_OWNER','demo_tenant','owner@demo.test','Demo Owner','organizer_owner','organizer_owner','{}',null),
('STF_DEMO_ADMIN','demo_tenant','admin@demo.test','Demo 管理員','organizer_admin','organizer_admin','{}',null)
on conflict (tenant_id, email) do update set
name=excluded.name, role=excluded.role, role_id=excluded.role_id, perms_json=excluded.perms_json, limit_sessions=excluded.limit_sessions;

-- ────────────────────────────────────────────────────────────────
-- Registration types
-- ────────────────────────────────────────────────────────────────

insert into public.registration_types
(id, tenant_id, code, name, module_key, need_payment, default_need_review, config_json)
values
('RT_MARKET','tuibile','market','市集攤商','market',true,true,'{}'),
('RT_CONSIGN','tuibile','consignment','百貨寄賣','consignment',true,true,'{"fees":["上架費","代撤費","轉移費"]}'::jsonb),
('RT_EXPERIENCE','tuibile','experience','體驗活動','experience',false,false,'{"participantFields":["adultCount","childCount","childAges"]}'::jsonb),
('RT_COLLAB','tuibile','collaboration','合作登記','collaboration',false,true,'{"paymentFlow":false}'::jsonb),
('RT_DEMO_MARKET','demo_tenant','market','Demo 市集','market',true,false,'{}')
on conflict (id) do update set
name=excluded.name, module_key=excluded.module_key, need_payment=excluded.need_payment, default_need_review=excluded.default_need_review, config_json=excluded.config_json;

-- ────────────────────────────────────────────────────────────────
-- Events / sessions
-- ────────────────────────────────────────────────────────────────

insert into public.events (id, tenant_id, title, description, location, cover_url, status, starts_at, ends_at)
values
('EV_TUIBILE_MAIN','tuibile','V8 測試活動｜兔彼樂','2BL V8 MVP 測試用活動，含市集、寄賣、體驗、合作登記。','V8 測試場域','https://placehold.co/1200x628?text=V8+Tuibile','開放中','2026-07-18 05:00:00+00','2026-07-19 12:00:00+00'),
('EV_DEMO_MAIN','demo_tenant','V8 測試活動｜第二主辦','第二 tenant 隔離測試。','Demo 測試場域','https://placehold.co/1200x628?text=V8+Demo','開放中','2026-08-01 05:00:00+00','2026-08-01 12:00:00+00')
on conflict (id) do update set title=excluded.title, description=excluded.description, location=excluded.location, cover_url=excluded.cover_url, status=excluded.status, starts_at=excluded.starts_at, ends_at=excluded.ends_at;

insert into public.sessions
(id, tenant_id, event_id, registration_type_id, name, type, region, dates_json, venue, fee, deposit, limit_count, max_stalls, current_count, status, need_review, modules_json, equip_json, basic_equip, custom_fields_json, addons_json, invoice_tax_json, refund_rules_json, theme, organizer, co_organizer, portals, cover_url, description, stall_list_json, assigned_staff)
values
(
'SES_MARKET_REVIEW_PAID','tuibile','EV_TUIBILE_MAIN','RT_MARKET','V8 市集場次｜審核制需付款','市集場次','高雄',
$$[{"date":"2026-07-18","label":"7/18(六)","fee":1200,"limit":20},{"date":"2026-07-19","label":"7/19(日)","fee":1200,"limit":20}]$$::jsonb,
'高雄 V8 測試場域',1200,500,40,2,2,'報名中',true,
'{"stallSelection":true,"payment":true,"invoice":true}'::jsonb,
'{"桌":{"open":true,"price":150,"incl":1},"椅":{"open":true,"price":50,"incl":1},"電":{"open":true,"price":300,"incl":0}}'::jsonb,
'基本含一桌一椅',
'[]'::jsonb,
'[{"name":"加購背板","price":300,"open":true}]'::jsonb,
'{"stall":true,"equip":false,"extra":true}'::jsonb,
null,
'奇幻旅人','兔彼樂共創活動','V8 測試協力','market,home',
'https://placehold.co/1200x628?text=Market',
'審核制、市集、付款、設備、選位完整測試。',
'["A01","A02","A03","A04","A05","A06"]'::jsonb,
'admin@tuibile.test,session@tuibile.test'
),
(
'SES_CONSIGN_PAID','tuibile','EV_TUIBILE_MAIN','RT_CONSIGN','V8 百貨寄賣｜審核制需付款','通路寄賣','高雄',
$$[{"date":"2026-07-18","label":"7/18(六)","fee":800,"limit":10}]$$::jsonb,
'百貨寄賣測試櫃位',800,0,10,1,1,'報名中',true,
'{"consignment":true,"payment":true,"invoice":true}'::jsonb,
'{"上架服務":{"open":true,"price":200,"incl":0},"代撤服務":{"open":true,"price":150,"incl":0},"轉移服務":{"open":true,"price":100,"incl":0}}'::jsonb,
'',
'[]'::jsonb,
'[]'::jsonb,
'{"stall":true,"equip":false,"extra":true}'::jsonb,
null,
'寄賣測試','兔彼樂共創活動','','consignment',
'https://placehold.co/1200x628?text=Consignment',
'百貨寄賣測試場次。',
'["C01","C02","C03"]'::jsonb,
'admin@tuibile.test'
),
(
'SES_EXP_FREE','tuibile','EV_TUIBILE_MAIN','RT_EXPERIENCE','V8 體驗活動｜不審核免費','體驗活動','高雄',
$$[{"date":"2026-07-18","label":"7/18(六)","fee":0,"limit":30}]$$::jsonb,
'體驗教室',0,0,30,0,1,'報名中',false,
'{"experience":true,"payment":false,"children":true}'::jsonb,
'{}'::jsonb,
'',
'[{"key":"childAges","label":"小孩年齡","type":"children_ages"}]'::jsonb,
'[]'::jsonb,
'{"stall":false,"equip":false,"extra":false}'::jsonb,
null,
'親子體驗','兔彼樂共創活動','','experience',
'https://placehold.co/1200x628?text=Experience',
'不審核免費體驗，測試小孩年齡欄位。',
'[]'::jsonb,
'onsite@tuibile.test'
),
(
'SES_COLLAB_REVIEW_FREE','tuibile','EV_TUIBILE_MAIN','RT_COLLAB','V8 合作登記｜審核制免付款','合作登記','高雄',
$$[{"date":"2026-07-19","label":"7/19(日)","fee":0,"limit":50}]$$::jsonb,
'合作登記線上審核',0,0,50,0,1,'報名中',true,
'{"collaboration":true,"payment":false}'::jsonb,
'{}'::jsonb,
'',
'[{"key":"collabType","label":"合作身份","type":"text"}]'::jsonb,
'[]'::jsonb,
'{"stall":false,"equip":false,"extra":false}'::jsonb,
null,
'合作測試','兔彼樂共創活動','','collaboration',
'https://placehold.co/1200x628?text=Collaboration',
'合作登記不應混入攤商付款流程。',
'[]'::jsonb,
'admin@tuibile.test'
),
(
'SES_DEMO_MARKET','demo_tenant','EV_DEMO_MAIN','RT_DEMO_MARKET','Demo 市集｜不審核需付款','市集場次','台中',
$$[{"date":"2026-08-01","label":"8/1(六)","fee":600,"limit":8}]$$::jsonb,
'Demo 場域',600,200,8,1,1,'報名中',false,
'{"stallSelection":true,"payment":true}'::jsonb,
'{"桌":{"open":true,"price":100,"incl":1}}'::jsonb,
'基本含一桌',
'[]'::jsonb,
'[]'::jsonb,
'{"stall":true,"equip":false,"extra":false}'::jsonb,
null,
'Demo 主題','第二測試主辦','','market',
'https://placehold.co/1200x628?text=Demo+Market',
'第二 tenant 隔離測試。',
'["D01","D02","D03"]'::jsonb,
'admin@demo.test'
)
on conflict (id) do update set
name=excluded.name,
type=excluded.type,
dates_json=excluded.dates_json,
venue=excluded.venue,
fee=excluded.fee,
deposit=excluded.deposit,
limit_count=excluded.limit_count,
max_stalls=excluded.max_stalls,
current_count=excluded.current_count,
status=excluded.status,
need_review=excluded.need_review,
modules_json=excluded.modules_json,
equip_json=excluded.equip_json,
basic_equip=excluded.basic_equip,
custom_fields_json=excluded.custom_fields_json,
addons_json=excluded.addons_json,
invoice_tax_json=excluded.invoice_tax_json,
theme=excluded.theme,
organizer=excluded.organizer,
co_organizer=excluded.co_organizer,
portals=excluded.portals,
cover_url=excluded.cover_url,
description=excluded.description,
stall_list_json=excluded.stall_list_json,
assigned_staff=excluded.assigned_staff;

-- ────────────────────────────────────────────────────────────────
-- Members
-- ────────────────────────────────────────────────────────────────

insert into public.members
(tenant_id, email, name, phone, brand, brand_name, brand_intro, fb_url, ig_url, line_id, city, invoice_type, invoice_title, tax_id, invoice_email, sell_category, fast_pass)
values
('tuibile','member.pending@v8.test','待確認會員','0911000001','待確認品牌','待確認品牌','付款待確認測試品牌','https://facebook.com/v8pending','https://instagram.com/v8pending','line_pending','高雄','個人','','','member.pending@v8.test','手作',false),
('tuibile','member.paid@v8.test','已付款會員','0911000002','已付款品牌','已付款品牌','已付款測試品牌','https://facebook.com/v8paid','https://instagram.com/v8paid','line_paid','高雄','公司','已付款有限公司','12345678','invoice.paid@v8.test','文創',false),
('tuibile','member.refunding@v8.test','退費中會員','0911000003','退費中品牌','退費中品牌','退費中測試品牌','https://facebook.com/v8refunding','https://instagram.com/v8refunding','line_refunding','台中','個人','','','member.refunding@v8.test','選物',false),
('tuibile','member.refunded@v8.test','已退費會員','0911000004','已退費品牌','已退費品牌','已退費測試品牌','https://facebook.com/v8refunded','https://instagram.com/v8refunded','line_refunded','台南','個人','','','member.refunded@v8.test','手作',false),
('tuibile','member.exp@v8.test','體驗會員','0911000005','','','','','','line_exp','高雄','個人','','','member.exp@v8.test','',false),
('tuibile','member.collab@v8.test','合作會員','0911000006','合作品牌','合作品牌','合作登記測試','https://facebook.com/v8collab','https://instagram.com/v8collab','line_collab','高雄','個人','','','member.collab@v8.test','合作',false),
('demo_tenant','member.demo@v8.test','Demo 會員','0922000001','Demo 品牌','Demo 品牌','第二 tenant 測試品牌','','','line_demo','台中','個人','','','member.demo@v8.test','測試',false)
on conflict (tenant_id, email) do update set
name=excluded.name,
phone=excluded.phone,
brand=excluded.brand,
brand_name=excluded.brand_name,
brand_intro=excluded.brand_intro,
fb_url=excluded.fb_url,
ig_url=excluded.ig_url,
line_id=excluded.line_id,
city=excluded.city,
invoice_type=excluded.invoice_type,
invoice_title=excluded.invoice_title,
tax_id=excluded.tax_id,
invoice_email=excluded.invoice_email,
sell_category=excluded.sell_category,
fast_pass=excluded.fast_pass;

-- ────────────────────────────────────────────────────────────────
-- Registrations
-- ────────────────────────────────────────────────────────────────

insert into public.registrations
(id, tenant_id, session_id, event_id, registration_type_id, email, name, phone, brand_name, brand_intro, sell_category, sell_items, fb_url, ig_url, equipment_json, equip_json, custom_fields_json, participants_json, selected_dates_json, addon_qty_json, addon_amount, stall_count, deposit, review_status, registration_status, payment_status, pay_status, amount, total_amount, payment_method, pay_method, paid_at, payment_report_amount, payment_last5, payment_reported_at, payment_screenshot_status, checkin_status, clear_status, deposit_refunded, tax_id, invoice_title, invoice_email, invoice_status, invoice_type, invoice_carrier, admin_note, transfer_status, refund_amount, refund_admin_fee, refund_transfer_fee, refund_rule_label, refunded_at, refund_note, stall_number, created_at, checkin_at)
values
('REG_PENDING_PAYMENT','tuibile','SES_MARKET_REVIEW_PAID','EV_TUIBILE_MAIN','RT_MARKET','member.pending@v8.test','待確認會員','0911000001','待確認品牌','付款待確認測試品牌','手作','飾品、明信片','https://facebook.com/v8pending','https://instagram.com/v8pending','{"桌":1,"椅":2,"電":1}'::jsonb,'{"桌":1,"椅":2,"電":1}'::jsonb,'{}'::jsonb,'{"adultCount":1,"childCount":0,"childAges":[],"totalCount":1}'::jsonb,'["2026-07-18"]'::jsonb,'{"0":1}'::jsonb,300,1,500,'已錄取','active','付款待確認','付款待確認',2300,2300,'ATM／銀行轉帳','ATM／銀行轉帳',null,2300,'12345',now() - interval '9 days','已回報客服','未報到','未清場','未退押金','','','member.pending@v8.test','待開立','個人','','[seed] 付款待確認測試資料','',0,0,0,null,null,null,'A02',now() - interval '10 days',null),
('REG_PAID','tuibile','SES_MARKET_REVIEW_PAID','EV_TUIBILE_MAIN','RT_MARKET','member.paid@v8.test','已付款會員','0911000002','已付款品牌','已付款測試品牌','文創','貼紙、徽章','https://facebook.com/v8paid','https://instagram.com/v8paid','{"桌":1,"椅":1}'::jsonb,'{"桌":1,"椅":1}'::jsonb,'{}'::jsonb,'{"adultCount":1,"childCount":0,"childAges":[],"totalCount":1}'::jsonb,'["2026-07-18","2026-07-19"]'::jsonb,'{}'::jsonb,0,1,500,'已錄取','active','已繳費','已繳費',2900,2900,'ATM／銀行轉帳','ATM／銀行轉帳',now() - interval '8 days',2900,'22222',now() - interval '9 days','已回報客服','未報到','未清場','未退押金','12345678','已付款有限公司','invoice.paid@v8.test','待開立','公司','','[seed] 已付款測試資料','',0,0,0,null,null,null,'A01',now() - interval '10 days',now() - interval '2 days'),
('REG_REFUNDING','tuibile','SES_MARKET_REVIEW_PAID','EV_TUIBILE_MAIN','RT_MARKET','member.refunding@v8.test','退費中會員','0911000003','退費中品牌','退費中測試品牌','選物','二手選物','https://facebook.com/v8refunding','https://instagram.com/v8refunding','{"桌":1,"椅":1}'::jsonb,'{"桌":1,"椅":1}'::jsonb,'{}'::jsonb,'{"adultCount":1,"childCount":0,"childAges":[],"totalCount":1}'::jsonb,'["2026-07-19"]'::jsonb,'{}'::jsonb,0,1,500,'已錄取','active','已繳費','已繳費',1700,1700,'ATM／銀行轉帳','ATM／銀行轉帳',now() - interval '8 days',1700,'33333',now() - interval '9 days','已回報客服','未報到','未清場','未退押金','','','member.refunding@v8.test','待開立','個人','','[seed] 退費中測試資料','退費中',0,0,0,null,null,'申請退費中','A03',now() - interval '10 days',null),
('REG_REFUNDED','tuibile','SES_MARKET_REVIEW_PAID','EV_TUIBILE_MAIN','RT_MARKET','member.refunded@v8.test','已退費會員','0911000004','已退費品牌','已退費測試品牌','手作','手作雜貨','https://facebook.com/v8refunded','https://instagram.com/v8refunded','{"桌":1,"椅":1}'::jsonb,'{"桌":1,"椅":1}'::jsonb,'{}'::jsonb,'{"adultCount":1,"childCount":0,"childAges":[],"totalCount":1}'::jsonb,'["2026-07-18"]'::jsonb,'{}'::jsonb,0,1,500,'已錄取','refunded','已退費','已退費',1700,1700,'ATM／銀行轉帳','ATM／銀行轉帳',now() - interval '10 days',1700,'44444',now() - interval '11 days','已回報客服',null,null,'未退押金','','','member.refunded@v8.test','作廢','個人','','[seed] 已退費測試資料；保留 review_status=已錄取','已退費',1185,500,15,'活動前 7 日以上：扣行政費 NT$500',now() - interval '1 day','已完成退費，不可報到與選位','',now() - interval '12 days',null),
('REG_CONSIGN','tuibile','SES_CONSIGN_PAID','EV_TUIBILE_MAIN','RT_CONSIGN','member.paid@v8.test','已付款會員','0911000002','寄賣測試品牌','百貨寄賣測試','選物','寄賣商品','https://facebook.com/v8paid','https://instagram.com/v8paid','{"上架服務":1,"代撤服務":1}'::jsonb,'{"上架服務":1,"代撤服務":1}'::jsonb,'{}'::jsonb,'{"adultCount":1,"childCount":0,"childAges":[],"totalCount":1}'::jsonb,'["2026-07-18"]'::jsonb,'{}'::jsonb,0,1,0,'待審核','active','未繳費','未繳費',1150,1150,null,null,null,0,null,null,'','未報到','未清場','未退押金','12345678','已付款有限公司','invoice.paid@v8.test','待開立','公司','','[seed] 百貨寄賣待審核資料','',0,0,0,null,null,null,'',now() - interval '10 days',null),
('REG_EXPERIENCE_FREE','tuibile','SES_EXP_FREE','EV_TUIBILE_MAIN','RT_EXPERIENCE','member.exp@v8.test','體驗會員','0911000005','','','親子體驗','','','','{}'::jsonb,'{}'::jsonb,'{"childAges":[6,9]}'::jsonb,'{"adultCount":1,"childCount":2,"childAges":[6,9],"totalCount":3}'::jsonb,'["2026-07-18"]'::jsonb,'{}'::jsonb,0,1,0,'已錄取','active','免費','免費',0,0,null,null,null,0,null,null,'','未報到','未清場','未退押金','','','member.exp@v8.test','','個人','','[seed] 免費體驗活動資料','',0,0,0,null,null,null,'',now() - interval '10 days',null),
('REG_COLLAB_FREE','tuibile','SES_COLLAB_REVIEW_FREE','EV_TUIBILE_MAIN','RT_COLLAB','member.collab@v8.test','合作會員','0911000006','合作品牌','合作登記測試','合作','KOL／攝影合作','https://facebook.com/v8collab','https://instagram.com/v8collab','{}'::jsonb,'{}'::jsonb,'{"collabType":"KOL"}'::jsonb,'{"adultCount":1,"childCount":0,"childAges":[],"totalCount":1}'::jsonb,'["2026-07-19"]'::jsonb,'{}'::jsonb,0,1,0,'待審核','active','免費','免費',0,0,null,null,null,0,null,null,'','未報到','未清場','未退押金','','','member.collab@v8.test','','個人','','[seed] 合作登記資料，不走付款流程','',0,0,0,null,null,null,'',now() - interval '10 days',null),
('REG_DEMO_PAID','demo_tenant','SES_DEMO_MARKET','EV_DEMO_MAIN','RT_DEMO_MARKET','member.demo@v8.test','Demo 會員','0922000001','Demo 品牌','第二 tenant 測試品牌','測試','Demo 商品','','','{"桌":1}'::jsonb,'{"桌":1}'::jsonb,'{}'::jsonb,'{"adultCount":1,"childCount":0,"childAges":[],"totalCount":1}'::jsonb,'["2026-08-01"]'::jsonb,'{}'::jsonb,0,1,200,'已錄取','active','已繳費','已繳費',800,800,'ATM／銀行轉帳','ATM／銀行轉帳',now() - interval '8 days',800,'99999',now() - interval '9 days','已回報客服','未報到','未清場','未退押金','','','member.demo@v8.test','待開立','個人','','[seed] 第二 tenant 已付款資料','',0,0,0,null,null,null,'D01',now() - interval '10 days',null)
on conflict (id) do update set
review_status=excluded.review_status,
registration_status=excluded.registration_status,
payment_status=excluded.payment_status,
pay_status=excluded.pay_status,
amount=excluded.amount,
total_amount=excluded.total_amount,
payment_report_amount=excluded.payment_report_amount,
payment_reported_at=excluded.payment_reported_at,
paid_at=excluded.paid_at,
transfer_status=excluded.transfer_status,
refund_amount=excluded.refund_amount,
refunded_at=excluded.refunded_at,
admin_note=excluded.admin_note,
stall_number=excluded.stall_number,
created_at=excluded.created_at,
checkin_at=excluded.checkin_at;

-- ────────────────────────────────────────────────────────────────
-- Registration items
-- ────────────────────────────────────────────────────────────────

insert into public.registration_items
(id, tenant_id, registration_id, session_id, item_type, item_name, quantity, unit_price, amount, tax_included, meta_json)
values
('ITEM_PENDING_STALL','tuibile','REG_PENDING_PAYMENT','SES_MARKET_REVIEW_PAID','stall_fee','攤位費',1,1200,1200,true,'{}'),
('ITEM_PENDING_DEPOSIT','tuibile','REG_PENDING_PAYMENT','SES_MARKET_REVIEW_PAID','deposit','押金',1,500,500,false,'{"excludeFromInvoice":true}'::jsonb),
('ITEM_PENDING_ELECTRIC','tuibile','REG_PENDING_PAYMENT','SES_MARKET_REVIEW_PAID','equipment','電',1,300,300,false,'{}'),
('ITEM_PENDING_ADDON','tuibile','REG_PENDING_PAYMENT','SES_MARKET_REVIEW_PAID','addon','加購背板',1,300,300,true,'{}'),
('ITEM_PAID_STALL','tuibile','REG_PAID','SES_MARKET_REVIEW_PAID','stall_fee','攤位費',2,1200,2400,true,'{}'),
('ITEM_PAID_DEPOSIT','tuibile','REG_PAID','SES_MARKET_REVIEW_PAID','deposit','押金',1,500,500,false,'{"excludeFromInvoice":true}'::jsonb),
('ITEM_REFUNDING_STALL','tuibile','REG_REFUNDING','SES_MARKET_REVIEW_PAID','stall_fee','攤位費',1,1200,1200,true,'{}'),
('ITEM_REFUNDING_DEPOSIT','tuibile','REG_REFUNDING','SES_MARKET_REVIEW_PAID','deposit','押金',1,500,500,false,'{"excludeFromInvoice":true}'::jsonb),
('ITEM_REFUNDED_STALL','tuibile','REG_REFUNDED','SES_MARKET_REVIEW_PAID','stall_fee','攤位費',1,1200,1200,true,'{}'),
('ITEM_REFUNDED_DEPOSIT','tuibile','REG_REFUNDED','SES_MARKET_REVIEW_PAID','deposit','押金',1,500,500,false,'{"excludeFromInvoice":true}'::jsonb),
('ITEM_CONSIGN_BASE','tuibile','REG_CONSIGN','SES_CONSIGN_PAID','stall_fee','寄賣費',1,800,800,true,'{}'),
('ITEM_CONSIGN_SERVICE','tuibile','REG_CONSIGN','SES_CONSIGN_PAID','equipment','上架／代撤服務',1,350,350,true,'{}'),
('ITEM_DEMO_STALL','demo_tenant','REG_DEMO_PAID','SES_DEMO_MARKET','stall_fee','Demo 攤位費',1,600,600,true,'{}'),
('ITEM_DEMO_DEPOSIT','demo_tenant','REG_DEMO_PAID','SES_DEMO_MARKET','deposit','Demo 押金',1,200,200,false,'{"excludeFromInvoice":true}'::jsonb)
on conflict (id) do update set amount=excluded.amount, quantity=excluded.quantity, unit_price=excluded.unit_price;

-- ────────────────────────────────────────────────────────────────
-- Payments / refunds
-- ────────────────────────────────────────────────────────────────

insert into public.payments
(id, tenant_id, reg_id, session_id, email, amount, method, status, trade_no, paid_at, created_at, screenshot_status, screenshot_received_at, detail_json, line_card_text, admin_note)
values
('PAY_PENDING','tuibile','REG_PENDING_PAYMENT','SES_MARKET_REVIEW_PAID','member.pending@v8.test',2300,'ATM／銀行轉帳','待確認','12345',null,now() - interval '9 days','已回報客服',now() - interval '9 days','{"source":"seed"}'::jsonb,'V8 測試付款待確認卡片','seed：待確認付款'),
('PAY_PAID','tuibile','REG_PAID','SES_MARKET_REVIEW_PAID','member.paid@v8.test',2900,'ATM／銀行轉帳','已確認','22222',now() - interval '8 days',now() - interval '9 days','已回報客服',now() - interval '9 days','{"source":"seed"}'::jsonb,'V8 測試已付款卡片','seed：已付款'),
('PAY_REFUNDING','tuibile','REG_REFUNDING','SES_MARKET_REVIEW_PAID','member.refunding@v8.test',1700,'ATM／銀行轉帳','已確認','33333',now() - interval '8 days',now() - interval '9 days','已回報客服',now() - interval '9 days','{"source":"seed"}'::jsonb,'V8 測試退費中卡片','seed：退費中'),
('PAY_REFUNDED','tuibile','REG_REFUNDED','SES_MARKET_REVIEW_PAID','member.refunded@v8.test',1700,'ATM／銀行轉帳','已確認','44444',now() - interval '10 days',now() - interval '11 days','已回報客服',now() - interval '11 days','{"source":"seed"}'::jsonb,'V8 測試已退費卡片','seed：已退費'),
('PAY_DEMO','demo_tenant','REG_DEMO_PAID','SES_DEMO_MARKET','member.demo@v8.test',800,'ATM／銀行轉帳','已確認','99999',now() - interval '8 days',now() - interval '9 days','已回報客服',now() - interval '9 days','{"source":"seed"}'::jsonb,'Demo 已付款卡片','seed：第二 tenant 已付款')
on conflict (id) do update set status=excluded.status, amount=excluded.amount, paid_at=excluded.paid_at, created_at=excluded.created_at, screenshot_received_at=excluded.screenshot_received_at, admin_note=excluded.admin_note;

insert into public.refunds
(id, tenant_id, reg_id, payment_id, session_id, email, status, paid_amount, refund_amount, admin_fee, transfer_fee, rule_label, reason, requested_at, confirmed_at, created_by, confirmed_by, note, created_at)
values
('REFUND_REQUESTED','tuibile','REG_REFUNDING','PAY_REFUNDING','SES_MARKET_REVIEW_PAID','member.refunding@v8.test','requested',1700,0,0,0,'待主辦確認','會員申請退費',now() - interval '2 days',null,'member.refunding@v8.test',null,'seed：退費中',now() - interval '2 days'),
('REFUND_COMPLETED','tuibile','REG_REFUNDED','PAY_REFUNDED','SES_MARKET_REVIEW_PAID','member.refunded@v8.test','completed',1700,1185,500,15,'活動前 7 日以上：扣行政費 NT$500','會員退費完成',now() - interval '2 days',now() - interval '1 day','member.refunded@v8.test','finance@tuibile.test','seed：已退費，名額與攤位應釋出',now() - interval '2 days')
on conflict (id) do update set status=excluded.status, refund_amount=excluded.refund_amount, requested_at=excluded.requested_at, confirmed_at=excluded.confirmed_at, created_at=excluded.created_at, note=excluded.note;

-- ────────────────────────────────────────────────────────────────
-- Stalls / equipment
-- ────────────────────────────────────────────────────────────────

insert into public.stalls
(id, tenant_id, session_id, stall_no, number, status, reg_id, email, hold_time, meta_json)
values
('STL_A01','tuibile','SES_MARKET_REVIEW_PAID','A01','A01','鎖定','REG_PAID','member.paid@v8.test',now() - interval '8 days','{"source":"seed"}'),
('STL_A02','tuibile','SES_MARKET_REVIEW_PAID','A02','A02','預留','REG_PENDING_PAYMENT','member.pending@v8.test',now() - interval '9 days','{"source":"seed"}'),
('STL_A03','tuibile','SES_MARKET_REVIEW_PAID','A03','A03','預留','REG_REFUNDING','member.refunding@v8.test',now() - interval '8 days','{"source":"seed"}'),
('STL_A04','tuibile','SES_MARKET_REVIEW_PAID','A04','A04','空閒',null,null,null,'{"source":"seed"}'),
('STL_A05','tuibile','SES_MARKET_REVIEW_PAID','A05','A05','空閒',null,null,null,'{"source":"seed"}'),
('STL_A06','tuibile','SES_MARKET_REVIEW_PAID','A06','A06','空閒',null,null,null,'{"source":"seed"}'),
('STL_C01','tuibile','SES_CONSIGN_PAID','C01','C01','空閒',null,null,null,'{"source":"seed"}'),
('STL_C02','tuibile','SES_CONSIGN_PAID','C02','C02','空閒',null,null,null,'{"source":"seed"}'),
('STL_C03','tuibile','SES_CONSIGN_PAID','C03','C03','空閒',null,null,null,'{"source":"seed"}'),
('STL_D01','demo_tenant','SES_DEMO_MARKET','D01','D01','鎖定','REG_DEMO_PAID','member.demo@v8.test',now() - interval '8 days','{"source":"seed"}'),
('STL_D02','demo_tenant','SES_DEMO_MARKET','D02','D02','空閒',null,null,null,'{"source":"seed"}'),
('STL_D03','demo_tenant','SES_DEMO_MARKET','D03','D03','空閒',null,null,null,'{"source":"seed"}')
on conflict (tenant_id, session_id, stall_no) do update set
number=excluded.number,
status=excluded.status,
reg_id=excluded.reg_id,
email=excluded.email,
hold_time=excluded.hold_time,
meta_json=excluded.meta_json;

insert into public.equipment_items
(id, tenant_id, session_id, name, price, included_qty, stock_qty, is_active, meta_json)
values
('EQ_MARKET_TABLE','tuibile','SES_MARKET_REVIEW_PAID','桌',150,1,50,true,'{}'),
('EQ_MARKET_CHAIR','tuibile','SES_MARKET_REVIEW_PAID','椅',50,1,100,true,'{}'),
('EQ_MARKET_ELECTRIC','tuibile','SES_MARKET_REVIEW_PAID','電',300,0,20,true,'{}'),
('EQ_CONSIGN_SETUP','tuibile','SES_CONSIGN_PAID','上架服務',200,0,20,true,'{}'),
('EQ_CONSIGN_REMOVE','tuibile','SES_CONSIGN_PAID','代撤服務',150,0,20,true,'{}'),
('EQ_CONSIGN_TRANSFER','tuibile','SES_CONSIGN_PAID','轉移服務',100,0,20,true,'{}'),
('EQ_DEMO_TABLE','demo_tenant','SES_DEMO_MARKET','桌',100,1,20,true,'{}')
on conflict (id) do update set price=excluded.price, included_qty=excluded.included_qty, stock_qty=excluded.stock_qty, is_active=excluded.is_active;

-- ────────────────────────────────────────────────────────────────
-- Finance / invoices
-- ────────────────────────────────────────────────────────────────

insert into public.finance_items
(id, tenant_id, session_id, type, name, amount, is_auto, meta_json)
values
('FIN_MARKET_OTHER_INCOME','tuibile','SES_MARKET_REVIEW_PAID','income','其他收入測試',1000,false,'{"source":"seed"}'),
('FIN_MARKET_EXPENSE','tuibile','SES_MARKET_REVIEW_PAID','expense','場地支出測試',500,false,'{"source":"seed"}'),
('FIN_DEMO_EXPENSE','demo_tenant','SES_DEMO_MARKET','expense','Demo 支出測試',200,false,'{"source":"seed"}')
on conflict (id) do update set amount=excluded.amount, type=excluded.type, name=excluded.name;

insert into public.invoices
(id, tenant_id, reg_id, session_id, invoice_type, invoice_title, tax_id, invoice_email, invoice_carrier, amount_total, amount_untaxed, tax_amount, status, issued_at, note)
values
('INV_PENDING','tuibile','REG_PENDING_PAYMENT','SES_MARKET_REVIEW_PAID','個人','','','member.pending@v8.test','',1800,1714,86,'待開立',null,'押金不列入發票'),
('INV_PAID','tuibile','REG_PAID','SES_MARKET_REVIEW_PAID','公司','已付款有限公司','12345678','invoice.paid@v8.test','',2400,2286,114,'待開立',null,'押金不列入發票'),
('INV_REFUNDING','tuibile','REG_REFUNDING','SES_MARKET_REVIEW_PAID','個人','','','member.refunding@v8.test','',1200,1143,57,'待處理',null,'退費中仍保留原始發票追溯資料，押金不列入發票'),
('INV_REFUNDED','tuibile','REG_REFUNDED','SES_MARKET_REVIEW_PAID','個人','','','member.refunded@v8.test','',1200,1143,57,'作廢',null,'已退費仍保留原始發票追溯資料，押金不列入發票'),
('INV_CONSIGN','tuibile','REG_CONSIGN','SES_CONSIGN_PAID','公司','已付款有限公司','12345678','invoice.paid@v8.test','',1150,1095,55,'待開立',null,'寄賣費用發票追溯資料'),
('INV_DEMO','demo_tenant','REG_DEMO_PAID','SES_DEMO_MARKET','個人','','','member.demo@v8.test','',600,571,29,'待開立',null,'Demo 發票測試')
on conflict (id) do update set status=excluded.status, amount_total=excluded.amount_total, amount_untaxed=excluded.amount_untaxed, tax_amount=excluded.tax_amount;

-- ────────────────────────────────────────────────────────────────
-- Email templates / report templates / announcements / audit logs
-- ────────────────────────────────────────────────────────────────

insert into public.email_templates
(id, tenant_id, template_key, subject, body_html, button_label, is_active)
values
('MAIL_TUIBILE_REG_CONFIRM','tuibile','registration_confirm','[placeholder] 報名確認','<p>[placeholder] 已收到報名。請回到我的紀錄查看狀態。</p>','前往我的紀錄',true),
('MAIL_TUIBILE_APPROVAL','tuibile','approval','[placeholder] 錄取通知','<p>[placeholder] 已錄取。請回到我的紀錄查看付款資訊。</p>','前往我的紀錄繳費',true),
('MAIL_TUIBILE_REJECT','tuibile','rejection','[placeholder] 結果通知','<p>[placeholder] 本次未錄取或額滿，正式文案後續替換。</p>','查看我的紀錄',true),
('MAIL_TUIBILE_PAYMENT_CONFIRM','tuibile','payment_confirm','[placeholder] 付款完成','<p>[placeholder] 付款已確認。</p>','查看我的紀錄',true),
('MAIL_TUIBILE_REFUND','tuibile','refund','[placeholder] 退費通知','<p>[placeholder] 退費狀態更新。</p>','查看我的紀錄',true),
('MAIL_DEMO_REG_CONFIRM','demo_tenant','registration_confirm','[placeholder] Demo 報名確認','<p>[placeholder] Demo 已收到報名。</p>','前往我的紀錄',true)
on conflict (tenant_id, template_key) do update set subject=excluded.subject, body_html=excluded.body_html, button_label=excluded.button_label, is_active=excluded.is_active;

insert into public.report_templates
(id, tenant_id, template_key, name, file_format, columns_json, role_required, is_active)
values
('RPT_TUIBILE_FULL','tuibile','registrations_full','完整名單 CSV','csv','["場次","姓名","Email","品牌","審核狀態","付款狀態","退費狀態","總金額","設備","選位"]'::jsonb,'organizer_admin',true),
('RPT_TUIBILE_PAYMENT','tuibile','payments','付款清單 CSV','csv','["場次","姓名","Email","金額","付款方式","付款狀態","回報時間","確認時間"]'::jsonb,'finance_admin',true),
('RPT_TUIBILE_INVOICE','tuibile','invoices','發票清單 CSV','csv','["姓名","Email","發票類型","統編","抬頭","未稅","稅額","含稅","狀態"]'::jsonb,'finance_admin',true),
('RPT_DEMO_FULL','demo_tenant','registrations_full','Demo 完整名單 CSV','csv','["場次","姓名","Email","品牌","付款狀態"]'::jsonb,'organizer_admin',true)
on conflict (tenant_id, template_key) do update set name=excluded.name, file_format=excluded.file_format, columns_json=excluded.columns_json, role_required=excluded.role_required, is_active=excluded.is_active;

-- ────────────────────────────────────────────────────────────────
-- Report exports / download logs（逐筆業務時間驗算測試資料）
-- 時間鏈：created_at(-2d) <= generated_at(-2d) <= downloaded_at(-1d)
-- download_logs.created_at(-1d) >= 對應 export.created_at(-2d)
-- ────────────────────────────────────────────────────────────────

insert into public.report_exports
(id, tenant_id, session_id, event_id, template_id, file_name, file_format, status, snapshot_summary_json, generated_by, generated_at, downloaded_at, created_at)
values
('RPX_TUIBILE_FULL_001','tuibile','SES_MARKET_REVIEW_PAID','EV_TUIBILE_MAIN','RPT_TUIBILE_FULL','tuibile_market_full_20260620.csv','csv','downloaded','{"rows":2,"note":"seed 完整名單匯出"}'::jsonb,'organizer@tuibile.test',now() - interval '2 days',now() - interval '1 day',now() - interval '2 days'),
('RPX_DEMO_FULL_001','demo_tenant','SES_DEMO_MARKET','EV_DEMO_MAIN','RPT_DEMO_FULL','demo_market_full_20260620.csv','csv','generated','{"rows":1,"note":"seed Demo 匯出，尚未下載"}'::jsonb,'organizer@demo.test',now() - interval '2 days',null,now() - interval '2 days')
on conflict (id) do update set status=excluded.status, file_name=excluded.file_name, file_format=excluded.file_format, snapshot_summary_json=excluded.snapshot_summary_json, generated_by=excluded.generated_by, generated_at=excluded.generated_at, downloaded_at=excluded.downloaded_at, created_at=excluded.created_at;

insert into public.report_download_logs
(id, tenant_id, session_id, event_id, template_id, export_id, staff_email, action, file_name, file_format, status, user_agent, meta_json, created_at)
values
('RDL_TUIBILE_001','tuibile','SES_MARKET_REVIEW_PAID','EV_TUIBILE_MAIN','RPT_TUIBILE_FULL','RPX_TUIBILE_FULL_001','organizer@tuibile.test','download','tuibile_market_full_20260620.csv','csv','downloaded','Mozilla/5.0 (seed test)','{"note":"seed 下載紀錄"}'::jsonb,now() - interval '1 day')
on conflict (id) do update set action=excluded.action, file_name=excluded.file_name, file_format=excluded.file_format, status=excluded.status, user_agent=excluded.user_agent, meta_json=excluded.meta_json, created_at=excluded.created_at;

insert into public.announcements
(id, tenant_id, title, content, link_url, link_text, url, url_text)
values
('ANN_TUIBILE_V8','tuibile','V8 測試公告','這是 V8 seed 測試公告。','https://2b-love.com','查看','https://2b-love.com','查看'),
('ANN_DEMO_V8','demo_tenant','Demo V8 測試公告','第二 tenant 測試公告。','https://2b-love.com/demo','查看','https://2b-love.com/demo','查看')
on conflict (id) do update set title=excluded.title, content=excluded.content, link_url=excluded.link_url, link_text=excluded.link_text, url=excluded.url, url_text=excluded.url_text;

insert into public.audit_logs
(id, tenant_id, actor_email, actor_role, action, target_table, target_id, before_json, after_json, meta_json)
values
('AUDIT_SEED_001','tuibile','system@v8.seed','system','seed_database','all','v8_seed','{}'::jsonb,'{"status":"created"}'::jsonb,'{"note":"V8 seed data installed"}'::jsonb),
('AUDIT_REFUND_RELEASE','tuibile','finance@tuibile.test','finance_admin','refund_completed_release_capacity_and_stall','registrations','REG_REFUNDED','{}'::jsonb,'{"payment_status":"已退費","transfer_status":"已退費","registration_status":"refunded","releaseCapacity":true,"releaseStall":true,"keepReviewStatus":true}'::jsonb,'{"decision":"2BL V8 MVP default"}'::jsonb),
('AUDIT_DEMO_SEED','demo_tenant','system@v8.seed','system','seed_database','all','demo_seed','{}'::jsonb,'{"status":"created"}'::jsonb,'{"note":"Demo tenant seed data installed"}'::jsonb)
on conflict (id) do update set after_json=excluded.after_json, meta_json=excluded.meta_json;


-- ────────────────────────────────────────────────────────────────
-- H-03: Platform staff（全域超管，不限 tenant）
-- ────────────────────────────────────────────────────────────────

insert into public.platform_staff (id, email, name, role, is_active, note)
values
('PSF_PLATFORM_SUPER','platform@v8.test','平台超級管理員','platform_super_admin',true,'V8 測試用平台超管，可跨 tenant 操作所有資料')
on conflict (email) do update set
name=excluded.name, role=excluded.role, is_active=excluded.is_active, note=excluded.note;

-- 說明：
-- platform_staff 的 token 格式為 makeToken(email, 'platform', env)
-- 即 md5(email + 'platform' + AUTH_SECRET)
-- 不同於 tenant staff 的 md5(email + tenantId + AUTH_SECRET)

commit;

-- ────────────────────────────────────────────────────────────────
-- 不可抗力模組測試資料
-- 場景 A：有延期目標場次（transfer_or_refund 模式）
-- 場景 B：無延期場次（refund_only 模式）
-- ────────────────────────────────────────────────────────────────

begin;

-- 場景 A：已啟動不可抗力（颱風警報），提供延期目標場次
insert into public.sessions (id, tenant_id, name, type, region, dates_json, venue, fee, deposit,
  limit_count, max_stalls, current_count, status, need_review, modules_json, equip_json,
  custom_fields_json, addons_json, invoice_tax_json,
  force_cancelled, force_cancel_reason_code, force_cancel_reason_label, force_cancelled_at,
  force_mode, force_transfer_target_session_id, force_choice_deadline, created_at)
values (
  'SES_FORCE_A', 'tuibile', 'V8 不可抗力場次A（已取消）', '市集場次', '台中',
  '[{"date":"2026-07-01","fee":1200,"limit":10}]'::jsonb,
  '台中逢甲夜市廣場', 1200, 500, 10, 10, 3, '關閉', true,
  '{}'::jsonb, '{}'::jsonb, '[]'::jsonb, '[]'::jsonb,
  '{"stall":true,"equip":false,"extra":false}'::jsonb,
  true, 'typhoon', '颱風警報',
  (now() - interval '2 hours'),
  'transfer_or_refund', 'SES_FORCE_B',
  (now() + interval '46 hours'),
  now()
) on conflict (id) do update set
  force_cancelled=excluded.force_cancelled, force_cancel_reason_code=excluded.force_cancel_reason_code,
  force_cancel_reason_label=excluded.force_cancel_reason_label, force_mode=excluded.force_mode,
  force_transfer_target_session_id=excluded.force_transfer_target_session_id,
  force_choice_deadline=excluded.force_choice_deadline;

-- 場景 A 延期目標場次
insert into public.sessions (id, tenant_id, name, type, region, dates_json, venue, fee, deposit,
  limit_count, max_stalls, current_count, status, need_review, modules_json, equip_json,
  custom_fields_json, addons_json, invoice_tax_json, created_at)
values (
  'SES_FORCE_B', 'tuibile', 'V8 不可抗力延期目標場次B', '市集場次', '台中',
  '[{"date":"2026-07-15","fee":1200,"limit":10}]'::jsonb,
  '台中逢甲夜市廣場（延期）', 1200, 500, 10, 10, 0, '報名中', true,
  '{}'::jsonb, '{}'::jsonb, '[]'::jsonb, '[]'::jsonb,
  '{"stall":true,"equip":false,"extra":false}'::jsonb, now()
) on conflict (id) do nothing;

-- 場景 C：無延期，refund_only 模式
insert into public.sessions (id, tenant_id, name, type, region, dates_json, venue, fee, deposit,
  limit_count, max_stalls, current_count, status, need_review, modules_json, equip_json,
  custom_fields_json, addons_json, invoice_tax_json,
  force_cancelled, force_cancel_reason_code, force_cancel_reason_label, force_cancelled_at,
  force_mode, force_choice_deadline, created_at)
values (
  'SES_FORCE_C', 'tuibile', 'V8 不可抗力場次C（無延期）', '市集場次', '台中',
  '[{"date":"2026-07-05","fee":1000,"limit":5}]'::jsonb,
  '台中文心路廣場', 1000, 300, 5, 5, 2, '關閉', true,
  '{}'::jsonb, '{}'::jsonb, '[]'::jsonb, '[]'::jsonb,
  '{"stall":true,"equip":false,"extra":false}'::jsonb,
  true, 'venue_unavailable', '場地突發不可使用',
  (now() - interval '1 hour'),
  'refund_only', (now() + interval '47 hours'),
  now()
) on conflict (id) do update set
  force_cancelled=excluded.force_cancelled, force_mode=excluded.force_mode;

-- 場景 A 報名資料（第一層：已錄取+已付款 → pending_force_choice）
insert into public.members (email, tenant_id, name, brand_name)
values ('force.paid@v8.test','tuibile','林測試','測試品牌FM')
on conflict (tenant_id,email) do nothing;

insert into public.registrations (id, tenant_id, session_id, email, name, brand_name, phone,
  review_status, payment_status, amount, total_amount, deposit, stall_count,
  registration_status, checkin_status, clear_status, deposit_refunded, reminder_sent,
  sell_category, equipment_json, custom_fields_json, addon_qty_json, selected_dates_json,
  participants_json, stall_number, force_status, created_at)
values
-- pending_force_choice（可選延期或退費）
('REG_FM_CHOICE','tuibile','SES_FORCE_A','force.paid@v8.test','林測試','測試品牌FM','0912111111',
 '已錄取','已繳費',1700,1700,500,1,'active','未報到','未清場','未退押金',false,
 '飾品','{}','[]','{}','["2026-07-01"]','{}','','pending_force_choice',
 now() - interval '3 days'),
-- transferred（已同意延期）
('REG_FM_TRANSFERRED','tuibile','SES_FORCE_A','member.paid@v8.test','陳已付款','已付款測試品牌','0912222222',
 '已錄取','已繳費',1700,1700,500,1,'active','未報到','未清場','未退押金',false,
 '手作','{}','[]','{}','["2026-07-01"]','{}','','transferred',
 now() - interval '3 days'),
-- refund_requested（主動申請退費）
('REG_FM_REFUND_REQ','tuibile','SES_FORCE_A','member.pending@v8.test','王待確認','待確認測試品牌','0912333333',
 '已錄取','待確認',2300,2300,500,1,'active','未報到','未清場','未退押金',false,
 '服飾','{}','[]','{}','["2026-07-01"]','{}','','refund_requested',
 now() - interval '3 days'),
-- cancel_notice_only（已錄取未付款）
('REG_FM_NOTICE_ONLY','tuibile','SES_FORCE_A','force.paid@v8.test','林測試','測試品牌FM2','0912444444',
 '已錄取','未繳費',1200,1200,500,1,'active','未報到','未清場','未退押金',false,
 '手作','{}','[]','{}','["2026-07-01"]','{}','','cancel_notice_only',
 now() - interval '2 days')
on conflict (id) do nothing;

-- 場景 C 報名（refund_only_auto）
insert into public.registrations (id, tenant_id, session_id, email, name, brand_name, phone,
  review_status, payment_status, amount, total_amount, deposit, stall_count,
  registration_status, checkin_status, clear_status, deposit_refunded, reminder_sent,
  sell_category, equipment_json, custom_fields_json, addon_qty_json, selected_dates_json,
  participants_json, stall_number, force_status, force_refund_requested_at, created_at)
values
('REG_FM_REFUND_ONLY','tuibile','SES_FORCE_C','member.collab@v8.test','吳合作','合作測試','0912555555',
 '已錄取','已繳費',1000,1000,300,1,'active','未報到','未清場','未退押金',false,
 '藝術','{}','[]','{}','["2026-07-05"]','{}','','refund_only_auto',
 now() - interval '30 minutes', now() - interval '1 day')
on conflict (id) do nothing;

-- force_majeure_logs 測試資料
insert into public.force_majeure_logs (id, tenant_id, registration_id, session_id, action,
  old_status, new_status, actor_type, actor_email, reason_code, target_session_id, note, created_at)
values
('FML_001','tuibile','REG_FM_CHOICE','SES_FORCE_A','force_cancel_session',
 null,'pending_force_choice','admin','admin@tuibile.test','typhoon','SES_FORCE_B','模式:transfer_or_refund', now() - interval '2 hours'),
('FML_002','tuibile','REG_FM_TRANSFERRED','SES_FORCE_A','agree_force_transfer',
 'pending_force_choice','transferred','member','member.paid@v8.test','typhoon','SES_FORCE_B','新報名:REG_FM_TRANS_NEW', now() - interval '1 hour'),
('FML_003','tuibile','REG_FM_REFUND_REQ','SES_FORCE_A','apply_force_refund',
 'pending_force_choice','refund_requested','member','member.pending@v8.test',null,null,'', now() - interval '30 minutes')
on conflict (id) do nothing;

commit;

-- ── 不可抗力 seed 修正：正確金額 & 補充 registration_items & payments ──

begin;

-- 修正金額（SES_FORCE_A fee=1200, deposit=500 → total=1700）
update public.registrations set amount=1700, total_amount=1700
  where id in ('REG_FM_REFUND_REQ','REG_FM_NOTICE_ONLY');

-- 修正金額（SES_FORCE_C fee=1000, deposit=300 → total=1300）
update public.registrations set amount=1300, total_amount=1300
  where id = 'REG_FM_REFUND_ONLY';

-- 修正 SES_FORCE_C current_count（只有 1 筆活躍報名）
update public.sessions set current_count=1 where id='SES_FORCE_C';

-- registration_items for REG_FM_CHOICE（SES_FORCE_A, total=1700, deposit=500, fee=1200）
insert into public.registration_items (id,tenant_id,registration_id,session_id,item_type,item_name,quantity,unit_price,amount,tax_included,meta_json,created_at)
values
('ITEM_FM_C1','tuibile','REG_FM_CHOICE','SES_FORCE_A','stall_fee','報名費／攤位費',1,1200,1200,true,'{}',now()-interval '3 days'),
('ITEM_FM_C2','tuibile','REG_FM_CHOICE','SES_FORCE_A','deposit','押金',1,500,500,false,'{"excludeFromInvoice":true}',now()-interval '3 days')
on conflict (id) do nothing;

-- registration_items for REG_FM_TRANSFERRED
insert into public.registration_items (id,tenant_id,registration_id,session_id,item_type,item_name,quantity,unit_price,amount,tax_included,meta_json,created_at)
values
('ITEM_FM_T1','tuibile','REG_FM_TRANSFERRED','SES_FORCE_A','stall_fee','報名費／攤位費',1,1200,1200,true,'{}',now()-interval '3 days'),
('ITEM_FM_T2','tuibile','REG_FM_TRANSFERRED','SES_FORCE_A','deposit','押金',1,500,500,false,'{"excludeFromInvoice":true}',now()-interval '3 days')
on conflict (id) do nothing;

-- registration_items for REG_FM_REFUND_REQ（amount 已修正為 1700）
insert into public.registration_items (id,tenant_id,registration_id,session_id,item_type,item_name,quantity,unit_price,amount,tax_included,meta_json,created_at)
values
('ITEM_FM_R1','tuibile','REG_FM_REFUND_REQ','SES_FORCE_A','stall_fee','報名費／攤位費',1,1200,1200,true,'{}',now()-interval '3 days'),
('ITEM_FM_R2','tuibile','REG_FM_REFUND_REQ','SES_FORCE_A','deposit','押金',1,500,500,false,'{"excludeFromInvoice":true}',now()-interval '3 days')
on conflict (id) do nothing;

-- registration_items for REG_FM_NOTICE_ONLY（amount 已修正為 1700）
insert into public.registration_items (id,tenant_id,registration_id,session_id,item_type,item_name,quantity,unit_price,amount,tax_included,meta_json,created_at)
values
('ITEM_FM_N1','tuibile','REG_FM_NOTICE_ONLY','SES_FORCE_A','stall_fee','報名費／攤位費',1,1200,1200,true,'{}',now()-interval '2 days'),
('ITEM_FM_N2','tuibile','REG_FM_NOTICE_ONLY','SES_FORCE_A','deposit','押金',1,500,500,false,'{"excludeFromInvoice":true}',now()-interval '2 days')
on conflict (id) do nothing;

-- registration_items for REG_FM_REFUND_ONLY（SES_FORCE_C fee=1000, deposit=300, total=1300）
insert into public.registration_items (id,tenant_id,registration_id,session_id,item_type,item_name,quantity,unit_price,amount,tax_included,meta_json,created_at)
values
('ITEM_FM_O1','tuibile','REG_FM_REFUND_ONLY','SES_FORCE_C','stall_fee','報名費／攤位費',1,1000,1000,true,'{}',now()-interval '1 day'),
('ITEM_FM_O2','tuibile','REG_FM_REFUND_ONLY','SES_FORCE_C','deposit','押金',1,300,300,false,'{"excludeFromInvoice":true}',now()-interval '1 day')
on conflict (id) do nothing;

-- payments for paid FM regs（已繳費的補付款紀錄）
insert into public.payments (id,tenant_id,reg_id,session_id,email,amount,method,status,paid_at,created_at)
values
('PAY_FM_CHOICE','tuibile','REG_FM_CHOICE','SES_FORCE_A','force.paid@v8.test',1700,'匯款','已確認',now()-interval '2 days',now()-interval '3 days'),
('PAY_FM_TRANSFERRED','tuibile','REG_FM_TRANSFERRED','SES_FORCE_A','member.paid@v8.test',1700,'匯款','已確認',now()-interval '2 days',now()-interval '3 days'),
('PAY_FM_REFUND_ONLY','tuibile','REG_FM_REFUND_ONLY','SES_FORCE_C','member.collab@v8.test',1300,'匯款','已確認',now()-interval '12 hours',now()-interval '1 day')
on conflict (id) do nothing;

commit;

-- ── 不可抗力 seed 修正 2：補充 invoice_status 及 invoices 記錄 ──

begin;

-- 設定 FM 報名的 invoice_status
update public.registrations
  set invoice_status = '待開立'
  where id in ('REG_FM_CHOICE','REG_FM_TRANSFERRED','REG_FM_REFUND_REQ','REG_FM_NOTICE_ONLY','REG_FM_REFUND_ONLY');

-- 新增 invoices 記錄
insert into public.invoices (id, tenant_id, reg_id, session_id, invoice_type, invoice_title,
  tax_id, invoice_email, invoice_carrier, amount_total, amount_untaxed, tax_amount,
  status, note, created_at)
values
('INV_FM_CHOICE','tuibile','REG_FM_CHOICE','SES_FORCE_A','','','','force.paid@v8.test','',
  1200, 1143, 57, '待開立','2BL V8 自動建立：押金不列入發票', now()-interval '3 days'),
('INV_FM_TRANSFERRED','tuibile','REG_FM_TRANSFERRED','SES_FORCE_A','','','','member.paid@v8.test','',
  1200, 1143, 57, '待開立','2BL V8 自動建立：押金不列入發票', now()-interval '3 days'),
('INV_FM_REFUND_REQ','tuibile','REG_FM_REFUND_REQ','SES_FORCE_A','','','','member.pending@v8.test','',
  1200, 1143, 57, '待開立','2BL V8 自動建立：押金不列入發票', now()-interval '3 days'),
('INV_FM_NOTICE_ONLY','tuibile','REG_FM_NOTICE_ONLY','SES_FORCE_A','','','','force.paid@v8.test','',
  1200, 1143, 57, '待開立','2BL V8 自動建立：押金不列入發票', now()-interval '2 days'),
('INV_FM_REFUND_ONLY','tuibile','REG_FM_REFUND_ONLY','SES_FORCE_C','','','','member.collab@v8.test','',
  1000, 952, 48, '待開立','2BL V8 自動建立：押金不列入發票', now()-interval '1 day')
on conflict (id) do nothing;

commit;

-- ── 不可抗力 seed 修正 3：補充 transferred 連結 ──

begin;

-- REG_FM_TRANSFERRED 需要 transferred_to_session_id
update public.registrations
  set transferred_to_session_id = 'SES_FORCE_B',
      force_choice_at = now() - interval '1 hour',
      force_choice_email = 'member.paid@v8.test'
  where id = 'REG_FM_TRANSFERRED';

-- 建立對應的新報名（transferred_from_registration_id 連結回原始報名）
insert into public.registrations (id, tenant_id, session_id, email, name, brand_name, phone,
  review_status, payment_status, amount, total_amount, deposit, stall_count,
  registration_status, checkin_status, clear_status, deposit_refunded, reminder_sent,
  sell_category, equipment_json, custom_fields_json, addon_qty_json, selected_dates_json,
  participants_json, stall_number, original_session_id, transferred_from_registration_id,
  force_status, force_choice_at, force_choice_email, created_at)
values
('REG_FM_TRANS_NEW','tuibile','SES_FORCE_B','member.paid@v8.test','陳已付款','已付款測試品牌','0912222222',
 '已錄取','已繳費',1700,1700,500,1,'active','未報到','未清場','未退押金',false,
 '手作','{}','[]','{}','["2026-07-15"]','{}','',
 'SES_FORCE_A','REG_FM_TRANSFERRED',
 'transferred',now()-interval '1 hour','member.paid@v8.test',
 now()-interval '1 hour')
on conflict (id) do nothing;

-- 對應 registration_items & invoice for REG_FM_TRANS_NEW
insert into public.registration_items (id,tenant_id,registration_id,session_id,item_type,item_name,quantity,unit_price,amount,tax_included,meta_json,created_at)
values
('ITEM_FM_TN1','tuibile','REG_FM_TRANS_NEW','SES_FORCE_B','stall_fee','報名費／攤位費',1,1200,1200,true,'{}',now()-interval '1 hour'),
('ITEM_FM_TN2','tuibile','REG_FM_TRANS_NEW','SES_FORCE_B','deposit','押金',1,500,500,false,'{"excludeFromInvoice":true}',now()-interval '1 hour')
on conflict (id) do nothing;

insert into public.invoices (id, tenant_id, reg_id, session_id, invoice_type, invoice_title,
  tax_id, invoice_email, invoice_carrier, amount_total, amount_untaxed, tax_amount,
  status, note, created_at)
values
('INV_FM_TRANS_NEW','tuibile','REG_FM_TRANS_NEW','SES_FORCE_B','','','','member.paid@v8.test','',
  1200, 1143, 57, '待開立','不可抗力延期轉場', now()-interval '1 hour')
on conflict (id) do nothing;

-- 更新 SES_FORCE_B current_count（已有一筆 transferred 報名占用名額）
update public.sessions set current_count=1 where id='SES_FORCE_B';

commit;

-- ── 不可抗力 seed 修正 4：REG_FM_TRANS_NEW force_status & payment ──

begin;

-- 新報名不繼承 force_status（應為 null，不是 'transferred'）
update public.registrations
  set force_status = null,
      paid_at = now() - interval '2 days'
  where id = 'REG_FM_TRANS_NEW';

-- 補充付款記錄（延期的新報名沿用原付款狀態，補一筆參照 payment）
insert into public.payments (id,tenant_id,reg_id,session_id,email,amount,method,status,paid_at,created_at)
values
('PAY_FM_TRANS_NEW','tuibile','REG_FM_TRANS_NEW','SES_FORCE_B','member.paid@v8.test',1700,'匯款（不可抗力延期沿用）','已確認',now()-interval '2 days',now()-interval '1 hour')
on conflict (id) do nothing;

commit;

-- ── 不可抗力 seed 修正 5：修正 REG_FM_TRANS_NEW 時間一致性 ──

begin;

-- paid_at 必須晚於 created_at
update public.registrations
  set paid_at = created_at + interval '30 minutes'
  where id = 'REG_FM_TRANS_NEW';

update public.payments
  set paid_at = created_at + interval '30 minutes'
  where id = 'PAY_FM_TRANS_NEW';

commit;

-- ═══════════════════════════════════════════════════════════
-- 報名合約同意機制種子資料（003_agreement.sql 後執行）
-- ═══════════════════════════════════════════════════════════

begin;

-- ── 更新全部 sessions 加入合約版本與正文 ────────────────────
-- 以正式合約正文（使用者提供）作為所有測試場次的預設合約內容
update public.sessions
  set agreement_required   = true,
      agreement_title      = '報名合約／活動細則與攤商規範',
      agreement_version    = 'v1.0',
      agreement_updated_at = now(),
      agreement_content    = $$# 報名合約／活動細則與攤商規範

## 一、報名前審核與資料填寫

報名不等於錄取，請務必填正確信箱，以利通知

「為了公平審核，請務必提供攤位照片，讓我們更了解您的品牌風格」。

攤位佈置請展現品牌質感，需拍攝美照供審核

新手務必模擬擺攤後拍照上

---

## 二、合約同意與活動規範

🎪 活動細則與攤商規範

報名繳費後，即視同同意本合約條款。

請所有攤商詳細閱讀並配合，共同維護市集品質與安全。

---

## 三、報到與簽退

🕐 一、報到與簽退

活動前 60 分鐘報到（例：11:00 開始，報到時間為 10:00–10:45）。

活動開始前 10 分鐘 必須完成開攤並上傳「開攤照片」至 LINE 客服，

未上傳視同未到。

活動結束前 30 分鐘方可收攤，不得提前離場或空攤。

簽退時須上傳「清空後場地照片」，確認場地整潔與垃圾帶走。

憑「開攤＋清場照片」簽退，方可退還保證金。

---

## 四、安全與互助

🔹 二、安全與互助

請與臨攤成為「安全夥伴」，互相協助與照應。

若遇突發狀況（如身體不適、騷擾、設備倒塌等），請立即通報服務台協助。

攤商需自行搬運、佈置與撤收桌椅，並歸位至指定集中區。

活動中禁止明火、高溫電器或危險行為。

---

## 五、設備與場地使用

📦 三、設備與場地使用

現場不提供電源與照明，請自備 行動電源或充電燈具。

攤位禁止私自併攤、變更販售內容或超出範圍。

若設備或場地有損壞、污染，將依廠商報價酌收清潔或維修費。

結束後請清理地面、歸還桌椅並將垃圾自行帶走。

---

## 六、商品與品牌規範

🛍 四、商品與品牌規範

禁止販售未授權商品與仿冒品

嚴禁販售仿冒、未授權或違法商品。違規者不退費並取消資格。

食品類商品須全包裝並符合食品安全法規。

攤商建議自備含品牌名稱與 QR Code 的立牌，方便顧客辨識。

品牌若涉及版權或侵權爭議，攤商自行負責。

---

## 七、環保與包裝

響應環保，避免過度包裝 鼓勵自備提袋與環保包裝，共同維護整潔與永續理念。

---

## 八、活動延期與退款

☔ 五、活動延期與退款

報名繳費完成後即視同同意下列退款原則：

活動前 7 日以上取消：酌收行政費$ 500後退還餘額。

活動前 3～6 日取消：退還報名費 50%,押金不退還。

活動前 3 日內或當日未出席,押金不退還，不退費。

若因天災、疫情等不可抗力因素導致活動取消，主辦將依狀況擇期延期或退還 50%,退還押金。若遇颱風或豪雨等天災，主辦將以安全為首，保有延期或取消權。

---

## 九、誠信與秩序

⚖️ 六、誠信與秩序

攤商須遵守報到、營業與撤場時間，保持現場秩序與友善互動。

遲到、早退或臨時取消兩次以上，將列入警示名單並不再錄取。

主辦得視現場狀況調整攤位配置與動線安排，攤商須予以配合。

若違反本規範，主辦有權提前終止合約並扣除相關費用，違約金最高上限為新台幣 5 萬元整，管轄法院為台中地方法院。

如對活動有任何疑問或意見，歡迎先與主辦單位客服聯繫，我們將盡力協助說明與處理。

請勿於公開或私密管道散布不實、誤導或足以損害名譽之言論；若經查證屬實，主辦得視情節終止合作並保留法律追訴權。

---

## 十、友善提醒

官方公告與全台市集大群組為最終依據，請保持通訊暢通。
https://line.me/ti/g2/cp-K_Los4J2zBc6rGcRA14TJCx3e99v0i4p-hQ?utm_source=invitation&utm_medium=link_copy&utm_campaign=default

---

## 十一、客服聯絡方式

📩 客服聯絡方式：

若有任何報名異動或退款問題，請聯繫 👉 兔彼樂共創活動有限公司

感謝每一位誠信出攤的夥伴，讓我們一起打造一場有溫度、有秩序的美好市集

---

## 十二、主辦／協辦／活動權利

凡兔彼樂共創活動所屬指定活動場域，保有活動修正及解釋之權利。

詳細注意事項請詳閱行前通知信。$$
 where tenant_id in ('tuibile','demo_tenant');

-- ── 更新既有報名：補合約快照（模擬報名時已同意）────────────
-- 使用 sessions 的合約內容快照已存在的報名
update public.registrations r
  set agreement_accepted         = true,
      agreement_viewed           = true,
      agreement_viewed_at        = r.created_at + interval '10 seconds',
      agreement_accepted_at      = r.created_at + interval '20 seconds',
      agreement_email            = r.email,
      agreement_version          = 'v1.0',
      agreement_title_snapshot   = '報名合約／活動細則與攤商規範',
      agreement_content_snapshot = (
        select s.agreement_content
          from public.sessions s
         where s.id = r.session_id
         limit 1
      )
 where r.registration_status = 'active'
   and r.review_status not in ('已取消','不錄取');

commit;

-- ── 確認已套用 ───────────────────────────────────────────────
select count(*) as total_with_agreement_snapshot
  from public.registrations
 where agreement_accepted = true
   and agreement_content_snapshot is not null;

