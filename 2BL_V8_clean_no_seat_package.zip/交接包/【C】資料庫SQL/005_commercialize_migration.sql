-- ════════════════════════════════════════════════════════════════
-- 2BL V8 Migration 005: 商業化 + 統一 Google 登入
-- 執行順序：在 004_google_oauth_migration.sql 之後執行
-- 安全：全部 IF NOT EXISTS，不刪除任何既有資料
-- ════════════════════════════════════════════════════════════════

-- ────────────────────────────────────────────────────────────────
-- 1. tenants 表：新增商業化欄位
-- ────────────────────────────────────────────────────────────────
ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS plan_type text not null default 'trial';
  -- trial = 試用中, active = 正式, locked = 鎖定, archived = 封存

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS trial_start_at timestamptz;

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS trial_end_at timestamptz;

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS locked_at timestamptz;

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS locked_reason text;

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS is_locked boolean not null default false;

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS archived_at timestamptz;

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS session_count_used integer not null default 0;
  -- 按場次計費用：累計已建立的場次數

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS contact_name text;
  -- 申請時填的聯絡人姓名

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS contact_phone text;
  -- 申請時填的聯絡人電話

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS event_type text;
  -- 活動類型：市集/寄賣/體驗/合作

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS apply_note text;
  -- 申請備註

ALTER TABLE public.tenants
  ADD COLUMN IF NOT EXISTS notify_email text;
  -- 系統通知寄到哪個 email（預設 = staff owner 的 email）

-- ────────────────────────────────────────────────────────────────
-- 2. members 表：新增 Google 登入支援
-- ────────────────────────────────────────────────────────────────
ALTER TABLE public.members
  ADD COLUMN IF NOT EXISTS google_sub text;
  -- Google 的唯一識別碼（sub）

ALTER TABLE public.members
  ADD COLUMN IF NOT EXISTS google_email text;
  -- Google 登入的 email（可能跟帳號 email 不同）

ALTER TABLE public.members
  ADD COLUMN IF NOT EXISTS display_name text;
  -- Google 顯示名稱

ALTER TABLE public.members
  ADD COLUMN IF NOT EXISTS avatar_url text;
  -- Google 頭像

ALTER TABLE public.members
  ADD COLUMN IF NOT EXISTS last_login_at timestamptz;

ALTER TABLE public.members
  ADD COLUMN IF NOT EXISTS login_provider text not null default 'email';
  -- email / google

-- ────────────────────────────────────────────────────────────────
-- 3. 新增 billing_logs 表（計費記錄）
-- ────────────────────────────────────────────────────────────────
create table if not exists public.billing_logs (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  billing_type text not null default 'per_session',
  -- per_session = 按場次, manual = 手動確認
  amount numeric(10,2) not null default 0,
  tax numeric(10,2) not null default 0,
  total numeric(10,2) not null default 0,
  session_id text,
  -- 若是按場次，記錄哪個場次
  period_start timestamptz,
  period_end timestamptz,
  status text not null default 'pending',
  -- pending = 待確認, confirmed = 已確認, cancelled = 已取消
  confirmed_at timestamptz,
  confirmed_by text,
  -- 你（管理者）的 email
  note text,
  created_at timestamptz not null default now()
);

create index if not exists idx_billing_logs_tenant on public.billing_logs(tenant_id);
create index if not exists idx_billing_logs_status on public.billing_logs(status);
create index if not exists idx_billing_logs_created on public.billing_logs(created_at desc);

-- ────────────────────────────────────────────────────────────────
-- 4. 新增 tenant_apply_logs 表（申請記錄）
-- ────────────────────────────────────────────────────────────────
create table if not exists public.tenant_apply_logs (
  id text primary key,
  brand_name text not null,
  contact_name text not null,
  contact_email text not null,
  contact_phone text,
  event_type text,
  plan_type text not null default 'trial',
  note text,
  status text not null default 'pending',
  -- pending = 待處理, approved = 已開通, rejected = 已拒絕
  tenant_id text,
  -- 開通後填入
  approved_at timestamptz,
  approved_by text,
  created_at timestamptz not null default now()
);

create index if not exists idx_apply_logs_status on public.tenant_apply_logs(status);
create index if not exists idx_apply_logs_created on public.tenant_apply_logs(created_at desc);

-- ────────────────────────────────────────────────────────────────
-- 5. 新增 platform_sessions 表（統一登入 session）
-- ────────────────────────────────────────────────────────────────
create table if not exists public.platform_sessions (
  id text primary key,
  google_sub text not null,
  google_email text not null,
  display_name text,
  avatar_url text,
  role text not null default 'member',
  -- member = 報名者, organizer = 主辦方, both = 兩者
  tenant_ids text,
  -- 若是主辦方，記錄管理哪些 tenant（逗號分隔）
  jwt_token text,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  last_used_at timestamptz not null default now()
);

create index if not exists idx_platform_sessions_sub on public.platform_sessions(google_sub);
create index if not exists idx_platform_sessions_email on public.platform_sessions(google_email);

-- ────────────────────────────────────────────────────────────────
-- 6. 驗算
-- ────────────────────────────────────────────────────────────────
DO $$
DECLARE missing text := '';
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='tenants' AND column_name='plan_type') THEN
    missing := missing || 'tenants.plan_type, ';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='tenants' AND column_name='is_locked') THEN
    missing := missing || 'tenants.is_locked, ';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='billing_logs') THEN
    missing := missing || 'billing_logs, ';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='tenant_apply_logs') THEN
    missing := missing || 'tenant_apply_logs, ';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='platform_sessions') THEN
    missing := missing || 'platform_sessions, ';
  END IF;
  IF missing <> '' THEN
    RAISE EXCEPTION '005 migration 未完整：%', missing;
  ELSE
    RAISE NOTICE '✅ 005_commercialize_migration 執行完成';
  END IF;
END $$;
