-- ══════════════════════════════════════════════════════════════
-- 007_agreement_templates_table.sql
-- 合約範本表（V8新增，供後台設定最多3個可重用合約範本）
-- ══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS public.tenant_agreement_templates (
  id            text        PRIMARY KEY,
  tenant_id     text        NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  slot_no       integer     NOT NULL CHECK (slot_no BETWEEN 1 AND 3),
  label         text        NOT NULL DEFAULT '範本',
  title         text        NOT NULL DEFAULT '',
  content       text        NOT NULL DEFAULT '',
  version       text        NOT NULL DEFAULT '',
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, slot_no)
);

-- RLS
ALTER TABLE public.tenant_agreement_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tenant_agreement_templates_tenant_isolation"
  ON public.tenant_agreement_templates
  USING (tenant_id = current_setting('app.tenant_id', true));

-- Index
CREATE INDEX IF NOT EXISTS idx_agr_tmpl_tenant
  ON public.tenant_agreement_templates(tenant_id, slot_no);

-- 更新 schema cache
NOTIFY pgrst, 'reload schema';
