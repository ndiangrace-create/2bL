-- 補充 sessions 表缺少的合約同意欄位
ALTER TABLE public.sessions
  ADD COLUMN IF NOT EXISTS agreement_required   boolean DEFAULT true,
  ADD COLUMN IF NOT EXISTS agreement_title      text    DEFAULT '報名合約／活動細則與攤商規範',
  ADD COLUMN IF NOT EXISTS agreement_content    text    DEFAULT '',
  ADD COLUMN IF NOT EXISTS agreement_version    text    DEFAULT '',
  ADD COLUMN IF NOT EXISTS agreement_updated_at timestamptz;

-- 更新 schema cache
NOTIFY pgrst, 'reload schema';
