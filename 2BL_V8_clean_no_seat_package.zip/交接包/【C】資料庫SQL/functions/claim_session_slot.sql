-- ================================================================
-- 2BL V8｜名額原子鎖定 Functions
-- File: database/functions/claim_session_slot.sql
-- Purpose:
--   以 DB 層級 FOR UPDATE 原子鎖定，防止 Cloudflare Workers
--   多實例並發時發生名額超收（race condition）。
--
-- 說明：
--   claim_session_slot  — 原子扣名額（報名時）
--   release_session_slot — 原子釋放名額（取消 / 退費完成時）
--
-- 使用方式（在 Worker 中透過 Supabase RPC 呼叫）：
--   POST /rest/v1/rpc/claim_session_slot
--   { "p_tenant_id": "tuibile", "p_session_id": "SES_xxx", "p_stall_count": 1 }
--
--   POST /rest/v1/rpc/release_session_slot
--   { "p_tenant_id": "tuibile", "p_session_id": "SES_xxx", "p_stall_count": 1 }
-- ================================================================

-- ────────────────────────────────────────────────────────────────
-- claim_session_slot
--   原子鎖定 session row → 檢查剩餘名額 → 若足夠則扣減並回傳 true
--   若名額不足回傳 false（不拋出錯誤，由 Worker 決定顯示文字）
-- ────────────────────────────────────────────────────────────────
create or replace function public.claim_session_slot(
  p_tenant_id   text,
  p_session_id  text,
  p_stall_count integer default 1
)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_current_count integer;
  v_limit_count   integer;
  v_remaining     integer;
begin
  -- FOR UPDATE：鎖住此 session row，阻擋同時間其他 transaction 讀取
  select current_count, limit_count
    into v_current_count, v_limit_count
    from public.sessions
   where id = p_session_id
     and tenant_id = p_tenant_id
   for update;

  if not found then
    return jsonb_build_object('ok', false, 'error', '找不到場次');
  end if;

  -- limit_count = 0 代表無上限（不限制總名額）
  if v_limit_count > 0 then
    v_remaining := v_limit_count - coalesce(v_current_count, 0);
    if v_remaining < p_stall_count then
      return jsonb_build_object(
        'ok', false,
        'error', '名額不足',
        'remaining', v_remaining
      );
    end if;
  end if;

  -- 原子扣減：不允許低於 0
  update public.sessions
     set current_count = greatest(0, coalesce(current_count, 0) + p_stall_count),
         updated_at    = now()
   where id = p_session_id
     and tenant_id = p_tenant_id;

  return jsonb_build_object(
    'ok', true,
    'remaining', greatest(0, coalesce(v_limit_count, 0) - coalesce(v_current_count, 0) - p_stall_count)
  );
end;
$$;

-- ────────────────────────────────────────────────────────────────
-- release_session_slot
--   原子釋放名額（取消 / 退費完成 / 審核不錄取時）
--   不允許 current_count 低於 0（防止重複釋放造成負數）
-- ────────────────────────────────────────────────────────────────
create or replace function public.release_session_slot(
  p_tenant_id   text,
  p_session_id  text,
  p_stall_count integer default 1
)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_current_count integer;
begin
  -- FOR UPDATE：鎖住此 session row
  select current_count
    into v_current_count
    from public.sessions
   where id = p_session_id
     and tenant_id = p_tenant_id
   for update;

  if not found then
    return jsonb_build_object('ok', false, 'error', '找不到場次');
  end if;

  -- 原子釋放：絕不低於 0
  update public.sessions
     set current_count = greatest(0, coalesce(current_count, 0) - p_stall_count),
         updated_at    = now()
   where id = p_session_id
     and tenant_id = p_tenant_id;

  return jsonb_build_object(
    'ok', true,
    'released', p_stall_count,
    'new_count', greatest(0, coalesce(v_current_count, 0) - p_stall_count)
  );
end;
$$;

-- ────────────────────────────────────────────────────────────────
-- Grant：讓 service_role 可呼叫
-- ────────────────────────────────────────────────────────────────
grant execute on function public.claim_session_slot(text, text, integer)   to service_role;
grant execute on function public.release_session_slot(text, text, integer) to service_role;
