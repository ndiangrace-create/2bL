-- ============================================================
-- 003_agreement.sql
-- 報名合約同意機制 — 新增欄位
-- 使用 ADD COLUMN IF NOT EXISTS，可重複執行，不破壞既有資料。
-- 必須在 001_init.sql、claim_session_slot.sql、
--   002_force_majeure.sql、seed_test_data.sql 之後執行。
-- ============================================================

-- ── sessions：合約設定欄位 ──────────────────────────────────
alter table public.sessions
  add column if not exists agreement_required    boolean not null default true,
  add column if not exists agreement_title       text,
  add column if not exists agreement_content     text,
  add column if not exists agreement_version     text,
  add column if not exists agreement_updated_at  timestamptz;

-- ── registrations：合約同意紀錄欄位 ────────────────────────
alter table public.registrations
  add column if not exists agreement_accepted          boolean not null default false,
  add column if not exists agreement_viewed            boolean not null default false,
  add column if not exists agreement_viewed_at         timestamptz,
  add column if not exists agreement_accepted_at       timestamptz,
  add column if not exists agreement_email             text,
  add column if not exists agreement_version           text,
  add column if not exists agreement_title_snapshot    text,
  add column if not exists agreement_content_snapshot  text;

-- ── index ───────────────────────────────────────────────────
create index if not exists idx_registrations_agreement_accepted
  on public.registrations(tenant_id, agreement_accepted);

-- ── 完成訊息 ────────────────────────────────────────────────
do $$ begin
  raise notice '003_agreement.sql 執行完成';
end $$;
