-- ================================================================
-- 2BL V8｜全新 Supabase 測試資料庫建置檔
-- File: database/001_init.sql
-- Purpose: 在全新的 Supabase 專案建立 2BL V8 MVP 所需完整資料表
-- Safe note: 本檔使用 CREATE TABLE IF NOT EXISTS，不會清空資料表。
-- 修正版：2026-06-22（地基修正）
--   - 新增 platform_staff 表（H-03：platform_super_admin 跨 tenant）
--   - registrations 廢棄欄位注釋（H-01）
-- ================================================================

begin;

create extension if not exists pgcrypto;

-- ────────────────────────────────────────────────────────────────
-- 1. Tenants / tenant settings
-- ────────────────────────────────────────────────────────────────

create table if not exists public.tenants (
  id text primary key,
  slug text unique,
  name text not null,
  status text not null default 'active',
  config_json jsonb not null default '{}'::jsonb,
  line_url text,
  bank_info text,
  logo_url text,
  cover_url text,
  email_from text,
  email_reply_to text,
  footer_text text,
  site_url text,
  default_refund_rules_json jsonb not null default '{}'::jsonb,
  payment_config_json jsonb not null default '{}'::jsonb,
  invoice_mode text not null default 'manual',
  invoice_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tenant_settings (
  tenant_id text primary key references public.tenants(id) on delete cascade,
  organizer_name text,
  logo_url text,
  cover_url text,
  line_url text,
  payment_config_json jsonb not null default '{}'::jsonb,
  email_templates_json jsonb not null default '{}'::jsonb,
  -- module_flags_json.requireSocialLinks: true = 報名時 FB 或 IG 至少填一個（H-02）
  module_flags_json jsonb not null default '{}'::jsonb,
  refund_rules_json jsonb not null default '{}'::jsonb,
  theme_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ────────────────────────────────────────────────────────────────
-- 2. Roles / permissions / staff
-- ────────────────────────────────────────────────────────────────

create table if not exists public.roles (
  id text primary key,
  name text not null,
  level integer not null default 0,
  description text,
  created_at timestamptz not null default now()
);

create table if not exists public.permissions (
  id text primary key,
  name text not null,
  description text,
  created_at timestamptz not null default now()
);

create table if not exists public.role_permissions (
  role_id text not null references public.roles(id) on delete cascade,
  permission_id text not null references public.permissions(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (role_id, permission_id)
);

-- H-03：platform_staff — 平台層全域管理員，不綁定任何 tenant
-- platform_super_admin 透過此表認證後，可操作所有 tenant 的資料
create table if not exists public.platform_staff (
  id text primary key,
  email text not null unique,
  name text,
  role text not null default 'platform_super_admin',
  is_active boolean not null default true,
  note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.staff (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  email text not null,
  name text,
  role text not null default 'organizer_admin',
  role_id text references public.roles(id),
  perms_json jsonb not null default '{}'::jsonb,
  limit_sessions text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tenant_id, email)
);

-- ────────────────────────────────────────────────────────────────
-- 3. Events / sessions / registration types
-- ────────────────────────────────────────────────────────────────

create table if not exists public.events (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  title text not null,
  description text,
  location text,
  cover_url text,
  status text default '開放中',
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.registration_types (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  code text not null,
  name text not null,
  module_key text not null default 'market',
  need_payment boolean not null default true,
  default_need_review boolean not null default true,
  config_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique (tenant_id, code)
);

create table if not exists public.sessions (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  event_id text references public.events(id) on delete set null,
  registration_type_id text references public.registration_types(id) on delete set null,
  name text not null,
  type text not null default '市集場次',
  region text,
  dates_json jsonb not null default '[]'::jsonb,
  venue text,
  fee numeric not null default 0,
  deposit numeric not null default 0,
  limit_count integer not null default 0,
  max_stalls integer not null default 0,
  current_count integer not null default 0,
  status text not null default '報名中',
  need_review boolean not null default true,
  modules_json jsonb not null default '{}'::jsonb,
  equip_json jsonb not null default '{}'::jsonb,
  basic_equip text,
  custom_fields_json jsonb not null default '[]'::jsonb,
  addons_json jsonb not null default '[]'::jsonb,
  invoice_tax_json jsonb not null default '{"stall":true,"equip":false,"extra":false}'::jsonb,
  refund_rules_json jsonb,
  theme text,
  organizer text,
  co_organizer text,
  portals text,
  cover_url text,
  description text,
  stall_list_json jsonb not null default '[]'::jsonb,
  assigned_staff text,
  force_cancel boolean not null default false,
  force_cancel_target_id text,
  force_cancel_deadline timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ────────────────────────────────────────────────────────────────
-- 4. Members / registrations / registration items
-- ────────────────────────────────────────────────────────────────

create table if not exists public.members (
  email text not null,
  tenant_id text not null references public.tenants(id) on delete cascade,
  name text,
  phone text,
  brand text,
  brand_name text,
  brand_intro text,
  photo_url text,
  fb_url text,
  ig_url text,
  collab_url text,
  collab_desc text,
  collab_items text,
  company text,
  tax_id text,
  invoice_email text,
  city text,
  line_id text,
  fast_pass boolean not null default false,
  invoice_carrier text,
  invoice_type text,
  invoice_title text,
  sell_category text,
  joined_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (tenant_id, email)
);

create table if not exists public.registrations (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  session_id text references public.sessions(id) on delete set null,
  event_id text references public.events(id) on delete set null,
  registration_type_id text references public.registration_types(id) on delete set null,
  email text not null,
  name text,
  phone text,
  brand text,
  brand_name text,
  brand_intro text,

  -- H-01 正式欄位（Worker 統一讀寫）
  sell_category text,    -- 正式。舊欄位 sell_cat 廢棄（僅保留 schema 相容）
  sell_cat text,         -- 廢棄：請勿從 Worker 寫入，僅供舊資料讀取
  sell_items text,       -- 正式。舊欄位 sell_item 廢棄
  sell_item text,        -- 廢棄：請勿從 Worker 寫入
  sell_link text,
  photo_url text,
  fb_url text,
  ig_url text,

  -- H-01：equipment_json 為正式欄位；equip_json 廢棄
  equipment_json jsonb not null default '{}'::jsonb,  -- 正式
  equip_json jsonb not null default '{}'::jsonb,      -- 廢棄：保留 schema 相容，勿從 Worker 寫入

  custom_fields_json jsonb not null default '{}'::jsonb,
  participants_json jsonb not null default '{}'::jsonb,
  selected_dates_json jsonb not null default '[]'::jsonb,
  addon_qty_json jsonb not null default '{}'::jsonb,
  addon_amount numeric not null default 0,
  stall_count integer not null default 1,

  -- H-01：stall_number 為正式欄位；stall_no 廢棄
  stall_number text,     -- 正式
  stall_no text,         -- 廢棄：保留 schema 相容，勿從 Worker 寫入

  deposit numeric not null default 0,
  review_status text not null default '待審核',
  registration_status text not null default 'active',

  -- H-01：payment_status 為正式欄位；pay_status 廢棄
  payment_status text not null default '未繳費',  -- 正式
  pay_status text not null default '',             -- 廢棄：保留 schema 相容，勿從 Worker 寫入

  amount numeric not null default 0,
  total_amount numeric not null default 0,

  -- H-01：payment_method 為正式欄位；pay_method 廢棄
  payment_method text,  -- 正式
  pay_method text,      -- 廢棄：保留 schema 相容，勿從 Worker 寫入

  paid_at timestamptz,
  payment_report_amount numeric not null default 0,
  payment_last5 text,
  payment_reported_at timestamptz,
  payment_screenshot_status text not null default '',
  payment_screenshot_received_at timestamptz,
  payment_detail_json jsonb not null default '{}'::jsonb,
  payment_line_card_text text,
  checkin_status text default '未報到',
  checkin_at timestamptz,
  clear_status text default '未清場',
  deposit_refunded text default '未退押金',
  tax_id text,
  invoice_title text,
  invoice_email text,
  invoice_status text,
  invoice_type text,
  invoice_carrier text,
  admin_note text,

  -- H-01：reminder_sent 為正式欄位；remind_sent 廢棄
  reminder_sent boolean not null default false,  -- 正式
  remind_sent boolean not null default false,    -- 廢棄：保留 schema 相容，勿從 Worker 寫入

  transfer_status text default '',
  transfer_target_session_id text,
  original_session_id text,
  transfer_chosen_at timestamptz,
  refund_amount numeric not null default 0,
  refund_admin_fee numeric not null default 0,
  refund_transfer_fee numeric not null default 0,
  refund_rule_label text,
  refunded_at timestamptz,
  refund_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.registration_items (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  registration_id text references public.registrations(id) on delete cascade,
  session_id text references public.sessions(id) on delete set null,
  item_type text not null default 'fee',
  item_name text not null,
  quantity numeric not null default 1,
  unit_price numeric not null default 0,
  amount numeric not null default 0,
  tax_included boolean not null default true,
  meta_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- ────────────────────────────────────────────────────────────────
-- 5. Payments / refunds / invoices / finance
-- ────────────────────────────────────────────────────────────────

create table if not exists public.payments (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  reg_id text references public.registrations(id) on delete set null,
  session_id text references public.sessions(id) on delete set null,
  email text,
  amount numeric not null default 0,
  method text,
  status text not null default '待確認',
  trade_no text,
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  screenshot_status text not null default '',
  screenshot_received_at timestamptz,
  detail_json jsonb not null default '{}'::jsonb,
  line_card_text text,
  admin_note text
);

create table if not exists public.refunds (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  reg_id text references public.registrations(id) on delete set null,
  payment_id text references public.payments(id) on delete set null,
  session_id text references public.sessions(id) on delete set null,
  email text,
  status text not null default 'requested',
  paid_amount numeric not null default 0,
  refund_amount numeric not null default 0,
  admin_fee numeric not null default 0,
  transfer_fee numeric not null default 0,
  rule_label text,
  reason text,
  requested_at timestamptz,
  confirmed_at timestamptz,
  created_by text,
  confirmed_by text,
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.finance_items (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  session_id text references public.sessions(id) on delete set null,
  type text,
  name text,
  amount numeric default 0,
  is_auto boolean default false,
  meta_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.invoices (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  reg_id text references public.registrations(id) on delete set null,
  session_id text references public.sessions(id) on delete set null,
  invoice_type text,
  invoice_title text,
  tax_id text,
  invoice_email text,
  invoice_carrier text,
  amount_total numeric not null default 0,
  amount_untaxed numeric not null default 0,
  tax_amount numeric not null default 0,
  status text not null default '待開立',
  issued_at timestamptz,
  note text,
  created_at timestamptz not null default now()
);

-- ────────────────────────────────────────────────────────────────
-- 6. Stalls / equipment
-- ────────────────────────────────────────────────────────────────

create table if not exists public.stalls (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  session_id text not null references public.sessions(id) on delete cascade,
  stall_no text not null,
  number text,
  status text not null default '空閒',
  reg_id text references public.registrations(id) on delete set null,
  email text,
  hold_time timestamptz,
  meta_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique (tenant_id, session_id, stall_no)
);

create table if not exists public.equipment_items (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  session_id text references public.sessions(id) on delete cascade,
  name text not null,
  price numeric not null default 0,
  included_qty integer not null default 0,
  stock_qty integer,
  is_active boolean not null default true,
  meta_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- ────────────────────────────────────────────────────────────────
-- 7. Email / report templates / announcements / audit
-- ────────────────────────────────────────────────────────────────

create table if not exists public.email_templates (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  template_key text not null,
  subject text not null default '[placeholder]',
  body_html text not null default '<p>[placeholder]</p>',
  button_label text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tenant_id, template_key)
);

create table if not exists public.report_templates (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  template_key text not null,
  name text not null,
  file_format text not null default 'csv',
  columns_json jsonb not null default '[]'::jsonb,
  role_required text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (tenant_id, template_key)
);

create table if not exists public.announcements (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  title text,
  content text,
  link_url text,
  link_text text,
  url text,
  url_text text,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id text primary key,
  tenant_id text references public.tenants(id) on delete set null,
  actor_email text,
  actor_role text,
  action text not null,
  target_table text,
  target_id text,
  before_json jsonb not null default '{}'::jsonb,
  after_json jsonb not null default '{}'::jsonb,
  meta_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.report_exports (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  session_id text references public.sessions(id) on delete set null,
  event_id text references public.events(id) on delete set null,
  template_id text references public.report_templates(id) on delete set null,
  file_name text,
  file_format text not null default 'csv',
  status text not null default 'generated',
  snapshot_summary_json jsonb not null default '{}'::jsonb,
  generated_by text,
  generated_at timestamptz not null default now(),
  downloaded_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.report_download_logs (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  session_id text references public.sessions(id) on delete set null,
  event_id text references public.events(id) on delete set null,
  template_id text references public.report_templates(id) on delete set null,
  export_id text references public.report_exports(id) on delete set null,
  staff_email text,
  action text not null default 'download',
  file_name text,
  file_format text not null default 'csv',
  status text not null default 'generated',
  user_agent text,
  meta_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- ────────────────────────────────────────────────────────────────
-- 8. Indexes
-- ────────────────────────────────────────────────────────────────

create index if not exists idx_platform_staff_email on public.platform_staff(email);
create index if not exists idx_staff_tenant_email on public.staff(tenant_id, email);
create index if not exists idx_events_tenant on public.events(tenant_id);
create index if not exists idx_sessions_tenant_status on public.sessions(tenant_id, status);
create index if not exists idx_sessions_event on public.sessions(event_id);
create index if not exists idx_members_tenant_email on public.members(tenant_id, email);
create index if not exists idx_regs_tenant_email on public.registrations(tenant_id, email);
create index if not exists idx_regs_tenant_session on public.registrations(tenant_id, session_id);
create index if not exists idx_regs_status on public.registrations(tenant_id, review_status, payment_status, transfer_status);
create index if not exists idx_payments_tenant_reg on public.payments(tenant_id, reg_id);
create index if not exists idx_payments_status on public.payments(tenant_id, status);
create index if not exists idx_refunds_tenant_reg on public.refunds(tenant_id, reg_id);
create index if not exists idx_stalls_tenant_session on public.stalls(tenant_id, session_id);
create index if not exists idx_finance_tenant_session on public.finance_items(tenant_id, session_id);
create index if not exists idx_invoices_tenant_session on public.invoices(tenant_id, session_id);
create index if not exists idx_audit_tenant_created on public.audit_logs(tenant_id, created_at desc);

commit;
