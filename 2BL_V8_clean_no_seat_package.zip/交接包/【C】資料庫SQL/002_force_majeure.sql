-- ================================================================
-- 2BL V8｜不可抗力取消／延期／退款模組 Migration
-- File: database/002_force_majeure.sql
-- Purpose: 在既有 V8 schema 上新增不可抗力相關欄位與 log 表
-- 安全：全部使用 ADD COLUMN IF NOT EXISTS，可重複執行不破壞既有資料
-- 執行順序：001_init.sql → functions/claim_session_slot.sql → 002_force_majeure.sql → seed_test_data.sql
-- ================================================================

begin;

-- ────────────────────────────────────────────────────────────────
-- 1. sessions 新增不可抗力欄位
--    注意：已有 force_cancel / force_cancel_target_id / force_cancel_deadline
--    新增欄位為完整不可抗力模組所需，舊欄位保留相容
-- ────────────────────────────────────────────────────────────────

alter table public.sessions
  add column if not exists force_cancelled boolean not null default false,
  add column if not exists force_cancel_reason_code text,
  add column if not exists force_cancel_reason_label text,
  add column if not exists force_cancel_note text,
  add column if not exists force_cancelled_at timestamptz,
  add column if not exists force_mode text,
  -- 'transfer_or_refund' = 提供延期目標場次
  -- 'refund_only'        = 無延期，直接退費
  add column if not exists force_transfer_target_session_id text,
  add column if not exists force_choice_deadline timestamptz,
  add column if not exists force_notice_sent_at timestamptz;

-- ────────────────────────────────────────────────────────────────
-- 2. registrations 新增不可抗力狀態欄位
--    注意：original_session_id 已存在（V8 原生欄位）
-- ────────────────────────────────────────────────────────────────

alter table public.registrations
  add column if not exists force_status text,
  -- 狀態機：
  -- null                = 不在不可抗力流程中
  -- pending_force_choice= 可選延期或退費（第一層，有延期場次模式）
  -- transferred         = 已同意延期（原始報名）
  -- refund_requested    = 主動申請退費
  -- auto_refund_requested= 逾期自動申請退費
  -- refunded            = 退費完成
  -- cancel_notice_only  = 只通知（第二層：已錄取未付款 / 待審核）
  -- no_force_action     = 不進入不可抗力流程（第三層）
  -- refund_only_auto    = 無延期場次模式，自動進入退費

  add column if not exists transferred_to_session_id text,
  -- 原始報名延期到哪個新場次
  add column if not exists transferred_from_registration_id text,
  -- 新報名來自哪筆原始報名
  add column if not exists force_choice_at timestamptz,
  add column if not exists force_choice_email text,
  add column if not exists force_choice_ip text,
  -- 攤友同意延期或申請退費時的來源 IP（可 null）
  add column if not exists force_choice_user_agent text,
  -- 攤友同意延期或申請退費時的 User-Agent（可 null）
  add column if not exists force_refund_requested_at timestamptz,
  add column if not exists force_refunded_at timestamptz,
  add column if not exists force_refund_note text;

-- ────────────────────────────────────────────────────────────────
-- 3. force_majeure_logs 新表
-- ────────────────────────────────────────────────────────────────

create table if not exists public.force_majeure_logs (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  registration_id text references public.registrations(id) on delete set null,
  session_id text references public.sessions(id) on delete set null,
  action text not null,
  old_status text,
  new_status text,
  actor_type text not null default 'system',  -- admin / member / system
  actor_email text,
  reason_code text,
  target_session_id text,
  note text,
  ip text,           -- 操作者來源 IP（可 null；system 觸發時為 null）
  user_agent text,   -- 操作者 User-Agent（可 null；system 觸發時為 null）
  created_at timestamptz not null default now()
);

-- ────────────────────────────────────────────────────────────────
-- 4. Indexes
-- ────────────────────────────────────────────────────────────────

create index if not exists idx_force_logs_tenant    on public.force_majeure_logs(tenant_id, created_at desc);
create index if not exists idx_force_logs_reg       on public.force_majeure_logs(registration_id);
create index if not exists idx_force_logs_session   on public.force_majeure_logs(session_id);
create index if not exists idx_regs_force_status    on public.registrations(tenant_id, force_status);
create index if not exists idx_sessions_force       on public.sessions(tenant_id, force_cancelled);

commit;
