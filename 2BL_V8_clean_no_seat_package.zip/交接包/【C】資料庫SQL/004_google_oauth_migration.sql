-- ════════════════════════════════════════════════════════════════
-- 2BL V8 Migration 004: Google OAuth 安全升級
-- 執行方式：在現有 DB 上執行，不刪除任何既有資料
-- 執行順序：在 003_agreement.sql 之後執行
-- ════════════════════════════════════════════════════════════════

-- Safe note: 全部使用 ALTER TABLE ... ADD COLUMN IF NOT EXISTS
-- 不會清空任何現有資料，可安全在正式 DB 上執行

-- ────────────────────────────────────────────────────────────────
-- 1. staff 表：補齊 OAuth 所需欄位
-- ────────────────────────────────────────────────────────────────

-- is_active（規格要求，相容舊 active 欄位）
ALTER TABLE public.staff
  ADD COLUMN IF NOT EXISTS is_active boolean not null default true;

-- 將舊 active 欄位資料同步到 is_active（若舊欄位存在）
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'staff' AND column_name = 'active'
  ) THEN
    UPDATE public.staff SET is_active = active WHERE is_active IS DISTINCT FROM active;
  END IF;
END $$;

-- display_name（Google 登入後顯示名稱）
ALTER TABLE public.staff
  ADD COLUMN IF NOT EXISTS display_name text;

-- last_login_at（記錄最後登入時間）
ALTER TABLE public.staff
  ADD COLUMN IF NOT EXISTS last_login_at timestamptz;

-- normalized_role（標準化角色碼，加速查詢）
ALTER TABLE public.staff
  ADD COLUMN IF NOT EXISTS normalized_role text;

-- 同步 normalized_role 初始值
UPDATE public.staff SET normalized_role = CASE
  WHEN role IN ('superadmin','超級管理員','platform_super_admin') THEN 'platform_super_admin'
  WHEN role IN ('主辦','主辦者','organizer_owner') THEN 'organizer_owner'
  WHEN role IN ('活動夥伴','共創夥伴','organizer_admin','organizer') THEN 'organizer_admin'
  WHEN role IN ('場次管理員','session_admin') THEN 'session_admin'
  WHEN role IN ('財務管理員','finance_admin') THEN 'finance_admin'
  WHEN role IN ('現場人員','onsite_staff') THEN 'onsite_staff'
  ELSE role
END
WHERE normalized_role IS NULL OR normalized_role = '';

-- ────────────────────────────────────────────────────────────────
-- 2. platform_staff 表：補齊欄位
-- ────────────────────────────────────────────────────────────────
ALTER TABLE public.platform_staff
  ADD COLUMN IF NOT EXISTS display_name text;

ALTER TABLE public.platform_staff
  ADD COLUMN IF NOT EXISTS last_login_at timestamptz;

ALTER TABLE public.platform_staff
  ADD COLUMN IF NOT EXISTS normalized_role text not null default 'platform_super_admin';

-- ────────────────────────────────────────────────────────────────
-- 3. 新增 admin_login_logs 表（登入記錄）
-- ────────────────────────────────────────────────────────────────
create table if not exists public.admin_login_logs (
  id text primary key,
  tenant_id text not null default '',
  staff_id text,
  email text not null default '',
  provider text not null default 'google',
  login_status text not null default 'error',
  reason text not null default '',
  ip text not null default '',
  user_agent text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists idx_admin_login_logs_email on public.admin_login_logs(email);
create index if not exists idx_admin_login_logs_tenant on public.admin_login_logs(tenant_id);
create index if not exists idx_admin_login_logs_created on public.admin_login_logs(created_at desc);

-- ────────────────────────────────────────────────────────────────
-- 4. 驗算：確認欄位補齊
-- ────────────────────────────────────────────────────────────────
DO $$
DECLARE
  missing_cols text := '';
BEGIN
  -- 檢查 staff 欄位
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='staff' AND column_name='is_active') THEN
    missing_cols := missing_cols || 'staff.is_active, ';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='staff' AND column_name='last_login_at') THEN
    missing_cols := missing_cols || 'staff.last_login_at, ';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='staff' AND column_name='display_name') THEN
    missing_cols := missing_cols || 'staff.display_name, ';
  END IF;
  -- 檢查 admin_login_logs 存在
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='admin_login_logs') THEN
    missing_cols := missing_cols || 'admin_login_logs, ';
  END IF;

  IF missing_cols <> '' THEN
    RAISE EXCEPTION '004 migration 未完整：缺少 %', missing_cols;
  ELSE
    RAISE NOTICE '✅ 004_google_oauth_migration 執行完成，所有欄位與資料表均已建立';
  END IF;
END $$;
