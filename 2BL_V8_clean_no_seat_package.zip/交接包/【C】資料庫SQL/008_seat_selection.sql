-- 008_seat_selection.sql
-- 2BL V8 選位模組補強：不重建既有 stalls，只補正式選位需要的欄位與紀錄表。

alter table if exists public.stalls add column if not exists seat_label text;
alter table if exists public.stalls add column if not exists seat_type text;
alter table if exists public.stalls add column if not exists price_adjustment numeric not null default 0;
alter table if exists public.stalls add column if not exists sort_order integer not null default 0;
alter table if exists public.stalls add column if not exists row_label text;
alter table if exists public.stalls add column if not exists col_label text;
alter table if exists public.stalls add column if not exists is_selectable boolean not null default true;
alter table if exists public.stalls add column if not exists is_reserved boolean not null default false;
alter table if exists public.stalls add column if not exists is_locked boolean not null default false;
alter table if exists public.stalls add column if not exists updated_at timestamptz;

create table if not exists public.seat_maps (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  session_id text not null references public.sessions(id) on delete cascade,
  map_name text not null default '預設選位圖',
  map_type text not null default 'grid',
  layout_json jsonb not null default '{}'::jsonb,
  is_enabled boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);

create table if not exists public.seat_assignments (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  session_id text not null references public.sessions(id) on delete cascade,
  registration_id text references public.registrations(id) on delete set null,
  stall_id text references public.stalls(id) on delete set null,
  seat_code text not null,
  status text not null default '預留',
  assigned_by text,
  assigned_source text not null default 'member',
  assigned_at timestamptz not null default now(),
  released_at timestamptz,
  locked_at timestamptz
);

create table if not exists public.seat_operation_logs (
  id text primary key,
  tenant_id text not null references public.tenants(id) on delete cascade,
  session_id text references public.sessions(id) on delete set null,
  registration_id text references public.registrations(id) on delete set null,
  stall_id text references public.stalls(id) on delete set null,
  action text not null,
  operator_type text,
  operator_id text,
  note text,
  created_at timestamptz not null default now()
);

create index if not exists idx_seat_maps_tenant_session on public.seat_maps(tenant_id, session_id);
create index if not exists idx_seat_assignments_tenant_session on public.seat_assignments(tenant_id, session_id);
create index if not exists idx_seat_assignments_registration on public.seat_assignments(registration_id);
create index if not exists idx_seat_logs_tenant_session on public.seat_operation_logs(tenant_id, session_id);

-- 防撞核心：同場次同攤位僅允許一筆有效佔用。
create unique index if not exists uq_seat_assignment_active
on public.seat_assignments(tenant_id, session_id, seat_code)
where status in ('預留','鎖定');
