# 2BL V8 整合版｜清理後交付包

## 目前可部署主線

正式部署仍只使用 3 個主檔：

1. 【A】立即部署檔案/register.html
2. 【A】立即部署檔案/admin.html
3. 【A】立即部署檔案/worker.js

worker.txt 已同步為 worker.js 的純文字副本，只是方便貼 Cloudflare 的備用檔；不得獨立修改。

## SQL

無選位版主線使用：

- 001_init.sql
- functions/claim_session_slot.sql
- 002_force_majeure.sql
- 003_agreement.sql
- 004_google_oauth_migration.sql
- 005_commercialize_migration.sql
- 006_agreement_columns.sql
- 007_agreement_templates_table.sql

008_seat_selection.sql 保留待用，不納入目前無選位版主線驗收。

## 目前狀態

可驗收：前台報名、後台管理、Google/Email 登入、會員資料、合約、費用試算與 Worker 重新驗算、手動付款管理。

暫時隔離：選位模組。

## 報告

請看 reports：

- changed_files.md
- version_cleanup_report.md
- validation_report.md
